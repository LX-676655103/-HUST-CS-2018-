#include "sendthread副本.h"

SendThread::SendThread()
{

}
