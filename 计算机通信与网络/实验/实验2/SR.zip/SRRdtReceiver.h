#ifndef STOPWAIT_SRRECEIVER_H
#define STOPWAIT_SRRECEIVER_H
#include "RdtReceiver.h"
#include "Global.h"

struct RCV_WINDOW
{
    Packet data;
    int status;
};

class SRRdtReceiver :public RdtReceiver
{
private:
    int rcv_base;    //接收窗口的base
    //接收窗口，窗口大小为8
    RCV_WINDOW rcv_win[WIN_LEN];  
    Packet AckPkt; //确认报文
public:
    int tran_num(int num); //将序号转换成窗口下标
    int belong_win(int num); //判断报文序号状态
    void receive(const Packet& packet);
public:
    SRRdtReceiver();
    virtual ~SRRdtReceiver();
    
};
#endif
