#ifndef STOPWAIT_SRSENDER_H
#define STOPWAIT_SRSENDER_H
#include "RdtSender.h"
#include "Global.h"

//窗口的状态情况，分为未发送，未确认以及已确认
#define UN_SENT   0
#define UN_ACK     1
#define ACKED       2

struct SND_WINDOW //发送窗口
{
    Packet data;
    int status;
};
class SRRdtSender :public RdtSender
{
private:
    int send_base;   //发送窗口的base
    int nextseqnum;  //发送窗口的nextseqnum
    bool waitingState; //是否处于等待ACK状态
    SND_WINDOW  snd_win[WIN_LEN];  //发送窗口，窗口大小为8
public:

    int tran_num(int num); //将序号转换成窗口下标
    int belong_win(int num); //判断返回的确认号是否在窗口中
    bool getWaitingState();
    bool send(const Message &message);
    void receive(const Packet &ackPkt);
    void timeoutHandler(int seqNum);
    SRRdtSender();
    virtual  ~SRRdtSender();
};
#endif //STOPWAIT_SRSENDER_H
