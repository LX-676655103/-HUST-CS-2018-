
#include "Global.h"
#include "RdtSender.h"
#include "RdtReceiver.h"
#include "GBNRdtReceiver.h"
#include "GBNRdtSender.h"


int main(int argc, char* argv[])
{
    RdtSender* ps = new GBNSender();
    RdtReceiver* pr = new GBNReceiver();
    pns->setRunMode(1);
    pns->init();
    pns->setRtdSender(ps);
    pns->setRtdReceiver(pr);
    pns->setInputFile("input.txt");
    pns->setOutputFile("output.txt");
    pns->start();
    delete ps;
    delete pr;
    delete pUtils;
    delete pns;

    return 0;
}

