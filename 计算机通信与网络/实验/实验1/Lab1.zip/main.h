#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include <iostream>
#include <stdio.h>
#include <winsock.h>
#include <algorithm>
#include <string>
#include <regex>
#include <time.h>
using namespace std;
#include "HttpClientContent.h"
#include "HttpResponseContent.h"
bool endWith(const string& fullStr, const string& endStr);
string getTime();
int print_menu();
int init_window(WSADATA& wsaData);
int print_respond_message(HttpResponseContent respond_content, HttpClientContent client_content);
