#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#include "HttpResponseContent.h"
#include "main.h"
#define BUFLEN 255
#define FILE_CLOSED 0


int HttpResponseContent::get_order() { return order; }
string HttpResponseContent::get_time() { return time; }
string HttpResponseContent::get_status_line() { return status_line; }
string HttpResponseContent::get_content_type() { return content_type; }
int HttpResponseContent::get_file_length() { return file_length; }

int HttpResponseContent::open_file(string mainPath, string url)
{
	int status = url_classification(url); //ʹ��url_classification�ж��ļ�����
	status_line = "HTTP/1.1 200 OK\r\n";
	infile = fopen((mainPath + url).c_str(), "rb");
	if (infile == NULL) //�����ǰ�ļ�������
	{ 
		infile = fopen((mainPath + "\\404.html").c_str(), "rb");
		status_line = "HTTP/1.1 404 Not Found\r\n";
		content_type = "text/html";
	}
	else if (status)
	{
		fclose(infile);
		//�����Զ���501ҳ��
		infile = fopen((mainPath + "\\501.html").c_str(), "rb");
		status_line = "HTTP/1.1 501 Not Inplemented\r\n";
		content_type = "text/html";
	}
	//ָ��ָ���ļ�ĩβ
	fseek(infile, 0, SEEK_END); 
	file_length = ftell(infile);
	//ָ������ָ���ļ�ͷ
	fseek(infile, 0, SEEK_SET); 
	return 0;
}
int HttpResponseContent::url_classification(string url)
{
	if (endWith(url, "html")) content_type = "text/html";
	else if (endWith(url, "htm")) content_type = "text/html";
	else if (endWith(url, ".txt")) content_type = "text/plain";
	else if (endWith(url, ".jpg")) content_type = "image/jpeg";
	else if (endWith(url, ".JPG")) content_type = "image/jpeg";
	else if (endWith(url, ".jpeg")) content_type = "image/jpeg";
	else if (endWith(url, ".png")) content_type = "image/png";
	else if (endWith(url, ".ico")) content_type = "image/x-icon";
	else if (endWith(url, ".css")) content_type = "text/css";
	else if (endWith(url, ".js")) content_type = "application/x-javascript";
	else if (endWith(url, ".gif")) content_type = "image/gif";
	else if (endWith(url, ".mp4")) content_type = "video/mpeg4";
	else if (endWith(url, ".mp3")) content_type = "audio/mp3";
	else if (endWith(url, ".avi")) content_type = "video/avi";
	else return -1;
	return 0;
}
int HttpResponseContent::Generate_respond_header(HttpClientContent client_content)
{
	string fullPath;
	time = getTime();
	server_version = "csr_http1.1";
	connect_status = "close";
	//connect_status = "keep-alive";
	//���������Ӧ���ı�ͷ
	respond_header = status_line  //״̬��
		+ "Content-Type: " + content_type + "\r\n"
		+ "Content-Length: " + std::to_string(file_length) + "\r\n"
		+ "Server: " + server_version + "\r\n"
		+ "Connection: "+ connect_status + "\r\n"
		+ "\r\n";    //��ͷ������־�����У�
	order++;
	return 0;
}

int HttpResponseContent::send_respond_header(SOCKET socket)
{
	int length = (int)(respond_header.length());
	return send(socket, respond_header.c_str(), length, 0);
}
int HttpResponseContent::send_data(SOCKET socket)
{
	char sendBuf[BUFLEN];
	while (true)
	{
		memset(sendBuf, 0, BUFLEN * sizeof(char));
		int bufReadNum = fread(sendBuf, 1, 255, infile);
		int status = send(socket, sendBuf, bufReadNum, 0);
		if (status == SOCKET_ERROR) return status;
		if (feof(infile))
		{
			fclose(infile); 
			break;
		}
	}
	return 0;
}

