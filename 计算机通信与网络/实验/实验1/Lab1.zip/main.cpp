#include "main.h"
#include "HttpClientContent.h"
#include "HttpResponseContent.h"
#include "ServerSocket.h"
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS

int HttpResponseContent::order = 1;
int main()
{
	SOCKET socket;
	WSADATA wsaData;
	ServerSocket srvSocket;
	HttpClientContent client_content;
	HttpResponseContent respond_content;
	print_menu();
	init_window(wsaData);

	if (srvSocket.create_socket()) return 0;
	if (srvSocket.bind_socket()) return 0;
	if (srvSocket.listen_socket()) return 0;
	
	int op = 0;
	string mainPath = "C:\\Users\\new\\Desktop\\lx531";
	cout << "       Main directory: " << mainPath << endl;
	printf("       If you want to modify the directory, please enter 1, else enter 0: ");
	scanf_s("%d", &op);
	if (op) { printf("       Please enter Main directory��"); cin >> mainPath; }
	print_menu();
	while (true)
	{
		socket = srvSocket.get_socket();
		socket = client_content.recv_content(socket);
		string url = client_content.get_url();
		respond_content.open_file(mainPath, url);
		respond_content.Generate_respond_header(client_content);
		respond_content.send_respond_header(socket);
		print_respond_message(respond_content, client_content);
		respond_content.send_data(socket);
	}
	return 0;
}