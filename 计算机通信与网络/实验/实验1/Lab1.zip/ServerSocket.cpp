#include "ServerSocket.h"
#define MAXCONN 100
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
int ServerSocket::create_socket()
{
	srvSocket = socket(AF_INET, SOCK_STREAM, 0);
	if (srvSocket == INVALID_SOCKET)
	{
		printf("       Server create socket error!\n");
		WSACleanup();
		return -1;
	}
	printf("       Server TCP socket create OK!\n");
	return 0;
}
int ServerSocket::bind_socket()
{
	int op = 0;
	//�� socket to Server's IP and port
	srvAddr.sin_family = AF_INET;
	srvAddr.sin_port = htons(5050);  //ʹ��htons�������ֽ�˳��ת��������ֽ�˳�򣬼�С��ת���
	srvAddr.sin_addr.S_un.S_addr = INADDR_ANY; //����Ĭ�ϵ�ַ0.0.0.0
	printf("       Server's IP��0.0.0.0 , Server's port: 5050 \n");
	printf("       If you want to modify the IP address and port, please enter 1, else enter 0: ");
	scanf_s("%d", &op);
	if (op) {
		int temp_num; char temp[30];
		printf("       Please enter Server's IP��");
		scanf_s("%s", temp, 30);
		srvAddr.sin_addr.S_un.S_addr = inet_addr(temp); //������0.0.0.0����ʽת��Ϊ��ʶ��ģʽ
		printf("       Please enter Server's port��");
		scanf_s("%d", &temp_num);
		srvAddr.sin_port = htons(temp_num);
	}
	int nRC = bind(srvSocket, (LPSOCKADDR)&srvAddr, sizeof(srvAddr));
	if (nRC == SOCKET_ERROR)
	{
		printf("       Server socket bind error!\n");
		closesocket(srvSocket);
		WSACleanup();
		return -1;
	}
	printf("       Server socket bind OK!\n");
	return 0;
}
int ServerSocket::listen_socket()
{
	//��ʼ�������̣��ȴ��ͻ�������
	int nRC = listen(srvSocket, MAXCONN);
	if (nRC == SOCKET_ERROR)
	{
		printf("       Server socket listen error!\n");
		closesocket(srvSocket);
		WSACleanup();
		return -1;
	}
	printf("       Server socket listen OK!\n");
	return 0;
}
SOCKET& ServerSocket::get_socket() { return srvSocket; }

