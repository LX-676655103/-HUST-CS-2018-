#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#include "main.h"

bool endWith(const string& fullStr, const string& endStr)
{
	if (endStr.size() > fullStr.size()) return false;
	int full = fullStr.size() - 1;
	int end = endStr.size() - 1;
	while (end >= 0)
	{
		if (fullStr[full] != endStr[end])
			return false;
		full--;  end--;
	}
	return true;
}
string getTime()
{
	time_t timep;
	time(&timep);
	char tmp[64];
	strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S", localtime(&timep));
	return tmp;
}
int print_menu()
{
	system("cls");	printf("\n\n");
	printf("       Welcome to use the Web server monitoring window     \n");
	printf("--------------------------------------------------------------\n");
	return 0;
}

int init_window(WSADATA& wsaData)
{
	int nRC;
	nRC = WSAStartup(0x0101, &wsaData);
	if (nRC)
	{
		printf("       Server initialize winsock error!\n");
		return -1;
	}
	else if (wsaData.wVersion != 0x0101)
	{
		printf("       Server's winsock version error!\n");
		WSACleanup();
		return -1;
	}
	printf("       Server's winsock initialized!\n");
	return 0;
}
int print_respond_message(HttpResponseContent respond_content, HttpClientContent client_content)
{
	cout << "       " << "Current Num: " << respond_content.get_order() << endl;
	cout << "       " << "Current Time: " << respond_content.get_time() << endl;
	cout << "       " << "Client's IP: " << client_content.get_IP() << endl;
	cout << "       " << "Client's Port: " << client_content.get_Port() << endl;
	cout << "       " << "Method: " << client_content.get_method() << endl;
	cout << "       " << "URL: " << client_content.get_url() << endl;
	cout << "       " << "Content-Type: " << respond_content.get_content_type() << endl;
	cout << "       " << "Content-Length: " << respond_content.get_file_length() << endl;
	cout << "       " << "Respond-Header: " << respond_content.get_status_line() << "\n" << endl;
	return 0;
}