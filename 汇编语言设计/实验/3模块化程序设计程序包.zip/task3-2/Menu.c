#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define N 7
#ifdef __cplusplus
extern "C" {
#endif
int OP3(char* GOOD);
int F10T2(char* STR);
void Calculate(void);
void Sort(void);
char* OP8(void);
extern char GA;
#ifdef __cplusplus
}
#endif


int main()
{
    int i,temp;
    char op=1,AUTH=0,*GOOD=NULL,*STICK;
    char BNAME[10]="LI XIANG",BPASS[10]="test",INAME[20],IPASS[10],IGOOD[10],INUM[20];
    _asm mov eax,ebx
    _asm mov ebx,eax
    while(op)
    {
        system("cls");
        printf("      Menu for Online store system\n");
        if(AUTH) printf("      Current username:%s\n",BNAME);
        else printf("      Current username:customer\n");
        if(GOOD) printf("      Current product name:%s\n",GOOD);
        else printf("      Current product name:\n");
        printf("      Please enter the numbers 1-9 to select the function:\n");
        printf("            1. Login / Re-Login\n");
        printf("            2. Find the specified product and display its information\n");
        printf("            3. Place an order\n");
        printf("            4. Calculate product recommendation\n");
        printf("            5. Ranking\n");
        printf("            6. Modify product information\n");
        printf("            7. Migrate the store operating environment\n");
        printf("            8. Display the message of the CS\n");
        printf("            9. Exit\n      ");
        op=getchar(); getchar();
        switch(op){
            case '1':
                INAME[0]=0;
                printf("      Please enter username:");
                scanf_s("%[^\n]%*c",INAME,20);
                if(INAME[0]==0){ AUTH=0; break;}
                if(strcmp(BNAME,INAME)!=0){AUTH=0; printf("      Login failed!\n");}
                else
                {
                    printf("      Please enter password:");
                    scanf_s("%[^\n]%*c",IPASS,10);
                    if(strcmp(BPASS,IPASS)!=0){AUTH=0; printf("      Login failed!\n");}
                    else {AUTH=1; printf("      Login successful!");}
                }
                break;
            case '2':
                GOOD=NULL;
                printf("      Please enter product name:");
                scanf_s("%[^\n]%*c",IGOOD,10);
                for(i=0;i<N;i++)
                {
                    if(strcmp((&GA+21*i),IGOOD)==0)
                    {
                        printf("      OK!current goods found!\n");
                        GOOD=&GA+21*i;
                        break;
                    }
                }
                if(GOOD==NULL) printf("      Sorry!No current goods found!\n");
                break;
            case '3':
                if(GOOD!=NULL&&OP3(GOOD))printf("      OK!Successfully ordered!\n");
                else printf("      Sorry!Order failed!\n");
                break;
            case '4':
                Calculate();
                printf("      Calculate finished!\n");
                break;
            case '5':
                Sort();
                printf("          ��Ʒ����     �ۿ�  ������  ���ۼ�  ������  ������  �Ƽ���\n");
                for(i=0;i<N;i++)
                {
                    printf("      %12s%8d%8d%8d%8d%8d%8d\n",(&GA+21*i),*(char*)(&GA+21*i+10),\
                           *(short*)(&GA+21*i+11),*(short*)(&GA+21*i+13),*(short*)(&GA+21*i+15),\
                           *(short*)(&GA+21*i+17),*(short*)(&GA+21*i+19));
                }
                break;
            case '6':
                if(GOOD!=NULL&&AUTH)
                {
                    printf("      Current product name:%s\n",GOOD);
                    do{
                            INUM[0]=0;
                            printf("      Discount:%d->",*(GOOD+10));
                            scanf_s("%[^\n]",INUM,20); getchar();
                            if(INUM[0]==0){temp=-2; break;}
                            temp=F10T2(INUM);
                    }while(temp==-1);
                    if(temp!=-2) *(GOOD+10)=(char)temp;
                    do{
                            INUM[0]=0;
                            printf("      Purchase price:%d->",*(short*)(GOOD+11));
                            scanf_s("%[^\n]",INUM,20); getchar();
                            if(INUM[0]==0){temp=-2; break;}
                            temp=F10T2(INUM);
                    }while(temp==-1);
                    if(temp!=-2) *(short*)(GOOD+11)=(short)temp;
                    do{
                            INUM[0]=0;
                            printf("      Selling price:%d->",*(short*)(GOOD+13));
                            scanf_s("%[^\n]",INUM,20); getchar();
                            if(INUM[0]==0){temp=-2; break;}
                            temp=F10T2(INUM);
                    }while(temp==-1);
                    if(temp!=-2) *(short*)(GOOD+13)=(short)temp;
                    do{
                            INUM[0]=0;
                            printf("      Retail Purchases:%d->",*(short*)(GOOD+15));
                            scanf_s("%[^\n]",INUM,20); getchar();
                            if(INUM[0]==0){temp=-2; break;}
                            temp=F10T2(INUM);
                    }while(temp==-1);
                    if(temp!=-2) *(short*)(GOOD+15)=(short)temp;
                }
                break;
            case '7':
                break;
            case '8':
                STICK=OP8();
                printf("      (CS)=%s\n",STICK);
                break;
            case '9':
                op=0;
                printf("      Welcome to use the system next time!\n");
                break;
            default: printf("      Illegal input!\n"); break;
        }
        getchar();
    }
    return 0;
}

