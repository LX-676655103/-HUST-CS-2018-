
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

BYTE *Read24BitBmpFile2Img(const char * filename,int *width,int *height)
{
	FILE * BinFile;
    BITMAPFILEHEADER FileHeader;
    BITMAPINFOHEADER BmpHeader;
	BYTE *img;
	unsigned int size;
	int Suc=1,w,h;

	// Open File
	*width=*height=0;
	if((BinFile=fopen(filename,"rb"))==NULL) return NULL;
	// Read Struct Info
	if (fread((void *)&FileHeader,1,sizeof(FileHeader),BinFile)!=sizeof(FileHeader)) Suc=-1;
	if (fread((void *)&BmpHeader,1,sizeof(BmpHeader),BinFile)!=sizeof(BmpHeader)) Suc=-1;
	if ( (Suc==-1) || (FileHeader.bfOffBits<sizeof(FileHeader)+sizeof(BmpHeader) ))
	{
			   fclose(BinFile);
			   return NULL;
	}
	// Read Image Data
	*width=w=BmpHeader.biWidth;
	*height=h=BmpHeader.biHeight;
	size=(*width)*(*height)*3;
	fseek(BinFile,FileHeader.bfOffBits,SEEK_SET);
	if ( (img=new BYTE[size])!=NULL)
	{
		for(int i=0;i<h;i++)
		{
			if(fread(img+(h-1-i)*w*3,sizeof(BYTE),w*3,BinFile)!=w*3)
			{
				fclose(BinFile);
				delete img;
				img=NULL;
				return NULL;
			}
			fseek(BinFile,(3*w+3)/4*4-3*w,SEEK_CUR);
		}
    }
    fclose(BinFile);
    return img;
}

void BGR8882BGR555(unsigned char *img888, unsigned char * img555,int width,int height)
{
	unsigned char *p = img888;
	unsigned char *q = img555;
	unsigned char r,g,b;
	unsigned char r1,g1,b1;
	int i ,j;
	for(i = 0;i< height;i++)
	{
		for(j = 0; j< width;j++)
		{
			b = *p;
			g = *(p+1);
			r = *(p+2);
			g1 = g>>6;
			r = (r>>3)<<2;
			*(q+1) = r | g1;
			g1 = ((g<<2)>>5)<<5;
			b1 = (b>>3);
			*(q) = g1 | b1;
			p+=3;
			q+=2;
		}
	}
}
bool Write555BitImg2BmpFile(BYTE *pImg,int width,int height,const char * filename)
{
	FILE *BinFile;
    bool Suc=true;
	BYTE p[4],*pCur;

    // Open File
    if((BinFile=fopen(filename,"w+b"))==NULL) return false;

    unsigned char *q = pImg;
    for(int i=0;i<height;i++)
    {
        for(int j=0;j<width;j++)
        {
            int temp = 0;

            temp+=(*(q+i*width*2+j*2)<<14);
            temp+=(*(q+i*width*2+j*2+1)<<22);
            temp+=(i<<7);
            temp+=(j);
            int num=temp>>14;
            if(num) fprintf(BinFile,"%x\n",temp);
        }
    }
    return 0;
}


int main()
{
	int width,height;

	BYTE *pGryImg=Read24BitBmpFile2Img("dot1.bmp",&width,&height);
	printf("%d,%d",width,height);
	unsigned char *pImg555 = new unsigned char[width*height*2];

	BGR8882BGR555(pGryImg, pImg555,width,height);
	Write555BitImg2BmpFile(pImg555,width,height,"dot2.txt");

	delete pGryImg;
	delete pImg555;
	return 0;
}
