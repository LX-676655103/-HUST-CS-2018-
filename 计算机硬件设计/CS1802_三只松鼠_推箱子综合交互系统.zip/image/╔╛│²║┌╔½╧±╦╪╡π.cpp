#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

int main()
{
    FILE* fromFile, *toFile;
    int tempnum;
	if((fromFile=fopen("about.txt","rb"))==NULL) return NULL;
    if((toFile=fopen("about_g.txt","w+b"))==NULL) return false;
    while(fscanf(fromFile, "%x", &tempnum)>0)
    {
        int num=tempnum>>14;
        if(num)
        {
            printf("%x\n",tempnum);
            fprintf(toFile,"%x\n",tempnum);
        }

    }
    return 0;
}
