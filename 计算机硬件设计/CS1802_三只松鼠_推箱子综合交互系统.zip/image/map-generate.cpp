#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
	//�ˣ���			5
	//���ӣ���		4
	//Ŀ�ĵأ���		3
	//�˺�Ŀ�ĵ��ںϣ�8
	//ǽ����			1
	//�����Ƶ�Ŀ�ĵأ��� 7
	//�յأ�			0
/*
const int height = 7;
const int width = 8;
int map[height][width] =
{
    1,1,1,1,1,1,1,0,
    1,0,0,0,0,0,1,1,
    1,0,4,0,5,0,0,1,
    1,4,4,1,1,4,0,1,
    1,0,4,3,1,0,0,1,
    1,3,3,3,0,3,1,1,
    1,1,1,1,1,1,1,1
};*/









/*const int height = 10;
const int width = 14;
int map[height][width] =
{
    1,1,1,1,1,1,1,1,1,1,1,1,0,0,
    1,3,3,0,0,1,0,0,0,0,0,1,1,1,
    1,3,3,0,0,1,0,4,0,0,4,0,0,1,
    1,3,3,0,0,1,4,1,1,1,1,0,0,1,
    1,3,3,0,0,0,0,5,0,1,1,0,0,1,
    1,3,3,0,0,1,0,1,0,0,4,0,1,1,
    1,1,1,1,1,1,0,1,1,4,0,4,0,1,
    0,0,1,0,4,0,0,4,0,4,0,4,0,1,
    0,0,1,0,0,0,0,1,0,0,0,0,0,1,
    0,0,1,1,1,1,1,1,1,1,1,1,1,1,
};*/


const int height = 9;
const int width = 9;
int map[height][width] =
{
    /*0, 0, 1, 1, 1, 1, 1, 0, 0,
    0, 1, 1, 0, 0, 0, 1, 1, 0,
    0, 1, 0, 0, 4, 3, 3, 1, 1,
    1, 1, 4, 0, 1, 3, 4, 3, 1,
    1, 0, 0, 0, 1, 3, 3, 3, 1,
    1, 0, 4, 1, 1, 1, 4, 0, 1,
    1, 0, 0, 4, 0, 4, 0, 1, 1,
    1, 1, 5, 0, 0, 0, 0, 1, 0,
    0, 1, 1, 1, 1, 1, 1, 1, 0*/

    1, 1, 1, 1, 1, 0, 0, 0, 0,
    1, 0, 0, 5, 1, 0, 0, 0, 0,
    1, 0, 4, 4, 1, 0, 1, 1, 1,
    1, 0, 4, 0, 1, 0, 1, 3, 1,
	1, 1, 1, 0, 1, 1, 1, 3, 1,
	1, 1, 1, 0, 0, 0, 0, 3, 1,
	0, 1, 0, 0, 0, 1, 0, 0, 1,
	0, 1, 0, 0, 0, 1, 1, 1, 1,
	0, 1, 1, 1, 1, 1, 0, 0, 0
};
int main()
{
    FILE *toFile;
    if((toFile=fopen("map.txt","w+b"))==NULL) return false;

    for(int i=0;i<height;i++)
    {
        for(int j=0; j<width; j++)
        {
            int tempnum = 0;
            switch(map[i][j]){
            case 3:
            //case 0:
            case 1:
            case 4:
            case 5:
                tempnum+=((i*8)<<7);
                tempnum+=(j*8);
                // if(map[i][j]==3)
                //    fprintf(toFile,"%x\n",tempnum);
                tempnum+=(map[i][j]<<14);
                fprintf(toFile,"%x\n",tempnum);
            default:
                break;
            }

        }
    }
    return 0;
}
