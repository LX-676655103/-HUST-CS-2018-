
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     INT = 258,
     FLOAT = 259,
     STRING = 260,
     ID = 261,
     RELOP = 262,
     TYPE = 263,
     ERRORID = 264,
     NULL_P = 265,
     TRUE = 266,
     FALSE = 267,
     VOID = 268,
     CLASS = 269,
     THIS = 270,
     NEW = 271,
     DELETE = 272,
     BREAK = 273,
     CONTINUE = 274,
     RETURN = 275,
     IF = 276,
     ELSE = 277,
     WHILE = 278,
     FOR = 279,
     PRINT = 280,
     SCAN = 281,
     ASSIGNOP = 282,
     PLUS = 283,
     MINUS = 284,
     STAR = 285,
     DIV = 286,
     MOD = 287,
     AND = 288,
     OR = 289,
     NOT = 290,
     AUTOPLUS = 291,
     AUTOMINUS = 292,
     PLUSASSIGNOP = 293,
     MINUSASSIGNOP = 294,
     STARASSIGNOP = 295,
     DIVASSIGNOP = 296,
     MODASSIGNOP = 297,
     DOT = 298,
     SEMI = 299,
     COMMA = 300,
     LP = 301,
     RP = 302,
     LC = 303,
     RC = 304,
     LB = 305,
     RB = 306,
     EOL = 307,
     CLASS_DEF_LIST = 308,
     CLASS_DEF = 309,
     FIELD_LIST = 310,
     VAR_DEF = 311,
     FUNC_DEF = 312,
     TYPE_COL = 313,
     VAR_DEF_LIST = 314,
     ID_DEF_LIST = 315,
     FUNC_DEF_ACT = 316,
     FORMALS_DEF = 317,
     VAR_DEF_S = 318,
     NEW_ID_ARR = 319,
     STMT_BLOCK = 320,
     STMT_LIST = 321,
     PRINT_STMT = 322,
     SCAN_STMT = 323,
     RETURN_EXP = 324,
     NEW_ID = 325,
     IF_STMT = 326,
     IF_ELSE_STMT = 327,
     FOR_STMT = 328,
     WHILE_STMT = 329,
     BREAK_STMT = 330,
     CONTINUE_STMT = 331,
     EXP_EXP = 332,
     EXP_ID = 333,
     ID_ACTUALS = 334,
     EXP_ID_ACTUALS = 335,
     ACTUALS = 336,
     EXP_LIST = 337,
     DELETE_ID = 338,
     DELETE_EXP_ID = 339,
     UMINUS = 340,
     LOWER_THEN_ELSE = 341
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 19 "parser.y"

	int    type_int;
	float  type_float;
	char   type_id[32];
                char   type_string[128];
	struct ASTNode *ptr;



/* Line 1676 of yacc.c  */
#line 148 "parser.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;

