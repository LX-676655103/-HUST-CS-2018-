class Main
{
    int m,n;
    int fibo(int a)
    {
        if(a==1||a==2) return 1;
        return fibo(a-1)+fibo(a-2);
    }
    int main()
    {
        int a,b,c;
        m=5;
        a=fibo(5);
        return 0;
    }
}











