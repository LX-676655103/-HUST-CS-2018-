class _My_test123 {} //测试类体为空&标识符
class My_test
{

    int num;    //测试int类型
    float num_1, num_2, _dsf; //测试float类型
    class _My_test123 test_213; //测试类类型
    string str;   //测试string类型
    int[][] array; //测试数组类型
}
class Main
{
    //测试函数定义
    void test1(){}  //函数体与参数列表为空
    int test2(int a)
    {
        return 0;
    }
    int fibo(int a, string b)
    {
        if(a==1||a==2) return 1;
        return fibo(a-1)+fibo(a-2);
    }

    string str;   //测试string类型
    float[][] array; //测试数组类型


    int main()
    {
        int m,n,i;
        int[] arr;
        string s;
        class My_test temp_1;
        //测试表达式
        arr = new int[10];  //测试new语句
        temp_1 = new My_test();

        s = "alex fan";//string赋值测试
        arr[2] = 3;

        m = test2();
        m = Main.test2();

        n = -i + n;

        i++; i--; ++i; --i;

        //测试while语句 if语句 break语句 continue语句
        while(i<=m)
        {
            n=fibo(i);
            write(n);
            i=i+1;
            if(i = 5) break;
            if(i!=5) continue;
        }

        //测试for语句
        for(a=1; a<10; a++)
        {
            Scan(i, m, n);
            Print(i);
        }
        delete temp_1;
        return 1;
    }
}











