

```
1. 语言名称：Defan

2. 标识符、常数、字符串等单词的文法：
（1）标识符：ID → [A-Z a-z _][A-Z a-z 0-9 _]*
（2）常数与字符串：Constant → INT | FLOAT | CHAR
INT → ([1-9][0-9]*)|(0[xX][0-9a-fA-F]+)|(0[0-7]*)
FLOAT → [0-9]*[.][0-9]+([eE][-+]?([1-9][0-9*]|[0]))?
CHAR → \'([^'\\]|\\['"?\\abfnrtv]|\\[0-7]{1,3}|\\[Xx][0-9A-Fa-f]+)\'

3. 符号集、保留字集、运算符、界符：
（1）符号集：ASCII码集
（2）保留字集：
int float char void 
class this 
return break continue
if else for while null true false 
Print Scan
（3）运算符： + - * / % < <= > >= = == != && || ! ++ -- += -= *= /= %=
（4）界符：; , . [ ] ( ) { }

4. 说明语句文法：
Program → ClassDefList
ClassDefList → ClassDef ClassDefList | ε

ClassDef → class ID { FieldList }
FieldList → Field FieldList | ε
Field → VariableDef | FunctionDef

VariableDef → Type IDList;
IDList → ID | ID , IDList
Type → int | char | void | class ID | Type[INT]

FunctionDef → Type ID ( Formals ) StmtBlock
Formals → VariableList | ε
VariableList → Variable | Variable, VariableList
Variable → Type ID
StmtBlock → { StmtList }
StmtList → Stmt StmtList | ε
Stmt → VariableDef | SimpleStmt ; | IfStmt | WhileStmt | ForStmt | BreakStmt ; | ReturnStmt ;| PrintStmt ; | ScanStmt ;| ContinueStmt ; | StmtBlock

5. 赋值语句文法（简单赋值）：
SimpleStmt →  Expr | ε

6. 表达式求值文法（简单算术运算，包括++， --）：
Expr → Constant | Expr = Expr | this | ( Expr ) |
Expr + Expr | Expr - Expr | Expr * Expr |
Expr / Expr | Expr % Expr | - Expr |
Expr < Expr | Expr <= Expr | Expr > Expr |
Expr >= Expr | Expr == Expr | Expr != Expr |
Expr && Expr | Expr || Expr | ! Expr |
Expr ++ | Expr -- |  ++Expr | --Expr | 
| ID ( Actuals ) | Expr.ID ( Actuals )
| ID | Expr[Expr] | Expr.ID

Actuals → ExprList | ε
ExprList → Expr, ExprList | Expr
Constant → INT | FLOAT | CHAR | null | true | false

7. 分支语句文法：
IfStmt → if ( Expr ) Stmt | if ( Expr ) Stmt else Stmt

8. 循环语句文法：
ForStmt → for ( SimpleStmt ; SimpleStmt ; SimpleStmt ) Stmt
WhileStmt → while ( Expr ) Stmt
BreakStmt → break
ContinueStmt → continue

9. 输入语句、输出语句文法：
PrintStmt → Print ( Expr )
ScanStmt → Scan ( Expr )

10. 过程或函数调用语句文法：
ReturnStmt → return | return Expr

11. 语义分析产生的错误：
（1）使用未定义的变量；
（2）调用未定义或未声明的函数；
（3）在同一作用域，名称的重复定义（如变量名、函数名、结构类型名以及结构体成员名等）。为更清楚说明语义错误，这里也可以拆分成几种类型的错误，如变量重复定义、函数重复定义、结构体成员名重复等；
（4）对非函数名采用函数调用形式；
（5）对函数名采用非函数调用形式访问；
（6）函数调用时参数个数不匹配，如实参表达式个数太多、或实参表达式个数太少；
（7）函数调用时实参和形参类型不匹配；
（8）对非数组变量采用下标变量的形式访问；
（9）数组变量的下标不是整型表达式；
（10）对非结构变量采用成员选择运算符“.”；
（11）结构成员不存在；
（12）赋值号左边不是左值表达式；
（13）对非左值表达式进行自增、自减运算；
（14）对结构体变量进行自增、自减运算；
（15）类型不匹配。如数组名与结构变量名间的运算，需要指出类型不匹配错误；有些需要根据定义的语言的语义自行进行界定，比如：32+'A'，10*12.3，如果使用强类型规则，则需要报错，如果按C语言的弱类型规则，则是允许这类运算的，但需要在后续阶段需要进行类型转换，类型统一后再进行对应运算； 
（16）函数返回值类型与函数定义的返回值类型不匹配；
（17）函数没有返回语句（当函数返回值类型不是void时）；
（18）break语句不在循环语句或switch语句中；
（19）continue语句不在循环语句中；
```







