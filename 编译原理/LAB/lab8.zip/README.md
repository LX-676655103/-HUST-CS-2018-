1. 本实验基于为windows环境

2. 安装gcc、flex以及bison环境

3. 执行批处理文件 **makefile.bat**，可以根据需要修改文件

4. 安装java环境后，打开模拟器Mars4_5.jar（**mars操作参见文件夹中的图片操作**，图在help image文件夹中）

5. 使用打开文件，编译文件，设置导出代码格式，导出代码（设置为hex格式），在代码文件前加入 “v2.0 raw” 方可使用加载镜像的功能进行加载（**mars操作参见文件夹中的图片操作**）

6. 如果需要使用cpu运行，使用文件夹中的logisim打开cpu.circ，将代码加载到指令存储器中，即可运行

7. **注意：如果需要使用cpu运行请删除测试文件中的读取函数Scan，且不得使用乘除运算，该CPU不支持乘除运算**

8. 测试程序如下，测试后可以看到数码管显示数字5 0 4 1 2 3 1 4 然后停下：

   第二个测试程序为冒泡排序，效果为从小到大排序（第三个为可以读数据进行排序的版本），

   其他测试文件详见test文件夹

   ```C++
   class Point
   {
       int x,y;
       int trans(){
           int temp;
           temp = x;
           x = y;
           y = temp;
           return 0;
       }
   }
   
   class Main
   {
       int main()
       {
           int i, num_of_point;
           class Point[5] p_array;
           num_of_point = 5;
           for(i=0;i<num_of_point;i++){
               p_array[i].x=i;
               p_array[i].y=num_of_point-i;
               p_array[i].trans();
           }
           for(i=0;i<num_of_point;i++){
               Print(p_array[i].x);
               Print(p_array[i].y);
           }
           return 0;
       }
   }
   ```

   ```C++
   class Main
   {
       int main()
       {
           int i,j,length,temp;
           int[10] array;
           length=10;
           for(i=0; i<length; i++)
               array[i]=20-i;
   
           for(i=0; i<length; i++)
               Print(array[i]);
   
           for(i=0; i<length-1; i++)
               for(j=0; j<length-i-1; j++)
               if(array[j]>array[j+1]){
               temp = array[j];
               array[j] = array[j+1];
               array[j+1] = temp;
           }
           for(i=0; i<length; i++)
               Print(array[i]);
   
           return 0;
       }
   }
   
   ```

   ```C
   class Main
   {
       int main()
       {
           int i,j,length,temp;
           int[10] array;
           Scan(length);
           for(i=0; i<length; i++)
               Scan(array[i]);
   
           for(i=0; i<length-1; i++)
               for(j=0; j<length-i-1; j++)
               if(array[j]>array[j+1]){
               temp = array[j];
               array[j] = array[j+1];
               array[j+1] = temp;
           }
           for(i=0; i<length; i++)
               Print(array[i]);
           return 0;
       }
   }
   
   ```

   

