#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdarg.h"
#include "parser.tab.h"
#define MAXLENGTH   1000
#define MAX_ID_NUM  30
/*活动记录控制信息需要的单元数，这个根据实际系统调整*/
#define DX 3*sizeof(int)

int LEV;             /* 层号 */
int index_array[20]; /* 数组各维度的上限 */

struct opn{
    int kind;    //标识联合成员的属性
    int type;    //标识操作数的数据类型
    union {
        int     const_int;      //整常数值，立即数
        float   const_float;    //浮点常数值，立即数
        char    const_char;     //字符常数值，立即数
        char    id[33];         //变量或临时变量的别名或标号字符串
        };
    int level;                  //变量的层号，0表示是全局变量，数据保存在静态数据区
    int offset;                 //偏移量，目标代码生成时用
    };

struct codenode {   //三地址TAC代码结点,采用单链表存放中间语言代码
        int  op;
        struct opn opn1,opn2,result;
        struct codenode  *next,*prior;
    };


/* 语法分析树结点 */
struct ASTNode {
    struct ASTNode *ptr[4];
	int kind;  /* 结点的类型 */
	/* 存储标识符以及常数信息 */
	union {
		  char type_id[33];
		  int type_int;
		  float type_float;
          char type_char;
          char type_string[33];
	      };

    int pos; /* 语法单位所在位置行号 */
    /* 符号表相关 */
    int place;  /* 符号表的地址 */
	int type;   /* 结点表达式的类型 */
	char flag;  /* 结点表达式的类别，与符号表的类别标识相同 */
    int offset; /* 偏移量 */
    int width;  /* 占数据字节数 */
    int num;    /* 函数参数个数 */
    int col_num;      /* 数组维数 */
    int index_class;  /* 类变量的类定义符号表地址 */
    int return_flag, return_pos; /* 标识函数中是否存在返回语句 */
    /* 中间代码生成相关 */
    /* 对布尔表达式的翻译时，真假转移目标的标号 */
    char Etrue[15],Efalse[15];
    /* 结点对应语句S执行后的下一条语句位置标号 */
    char Snext[15];
    char Sbreak[15], Scontinue[15];
    /* 中间代码链表头指针 */
    struct codenode *code;
    };

/* 符号表的表项 */
struct symbol {
    char name[128];  /* 类名或变量或函数名 */
    /* 层号，类定义为0层，
        函数定义为1层，
        参数定义为2层
        */
    int level;
    /* 变量以及函数返回值的类型，
        包括int，float，char，void，class
        其中，变量不得使用void类型，函数返回类型不得是数组
        */
    int type;
    /* 存储函数参数的个数 & 数组参数或变量的维数
        index_array数组存储数组不同维度的上限
        */
    int paramnum;
    int index_array[20];
    /* 当type为class时，保存类定义在符号表中的下标 */
    int index_class;
    /* 别名，为解决嵌套层次使用 */
    char alias[10];
    /* 符号标记：
        类定义：'C'，函数：'F'，参数：'P' ，参数数组：'Q'
        变量：'V'，临时变量：'T'，数组定义：'A'
        */
    char flag;
    /* 对于类数据成员，该值表示成员相对于类的偏移，
        对于函数成员来说，该值表示函数的活动记录大小，
        对于局部变量来说，该值表示变量相对于函数栈基址的偏移
         */
    int offset;
    int is_pointer;
    };


/* 符号表 */
struct symboltable{
    struct symbol symbols[MAXLENGTH];
    int index;
    } symbolTable;

struct symbol_scope_begin {
    /* 当前作用域的符号在符号表的起始位置序号,
        是一个栈结构,当使用顺序表作为符号表时,
        进入、退出一个作用域时需要对其操作
         */
    int TX[100];
    int top;
    } symbol_scope_TX;

struct class_index {
    int TX[100];
    int index;
    } class_index;

/*generate AST*/
struct ASTNode * mknode(int num,int kind,int pos,...);

/*generate symbol table*/
char *str_catch(char *s1, char *s2);
char *strcat0(char *s1,char *s2);
char *newTemp();
char *newAlias();
void prn_symbol();
int searchSymbolTable(char *name);
int fillSymbolTable(char *name,char *alias,int level,int type,char flag,int offset);
int fill_Temp(char *name,int level,int type,char flag,int offset);

/*semantic analysis*/
void semantic_error(int line,char *msg1,char *msg2);
void boolExp(struct ASTNode *T);
void Exp(struct ASTNode *T);
void fill_array(int num, int index);
void type_find(struct ASTNode *T);
void id_list(struct ASTNode *T);
int match_param(int i,int pos,struct ASTNode *T);
void assign_op(struct ASTNode *T);
void semantic_Analysis0(struct ASTNode *T);
void semantic_Analysis(struct ASTNode *T);

/*code generate*/
char *newLabel();
struct codenode *genIR(int op, struct opn opn1, struct opn opn2, struct opn result);
struct codenode *genLabel(char *label);
struct codenode *genGoto(char *label);
struct codenode *merge(int num, ...);
void prnIR(struct codenode *head);

/*code optimize*/
int old_code, new_code;
/* DAG图结点 */
typedef struct DAG_Node{
    /* 结点类型 &
        是否是叶节点 &
        是否有效*/
    int kind;
    int is_leaf, is_valid;

    union {
        int     const_int;
        float   const_float;
        char    const_char;
    };

    /* 附加标识符个数以及下标数组 */
    int id_num;
    int id_index[MAX_ID_NUM];

    /* 子节点个数以及下标数组 */
    int child_num;
    int child_index[3];
}DAG_Node;
DAG_Node DAG[200];

/* 标识符表 */
struct ID_table{
    char name[33];
    /* 指向当前标识符附加的结点 */
    int node_index;
    int all_num;
}id_table[40];

/* 标识符表 */
struct all_table{
    char name[33];
    int is_save;
}all_table[200];

struct code_table{
    struct codenode *code;
    int id_index;
}code_table[1000];

/* 填充标识符表 & 存储结点序号 */
int fill_table(char* name, int node_num);
/* 查找标识符表，找到返回下标，否则返回-1 */
int find_id(char *name);
/* 查找常数 */
int find_int(int num);
int find_float(int num);
int find_char(int num);
/* 生成结点填充DAG图 */
int fill_DAG_graph(int kind, int is_leaf);
/* 查找结点标识符集中，是否存在下标为id_index的标识符 */
/* 查找结点标识符集中，是否存在下标为id_index的标识符 */
int find_id_dag(int node_index, int id_index);
/* 从结点标识符集中删除下标为id_index的标识符 */
int delete_id(int node_index, int id_index);
/* 找到下一个基本块的首个语句 */
struct codenode *find_block_begin(struct codenode *present);
/* 当前是否是结束语句 */
int is_block_end(struct codenode *code);
/* 创建DAG图并生成优化后的代码 */
struct codenode *creDAG_and_gencode(struct codenode* begincode);
/* DAG优化入口 */
struct codenode *DAG_optimize(struct codenode *head);
struct codenode *var_optimize();
int find_all(char *name);


void objectCode(struct codenode *head);















