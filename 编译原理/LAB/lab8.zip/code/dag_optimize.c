#include "def.h"
#define DEBUG 1
struct codenode * phead;
int max_id_num = 0, max_all_num = 0;
int max_node_num = 0;
int tac_num = 0;

/* ����ʶ���� & �洢������ */
int fill_table(char* name, int node_num)
{
    strcpy(id_table[max_id_num].name,name);
    id_table[max_id_num].node_index=node_num;
    id_table[max_id_num].all_num = find_all(name);
    return max_id_num++;
}

/* ���ұ�ʶ�������ҵ������±꣬���򷵻�-1 */
int find_id(char *name)
{
    int i;
    for(i=0; i<max_id_num; i++)
        if (!strcmp(id_table[i].name, name))
            return i;
    return -1;
}

int find_all(char *name)
{
    int i;
    for(i=0; i<max_all_num; i++)
        if (!strcmp(all_table[i].name, name))
            return i;
    strcpy(all_table[max_all_num].name,name);
    all_table[max_all_num].is_save=0;
    return max_all_num++;
}

/* ���ҳ��� */
int find_int(int num)
{
    int i;
    for(i=0; i<max_node_num; i++)
        if (DAG[i].kind==INT && DAG[i].is_valid && DAG[i].const_int==num)
            return i;
    return -1;
}
int find_float(int num)
{
    int i;
    for(i=0; i<max_node_num; i++)
        if (DAG[i].kind==FLOAT && DAG[i].is_valid && DAG[i].const_float==num)
            return i;
    return -1;
}
int find_char(int num)
{
    int i;
    for(i=0; i<max_node_num; i++)
        if (DAG[i].kind==CHAR && DAG[i].is_valid && DAG[i].const_char==num)
            return i;
    return -1;
}

/* ���ɽ�����DAGͼ */
int fill_DAG_graph(int kind, int is_leaf)
{
    DAG[max_node_num].kind=kind;
    DAG[max_node_num].is_leaf=is_leaf;
    DAG[max_node_num].is_valid=1;
    DAG[max_node_num].child_num=0;
    DAG[max_node_num].id_num=0;
    return max_node_num++;
}

/* ���ҽ���ʶ�����У��Ƿ�����±�Ϊid_index�ı�ʶ�� */
int find_id_dag(int node_index, int id_index)
{
    int i,max_length=DAG[node_index].id_num;
    for(i=0; i<max_length; i++)
        if(DAG[node_index].id_index[i]==id_index)
            return i;
    return -1;
}

/* �ӽ���ʶ������ɾ���±�Ϊid_index�ı�ʶ�� */
int delete_id(int node_index, int id_index)
{
    int i,max_length=DAG[node_index].id_num;
    for(i=0; i<max_length; i++)
        if(DAG[node_index].id_index[i]==id_index)
            break;
    if(i < max_length)
    {
        for(; i<max_length-1; i++)
            DAG[node_index].id_index[i] = DAG[node_index].id_index[i+1];
        DAG[node_index].id_num--;
        return 1;
    }
    return 0;
}


/* �ҵ���һ����������׸���� */
struct codenode *find_block_begin(struct codenode *present)
{
    if(!present) return NULL;
    struct codenode *h = present;
    while(1)
    {
        switch (h->op)
        {
        /* ת������Ŀ����� | �����ĵ�һ����� */
        case LABEL:case FUNCTION:
            return h;
        /* ����ת�����ĺ�һ�� */
        case JLE:case JLT:case JGE:
        case JGT:case EQ:case NEQ:
            if(h->next!=present)
                return h->next;
        default: break;
        }
        h = h->next;
        if(h == present)  return present;
    }
    return NULL;
}

/* ��ǰ�Ƿ��ǽ������ */
int is_block_end(struct codenode *code)
{
    if(!code) return -1;
    /* ֹͣ������ */
    if(code->next == phead) return 1;
    /* ���֮ǰ����� */
    if(code->next->op == LABEL || code->next->op == FUNCTION) return 1;
    switch(code->op)
    {
    /* ������ & ����ת����� & �������*/
    case GOTO: case RETURN:
    case JLE:case JLT:case JGE:
    case JGT:case EQ:case NEQ:
        return 1;
    default: break;
    }
    return 0;
}


/* ����DAGͼ�������Ż���Ĵ��� */
struct codenode *creDAG_and_gencode(struct codenode* begincode)
{
    int rtn, i, j, temp_kind;
    int A_id_index, A_node_index;
    int B_id_index, B_node_index;
    int C_id_index, C_node_index;
    struct opn opn1, opn2, result;
    /* ����ʶ���� & DAGͼ��� */
    max_node_num = 0;
    max_id_num = 0;
    struct codenode *newcode=NULL, *h=begincode;
    if(!begincode) return NULL;

    /* ����DAGͼ */
    while(1)
    {
        old_code++;
        /* DAG��㴦�� */
        /* 0����Ԫʽ A:=B ���� */
        if(h->op == ASSIGNOP)
        {
            /* B Ϊ���� */
            if (h->opn1.kind == INT){
                B_id_index = find_int(h->opn1.const_int);
                /* ������ */
                if(B_id_index==-1){
                    B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                    DAG[B_node_index].const_int = h->opn1.const_int;
                }else B_node_index = B_id_index;
            }
            if (h->opn1.kind == CHAR){
                B_id_index = find_int(h->opn1.const_char);
                /* ������ */
                if(B_id_index==-1){
                    B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                    DAG[B_node_index].const_char = h->opn1.const_char;
                }else B_node_index = B_id_index;
            }
            if (h->opn1.kind == FLOAT){
                B_id_index = find_int(h->opn1.const_float);
                /* ������ */
                if(B_id_index==-1){
                    B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                    DAG[B_node_index].const_float = h->opn1.const_float;
                }else B_node_index = B_id_index;
            }

            /* B Ϊ��ʶ�� */
            if (h->opn1.kind == ID){
                B_id_index = find_id(h->opn1.id);
                /* ��ʶ�� B �����ڣ�������ʶ����������һ��Ҷ��� */
                if(B_id_index==-1){
                    B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                    B_id_index = fill_table(h->opn1.id, B_node_index);
                    DAG[B_node_index].id_index[DAG[B_node_index].id_num++]=B_id_index;
                }
                else B_node_index = id_table[B_id_index].node_index;
            }

            A_id_index = find_id(h->result.id);
            /* ��ʶ�� A δ���� */
            if(A_id_index==-1){
                /* ������ʶ�� A
                    ����ʶ�� A ���ӵ���� B �� */
                A_id_index = fill_table(h->result.id, B_node_index);
                DAG[B_node_index].id_index[DAG[B_node_index].id_num++]=A_id_index;
            }
            /* ��д�������˲�Ϊͬһ����ʶ�� */
            else if((h->opn1.kind == ID && A_id_index != B_id_index)
                    || h->opn1.kind != ID){
                /* ����ʶ����ʶ����������1ʱ��ɾ����ʶ�� A */
                if(DAG[id_table[A_id_index].node_index].id_num > 1)
                    delete_id(id_table[A_id_index].node_index, A_id_index);
                /* ����ʶ�� A ���ӵ���� B ��
                    ����ʶ��NODE(A)ָ���� B */
                DAG[B_node_index].id_index[DAG[B_node_index].id_num++]=A_id_index;
                id_table[A_id_index].node_index = B_node_index;
            }
        }

        /* 1����Ԫʽ A:= op B ���� */
        /* ֻ���� *= �Լ� =* �������㣬����������� */
        if(h->op == POINT_EXP || h->op == EXP_POINT)
        {
            int gen_flag = 0;  /* �Ƿ�����A��־ */
            B_id_index = find_id(h->opn1.id);
            if(B_id_index==-1)
            {
                B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                B_id_index = fill_table(h->opn1.id, B_node_index);
                DAG[B_node_index].id_index[DAG[B_node_index].id_num++]=B_id_index;
                gen_flag = 1;
            }
            else{
                B_node_index = id_table[B_id_index].node_index;
                /* ���ҹ����ӱ���ʽ����
                    ��ѯ������̽��ΪB & ������뵱ǰ��ͬ */
                for(i=0; i<max_node_num; i++)
                    if(DAG[i].child_num==1 && DAG[i].kind==h->op
                       && DAG[i].child_index[0]==B_node_index){
                        A_node_index = i;
                        break;
                    }
                if(i>=max_node_num) gen_flag = 1;
            }
            /* ������A */
            if(gen_flag){
                A_node_index = fill_DAG_graph(h->op, 0);
                DAG[A_node_index].child_index[DAG[A_node_index].child_num++] = B_node_index;
            }

            A_id_index = find_id(h->result.id);
            /* ��ʶ�� A δ���� */
            if(A_id_index==-1)
            {
                /* ������ʶ�� A */
                A_id_index = fill_table(h->result.id, A_node_index);
                DAG[A_node_index].id_index[DAG[A_node_index].id_num++]=A_id_index;
            }
            else
            {
                if(find_id_dag(A_node_index, A_id_index)==-1)
                {
                    /* ����ʶ����ʶ����������1ʱ��ɾ����ʶ�� A */
                    if(DAG[id_table[A_id_index].node_index].id_num > 1 && h->op == EXP_POINT)
                        delete_id(id_table[A_id_index].node_index, A_id_index);
                    DAG[A_node_index].id_index[DAG[A_node_index].id_num++]=A_id_index;
                    if(h->op == EXP_POINT) id_table[A_id_index].node_index = A_node_index;
                }
            }
        }

        /* 2����Ԫʽ A:= B op C ���� */
        if(h->op == PLUS || h->op == MINUS || h->op == STAR|| h->op == DIV
           || h->op == MOD || h->op == JLE || h->op == JLT || h->op == JGE
           || h->op == JGT || h->op == EQ || h->op == NEQ)
        {
            int gen_flag = 0;  /* �Ƿ�����A��־ */
            int B_new_flag = 0, C_new_flag = 0;

            /* B Ϊ���� */
            if (h->opn1.kind == INT){
                B_id_index = find_int(h->opn1.const_int);
                /* ������ */
                if(B_id_index==-1){
                    B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                    DAG[B_node_index].const_int = h->opn1.const_int;
                    gen_flag = 1;
                    B_new_flag=1;
                }
                else B_node_index = B_id_index;
            }
            if (h->opn1.kind == CHAR){
                B_id_index = find_int(h->opn1.const_char);
                /* ������ */
                if(B_id_index==-1){
                    B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                    DAG[B_node_index].const_char = h->opn1.const_char;
                    gen_flag = 1;
                    B_new_flag=1;
                }
                else B_node_index = B_id_index;
            }
            if (h->opn1.kind == FLOAT){
                B_id_index = find_int(h->opn1.const_float);
                /* ������ */
                if(B_id_index==-1){
                    B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                    DAG[B_node_index].const_float = h->opn1.const_float;
                    gen_flag = 1;
                    B_new_flag=1;
                }
                else B_node_index = B_id_index;
            }

            /* B Ϊ��ʶ�� */
            if (h->opn1.kind == ID){
                B_id_index = find_id(h->opn1.id);
                /* ��ʶ�� B �����ڣ�������ʶ����������һ��Ҷ��� */
                if(B_id_index==-1){
                    B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                    B_id_index = fill_table(h->opn1.id, B_node_index);
                    DAG[B_node_index].id_index[DAG[B_node_index].id_num++]=B_id_index;
                    gen_flag = 1;
                    B_new_flag=1;
                }
                else B_node_index = id_table[B_id_index].node_index;
            }

            /* C Ϊ���� */
            if (h->opn2.kind == INT){
                C_id_index = find_int(h->opn2.const_int);
                /* ������ */
                if(C_id_index==-1){
                    C_node_index = fill_DAG_graph(h->opn2.kind, 1);
                    DAG[C_node_index].const_int = h->opn2.const_int;
                    gen_flag = 1;
                    C_new_flag=1;
                }
                else C_node_index = C_id_index;
            }
            if (h->opn2.kind == CHAR){
                C_id_index = find_int(h->opn2.const_char);
                /* ������ */
                if(C_id_index==-1){
                    C_node_index = fill_DAG_graph(h->opn2.kind, 1);
                    DAG[C_node_index].const_char = h->opn2.const_char;
                    gen_flag = 1;
                    C_new_flag=1;
                }
                else C_node_index = C_id_index;
            }
            if (h->opn2.kind == FLOAT){
                C_id_index = find_int(h->opn2.const_float);
                /* ������ */
                if(C_id_index==-1){
                    C_node_index = fill_DAG_graph(h->opn2.kind, 1);
                    DAG[C_node_index].const_float = h->opn2.const_float;
                    gen_flag = 1;
                    C_new_flag=1;
                }
                else C_node_index = C_id_index;
            }

            /* C Ϊ��ʶ�� */
            if (h->opn2.kind == ID)
            {
                C_id_index = find_id(h->opn2.id);
                if(C_id_index==-1)
                {
                    C_node_index = fill_DAG_graph(h->opn2.kind, 1);
                    C_id_index = fill_table(h->opn2.id, C_node_index);
                    DAG[C_node_index].id_index[DAG[C_node_index].id_num++]=C_id_index;
                    gen_flag = 1;
                    C_new_flag=1;
                }
                else C_node_index = id_table[C_id_index].node_index;
            }

            if(DAG[B_node_index].kind==INT && DAG[C_node_index].kind==INT)
            {
                /* �ϲ���֪�� */
                int result_num;
                if(h->op==PLUS || h->op==MINUS || h->op==STAR|| h->op==DIV || h->op==MOD)
                {
                    gen_flag = 0;
                    switch(h->op)
                    {
                        case PLUS: result_num = DAG[B_node_index].const_int + DAG[C_node_index].const_int; break;
                        case MINUS: result_num = DAG[B_node_index].const_int - DAG[C_node_index].const_int; break;
                        case STAR: result_num = DAG[B_node_index].const_int * DAG[C_node_index].const_int; break;
                        case DIV: result_num = DAG[B_node_index].const_int / DAG[C_node_index].const_int; break;
                        case MOD: result_num = DAG[B_node_index].const_int % DAG[C_node_index].const_int; break;
                    }
                    A_id_index = find_int(result_num);
                    /* ������ */
                    if(A_id_index==-1)
                    {
                        A_node_index = fill_DAG_graph(INT, 1);
                        DAG[A_node_index].const_int = result_num;
                    }
                }
            }
            else
            {
                /* ���ҹ����ӱ���ʽ */
                /* ���ҹ����ӱ���ʽ����
                    ��ѯ������̽��ΪB & ������뵱ǰ��ͬ */
                for(i=0; i<max_node_num; i++)
                    if(DAG[i].child_num==2 && DAG[i].kind==h->op
                       && DAG[i].child_index[0]==B_node_index
                       && DAG[i].child_index[1]==C_node_index){
                        A_node_index = i;
                        break;
                    }
                if(i>=max_node_num) gen_flag = 1;
            }

            /* ������A */
            if(gen_flag){
                A_node_index = fill_DAG_graph(h->op, 0);
                DAG[A_node_index].child_index[DAG[A_node_index].child_num++] = B_node_index;
                DAG[A_node_index].child_index[DAG[A_node_index].child_num++] = C_node_index;
            }

            A_id_index = find_id(h->result.id);
            /* ��ʶ�� A δ���� */
            if(A_id_index==-1){
                /* ������ʶ�� A */
                A_id_index = fill_table(h->result.id, A_node_index);
                DAG[A_node_index].id_index[DAG[A_node_index].id_num++]=A_id_index;
            }
            else
            {
                if(find_id_dag(A_node_index, A_id_index)==-1)
                {
                    /* ����ʶ����ʶ����������1ʱ��ɾ����ʶ�� A */
                    if(DAG[id_table[A_id_index].node_index].id_num > 1)
                        delete_id(id_table[A_id_index].node_index, A_id_index);
                    DAG[A_node_index].id_index[DAG[A_node_index].id_num++]=A_id_index;
                    id_table[A_id_index].node_index = A_node_index;
                }
            }
        }

        /* ����������� */
        if(h->op==CALL)
        {
            B_id_index = find_id(h->opn1.id);
            if(B_id_index==-1)
            {
                B_node_index = fill_DAG_graph(h->opn1.kind, 1);
                B_id_index = fill_table(h->opn1.id, B_node_index);
                DAG[B_node_index].id_index[DAG[B_node_index].id_num++]=B_id_index;
            }
            A_node_index = fill_DAG_graph(h->op, 0);
            A_id_index = find_id(h->result.id);
            if(A_id_index==-1){
                /* ������ʶ�� A */
                A_id_index = fill_table(h->result.id, A_node_index);
                DAG[A_node_index].id_index[DAG[A_node_index].id_num++]=A_id_index;
            }
            DAG[A_node_index].child_index[DAG[A_node_index].child_num++] = B_node_index;
        }

        if(h->op==FUNCTION || h->op==PARAM || h->op==ARG
           || h->op==GOTO || h->op==LABEL || h->op==RETURN)
        {
            /* B Ϊ��ʶ�� */
            B_id_index = find_id(h->result.id);
            if(B_id_index==-1)
            {
                B_node_index = fill_DAG_graph(h->result.kind, 1);
                B_id_index = fill_table(h->result.id, B_node_index);
                DAG[B_node_index].id_index[DAG[B_node_index].id_num++]=B_id_index;
            }
            else B_node_index = id_table[B_id_index].node_index;
            A_node_index = fill_DAG_graph(h->op, 0);
            DAG[A_node_index].child_index[DAG[A_node_index].child_num++] = B_node_index;
        }

        /* �����ǰ���Ϊ������䣬�������� */
        if(is_block_end(h)==1) break;
        h = h->next;
    }
    /* �������ɴ��� */
    for(i=0; i<max_node_num; i++)
    {
        if(!DAG[i].is_valid) continue;
        switch (DAG[i].kind)
        {
        case INT:
            for(j=0; j<DAG[i].id_num; j++)
            {
                opn1.kind = INT;
                opn1.const_int = DAG[i].const_int;
                result.kind = ID;
                strcpy(result.id, id_table[DAG[i].id_index[j]].name);
                newcode = merge(2, newcode, genIR(ASSIGNOP, opn1, opn2, result));

                #if(DEBUG)
                code_table[tac_num].id_index=id_table[DAG[i].id_index[j]].all_num;
                code_table[tac_num++].code = genIR(ASSIGNOP, opn1, opn2, result);
                #endif
            }
            break;
        case FLOAT:
            for(j=0; j<DAG[i].id_num; j++)
            {
                opn1.kind = FLOAT;
                opn1.const_int = DAG[i].const_float;
                result.kind = ID;
                strcpy(result.id, id_table[DAG[i].id_index[j]].name);
                newcode = merge(2, newcode, genIR(ASSIGNOP, opn1, opn2, result));

                #if(DEBUG)
                code_table[tac_num].id_index=id_table[DAG[i].id_index[j]].all_num;
                code_table[tac_num++].code = genIR(ASSIGNOP, opn1, opn2, result);
                #endif
            }
            break;
        case CHAR:
            for(j=0; j<DAG[i].id_num; j++)
            {
                opn1.kind = CHAR;
                opn1.const_int = DAG[i].const_char;
                result.kind = ID;
                strcpy(result.id, id_table[DAG[i].id_index[j]].name);
                newcode = merge(2, newcode, genIR(ASSIGNOP, opn1, opn2, result));

                #if(DEBUG)
                code_table[tac_num].id_index=id_table[DAG[i].id_index[j]].all_num;
                code_table[tac_num++].code = genIR(ASSIGNOP, opn1, opn2, result);
                #endif
            }
            break;
        case ID:
            for(j=1; j<DAG[i].id_num; j++)
            {
                opn1.kind = ID;
                strcpy(opn1.id, id_table[DAG[i].id_index[0]].name);
                result.kind = ID;
                strcpy(result.id, id_table[DAG[i].id_index[j]].name);
                newcode = merge(2, newcode, genIR(ASSIGNOP, opn1, opn2, result));

                #if(DEBUG)
                all_table[id_table[DAG[i].id_index[0]].all_num].is_save=1;
                code_table[tac_num].id_index=id_table[DAG[i].id_index[j]].all_num;
                code_table[tac_num++].code = genIR(ASSIGNOP, opn1, opn2, result);
                #endif
            }
            break;
        case JLE:case JLT:case JGE:case JGT:case EQ:case NEQ:
        case PLUS:case MINUS:case STAR:case DIV:case MOD:
            temp_kind = DAG[DAG[i].child_index[0]].kind;
            if(temp_kind==INT || temp_kind==FLOAT || temp_kind==CHAR)
            {
                opn1.kind = temp_kind;
                if(temp_kind==INT) opn1.const_int = DAG[DAG[i].child_index[0]].const_int;
                if(temp_kind==FLOAT) opn1.const_float = DAG[DAG[i].child_index[0]].const_float;
                if(temp_kind==CHAR) opn1.const_char = DAG[DAG[i].child_index[0]].const_char;
            }
            else{
                opn1.kind = ID;
                strcpy(opn1.id, id_table[DAG[DAG[i].child_index[0]].id_index[0]].name);
                all_table[id_table[DAG[DAG[i].child_index[0]].id_index[0]].all_num].is_save=1;
            }

            temp_kind = DAG[DAG[i].child_index[1]].kind;
            if(temp_kind==INT || temp_kind==FLOAT || temp_kind==CHAR)
            {
                opn2.kind = temp_kind;
                if(temp_kind==INT) opn2.const_int = DAG[DAG[i].child_index[1]].const_int;
                if(temp_kind==FLOAT) opn2.const_float = DAG[DAG[i].child_index[1]].const_float;
                if(temp_kind==CHAR) opn2.const_char = DAG[DAG[i].child_index[1]].const_char;
            }
            else{
                opn2.kind = ID;
                strcpy(opn2.id, id_table[DAG[DAG[i].child_index[1]].id_index[0]].name);
                all_table[id_table[DAG[DAG[i].child_index[1]].id_index[0]].all_num].is_save=1;
            }
            result.kind = ID;
            strcpy(result.id, id_table[DAG[i].id_index[0]].name);
            newcode = merge(2, newcode, genIR(DAG[i].kind, opn1, opn2, result));

            #if(DEBUG)
            code_table[tac_num].id_index=id_table[DAG[i].id_index[0]].all_num;
            code_table[tac_num++].code = genIR(DAG[i].kind, opn1, opn2, result);
            #endif

            for(j=1; j<DAG[i].id_num; j++)
            {
                opn1.kind = ID;
                strcpy(opn1.id, id_table[DAG[i].id_index[0]].name);
                result.kind = ID;
                strcpy(result.id, id_table[DAG[i].id_index[j]].name);
                newcode = merge(2, newcode, genIR(ASSIGNOP, opn1, opn2, result));
                #if(DEBUG)
                all_table[id_table[DAG[i].id_index[0]].all_num].is_save=1;
                code_table[tac_num].id_index=id_table[DAG[i].id_index[j]].all_num;
                code_table[tac_num++].code = genIR(ASSIGNOP, opn1, opn2, result);
                #endif
            }
            break;

        case FUNCTION: case PARAM: case LABEL:case GOTO:
            result.kind = ID;
            strcpy(result.id, id_table[DAG[DAG[i].child_index[0]].id_index[0]].name);
            newcode = merge(2, newcode, genIR(DAG[i].kind, opn1, opn2, result));
            #if(DEBUG)
            code_table[tac_num++].code = genIR(DAG[i].kind, opn1, opn2, result);
            #endif
            break;

        case RETURN: case ARG:
            temp_kind = DAG[DAG[i].child_index[0]].kind;
            if(temp_kind==INT || temp_kind==FLOAT || temp_kind==CHAR)
            {
                result.kind = temp_kind;
                if(temp_kind==INT) result.const_int = DAG[DAG[i].child_index[0]].const_int;
                if(temp_kind==FLOAT) result.const_float = DAG[DAG[i].child_index[0]].const_float;
                if(temp_kind==CHAR) result.const_char = DAG[DAG[i].child_index[0]].const_char;
            }
            else{
                result.kind = ID;
                strcpy(result.id, id_table[DAG[DAG[i].child_index[0]].id_index[0]].name);
                all_table[id_table[DAG[DAG[i].child_index[0]].id_index[0]].all_num].is_save=1;
                code_table[tac_num].id_index=id_table[DAG[DAG[i].child_index[0]].id_index[0]].all_num;
            }
            newcode = merge(2, newcode, genIR(DAG[i].kind, opn1, opn2, result));
            #if(DEBUG)
            code_table[tac_num++].code = genIR(DAG[i].kind, opn1, opn2, result);
            #endif
        break;

        case CALL:case EXP_POINT:case POINT_EXP:
            opn1.kind = ID;
            strcpy(opn1.id, id_table[DAG[DAG[i].child_index[0]].id_index[0]].name);
            result.kind = ID;
            strcpy(result.id, id_table[DAG[i].id_index[0]].name);
            newcode = merge(2, newcode, genIR(DAG[i].kind, opn1, opn2, result));
            #if(DEBUG)
            if(DAG[i].kind==POINT_EXP)  all_table[id_table[DAG[i].id_index[0]].all_num].is_save=1;
            all_table[id_table[DAG[DAG[i].child_index[0]].id_index[0]].all_num].is_save=1;

            code_table[tac_num].id_index=id_table[DAG[i].id_index[0]].all_num;
            code_table[tac_num++].code = genIR(DAG[i].kind, opn1, opn2, result);
            #endif
            for(j=1; j<DAG[i].id_num; j++)
            {
                opn1.kind = ID;
                strcpy(opn1.id, id_table[DAG[i].id_index[0]].name);
                result.kind = ID;
                strcpy(result.id, id_table[DAG[i].id_index[j]].name);
                newcode = merge(2, newcode, genIR(ASSIGNOP, opn1, opn2, result));
                #if(DEBUG)
                code_table[tac_num].id_index=id_table[DAG[i].id_index[j]].all_num;
                all_table[id_table[DAG[i].id_index[0]].all_num].is_save=1;
                code_table[tac_num++].code = genIR(ASSIGNOP, opn1, opn2, result);
                #endif
            }
            break;

        }
    }
    return newcode;
}

/* ɾ��δ���ñ��� */
struct codenode *var_optimize()
{
    int i;
    struct codenode *newcode=NULL;
    #if(DEBUG)
    for(i=0; i<tac_num; i++)
    {
        switch (code_table[i].code->op)
        {
        case ASSIGNOP:
            if(all_table[code_table[i].id_index].is_save)
                newcode = merge(2, newcode, code_table[i].code),new_code++;
            break;

        case JLE:case JLT:case JGE:case JGT:case EQ:case NEQ:
            newcode = merge(2, newcode, code_table[i].code);
            new_code++;
            break;
        case PLUS:case MINUS:case STAR:case DIV:case MOD:
            if(all_table[code_table[i].id_index].is_save)
                newcode = merge(2, newcode, code_table[i].code),new_code++;
            break;

        case FUNCTION: case PARAM: case LABEL:case GOTO: case RETURN: case ARG:case POINT_EXP: case CALL:
            newcode = merge(2, newcode, code_table[i].code),new_code++;
            break;

        case EXP_POINT:
            if(all_table[code_table[i].id_index].is_save)
                newcode = merge(2, newcode, code_table[i].code),new_code++;
            break;
        }
    }
    #endif
    return newcode;
}


/* DAG�Ż���� */
struct codenode *DAG_optimize(struct codenode *head)
{
    struct codenode *newcode=NULL;
    struct codenode *h=head; phead = head;
    while(1)
    {
        newcode = merge(2, newcode, creDAG_and_gencode(h));
        h=find_block_begin(h->next);
        if(h==head) break;
    }
    return newcode;
    //return var_optimize();
}
