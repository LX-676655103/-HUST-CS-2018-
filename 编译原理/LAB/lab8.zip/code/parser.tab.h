
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     INT = 258,
     FLOAT = 259,
     CHAR = 260,
     ID = 261,
     RELOP = 262,
     TYPE = 263,
     ERRORID = 264,
     NULL_P = 265,
     TRUE = 266,
     FALSE = 267,
     VOID = 268,
     BOOL = 269,
     CLASS = 270,
     THIS = 271,
     BREAK = 272,
     CONTINUE = 273,
     RETURN = 274,
     IF = 275,
     ELSE = 276,
     WHILE = 277,
     FOR = 278,
     PRINT = 279,
     SCAN = 280,
     ASSIGNOP = 281,
     PLUS = 282,
     MINUS = 283,
     STAR = 284,
     DIV = 285,
     MOD = 286,
     AND = 287,
     OR = 288,
     NOT = 289,
     AUTOPLUS = 290,
     AUTOMINUS = 291,
     PLUSASSIGNOP = 292,
     MINUSASSIGNOP = 293,
     STARASSIGNOP = 294,
     DIVASSIGNOP = 295,
     MODASSIGNOP = 296,
     DOT = 297,
     SEMI = 298,
     COMMA = 299,
     LP = 300,
     RP = 301,
     LC = 302,
     RC = 303,
     LB = 304,
     RB = 305,
     EOL = 306,
     CLASS_DEF_LIST = 307,
     CLASS_DEF = 308,
     FIELD_LIST = 309,
     VAR_DEF = 310,
     FUNC_DEF = 311,
     TYPE_COL = 312,
     VAR_DEF_LIST = 313,
     ID_DEF_LIST = 314,
     FUNC_DEF_ACT = 315,
     FORMALS_DEF = 316,
     VAR_DEF_S = 317,
     STMT_BLOCK = 318,
     STMT_LIST = 319,
     PRINT_STMT = 320,
     SCAN_STMT = 321,
     RETURN_EXP = 322,
     IF_STMT = 323,
     IF_ELSE_STMT = 324,
     FOR_STMT = 325,
     WHILE_STMT = 326,
     BREAK_STMT = 327,
     CONTINUE_STMT = 328,
     EXP_EXP = 329,
     EXP_ID = 330,
     ID_ACTUALS = 331,
     EXP_ID_ACTUALS = 332,
     ACTUALS = 333,
     EXP_LIST = 334,
     DELETE_ID = 335,
     DELETE_EXP_ID = 336,
     FUNCTION = 337,
     PARAM = 338,
     ARG = 339,
     LABEL = 340,
     GOTO = 341,
     JLT = 342,
     JLE = 343,
     JGT = 344,
     JGE = 345,
     EQ = 346,
     NEQ = 347,
     CALL = 348,
     EXP_POINT = 349,
     POINT_EXP = 350,
     NEW = 351,
     UMINUS = 352
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 19 "parser.y"

	int    type_int;
	float  type_float;
	char   type_id[32];
                char   type_string[128];
	struct ASTNode *ptr;



/* Line 1676 of yacc.c  */
#line 159 "parser.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;

