class Main
{
    int main()
    {
        int i,j,length,temp;
        int[10] array;
        Scan(length);
        for(i=0; i<length; i++)
            Scan(array[i]);

        for(i=0; i<length-1; i++)
            for(j=0; j<length-i-1; j++)
            if(array[j]>array[j+1]){
            temp = array[j];
            array[j] = array[j+1];
            array[j+1] = temp;
        }
        for(i=0; i<length; i++)
            Print(array[i]);

        return 0;
    }
}









