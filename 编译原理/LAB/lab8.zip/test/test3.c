class Main
{
    int main()
    {
        int i,j,k;
        int[5][5][5] array;
        for(i=0; i<5; i++)
          for(j=0; j<5; j++)
            for(k=0; k<5; k++)
            {
                array[i][j][k] = i*2+j*3+k*4;
                Print(array[i][j][k]);
            }
        return 0;
    }
}









