class Point
{
    int x,y;
    int trans()
    {
        int temp;
        temp = x; x = y; y = temp;
        return 0;
    }
}

class Main
{
    int main()
    {
        int i, num_of_point;
        class Point[5] p_array;
        Scan(num_of_point);
        for(i=0;i<num_of_point;i++)
        {
            Scan(p_array[i].x);
            Scan(p_array[i].y);
            p_array[i].trans();
        }
        for(i=0;i<num_of_point;i++){
            Print(p_array[i].x); Print(p_array[i].y);
        }
        return 0;
    }
}









