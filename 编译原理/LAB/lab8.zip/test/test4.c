class Fibo
{
    int fibo(int a)
    {
        if(a==1||a==2) return 1;
        return fibo(a-1)+fibo(a-2);
    }
}
class Main
{
    int num,i;
    class Fibo f;
    int main()
    {
        Scan(num);
        for(i=1;i<num;i++)
            Print(f.fibo(i));
        return 0;
    }
}









