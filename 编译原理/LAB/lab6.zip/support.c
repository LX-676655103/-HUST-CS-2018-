#include "def.h"

char *strcat0(char *s1,char *s2)
{
    static char result[10];
    strcpy(result,s1);
    strcat(result,s2);
    return result;
}

char *str_catch(char *s1, char *s2)
{
    static char result[10];
    strcpy(result, s1);
    strcat(result, s2);
    return result;
}

char *newTemp()
{
    static int no = 1;
    char s[10];
    snprintf(s, 10, "%d", no++);
    return str_catch("temp", s);
}

/* 生成新的标识符别名 */
char *newAlias()
{
    static int no=1;
    char s[10];
    itoa(no++,s,10);
    return strcat0("v",s);
}

/* 显示错误信息 */
void semantic_error(int line,char *msg1,char *msg2)
{
    printf("在%d行,%s %s\n",line,msg1,msg2);
}

/* 打印符号表 */
void prn_symbol() {
	int i = 0;
	printf("----------------------------------------------------------------------------------\n");
	printf("|                               Symbol Table                                     |\n");
	printf("----------------------------------------------------------------------------------\n");
	printf("|       %-18s|  %-6s  | %-4s |\t%s\t|%s|%s|%s|%s|\n", "变量名",  "别名", "层号", "类型", "类索引", "维数","标 记","偏移量");
	printf("----------------------------------------------------------------------------------\n");

	for (i = 0; i < symbolTable.index; ++i) {
		if (!strcmp(symbolTable.symbols[i].name, " "))
			continue;
		printf("| %-20s ", symbolTable.symbols[i].name);
		printf("| %-7s", symbolTable.symbols[i].alias);
		printf("|  %-3d ", symbolTable.symbols[i].level);
		switch (symbolTable.symbols[i].type)
		{
		case INT:
			if (symbolTable.symbols[i].flag != 'A'&&symbolTable.symbols[i].flag != 'Q')
				printf("|\t%s\t", "int");
			else printf("|\t%s\t", "int[]");
			break;
		case FLOAT:
			if (symbolTable.symbols[i].flag != 'A'&&symbolTable.symbols[i].flag != 'Q')
				printf("|\t%s\t", "float");
			else printf("|\t%s\t","float[]");
			break;
		case CHAR:
			if (symbolTable.symbols[i].flag != 'A'&&symbolTable.symbols[i].flag != 'Q')
				printf("|\t%s\t", "char");
			else printf("|\t%s\t", "char[]");
			break;
        case CLASS:
            if (symbolTable.symbols[i].flag != 'A'&&symbolTable.symbols[i].flag != 'Q')
				printf("|\t%s\t", "class");
			else printf("|\t%s\t", "class[]");
			break;
        case VOID: printf("|\t%s\t", "void"); break;
		case NULL_P: printf("|\t%s\t", "null"); break;
        case TRUE:printf("|\t%s\t", "bool"); break;
        case FALSE:printf("|\t%s\t", "bool"); break;
		default:printf("|\t%s\t", "");
			break;
		}
		if(symbolTable.symbols[i].type==CLASS)
            printf("|  %-3d ", (symbolTable.symbols[i].index_class));
        else printf("|      " );
        if(symbolTable.symbols[i].paramnum > 0)
            printf("| %-3d", (symbolTable.symbols[i].paramnum));
        else printf("|    ");
		printf("|  %c  ", (symbolTable.symbols[i].flag));
		/*if (symbolTable.symbols[i].flag == 'F')
			printf("%s %d\t|\n", "Func panramnum:", symbolTable.symbols[i].paramnum);
		else*/
			printf("| %-4d |\n",symbolTable.symbols[i].offset);
	}
	printf("----------------------------------------------------------------------------------\n");
}

/* 生成新的标签 */
char *newLabel()
{
	static int no = 1;
	char s[10];
	//itoa(no++, s, 10);
	snprintf(s, 10, "%d", no++);
	return strcat0("label", s);
}

/* 生成一条TAC代码的结点组成的双向循环链表，返回头指针 */
struct codenode *genIR(int op, struct opn opn1, struct opn opn2, struct opn result)
{
	struct codenode *h = (struct codenode *)malloc(sizeof(struct codenode));
	h->op = op;
	h->opn1 = opn1;
	h->opn2 = opn2;
	h->result = result;
	h->next = h->prior = h;
	return h;
}

/* 生成一条标号语句，返回头指针 */
struct codenode *genLabel(char *label)
{
	struct codenode *h = (struct codenode *)malloc(sizeof(struct codenode));
	h->op = LABEL;
	strcpy(h->result.id, label);
	h->next = h->prior = h;
	return h;
}

/* 生成GOTO语句，返回头指针 */
struct codenode *genGoto(char *label)
{
	struct codenode *h = (struct codenode *)malloc(sizeof(struct codenode));
	h->op = GOTO;
	strcpy(h->result.id, label);
	h->next = h->prior = h;
	return h;
}

/* 合并多个中间代码的双向循环链表，首尾相连 */
struct codenode *merge(int num, ...)
{
	struct codenode *h1, *h2, *p, *t1, *t2;
	va_list ap;
	va_start(ap, num);
	h1 = va_arg(ap, struct codenode *);
	while (--num > 0)
	{
		h2 = va_arg(ap, struct codenode *);
		if (h1 == NULL)
			h1 = h2;
		else if (h2)
		{
			t1 = h1->prior;
			t2 = h2->prior;
			t1->next = h2;
			t2->next = h1;
			h1->prior = t2;
			h2->prior = t1;
		}
	}
	va_end(ap);
	return h1;
}

/* 输出中间代码 */
void prnIR(struct codenode *head)
{
    char opnstr1[32], opnstr2[32], resultstr[32];
    struct codenode *h = head;
    if(h) {
        do
        {
            if (h->opn1.kind == INT) sprintf(opnstr1, "#%d", h->opn1.const_int);
            if (h->opn1.kind == CHAR) sprintf(opnstr1, "#%c", h->opn1.const_char);
            if (h->opn1.kind == FLOAT) sprintf(opnstr1, "#%f", h->opn1.const_float);
            if (h->opn1.kind == ID) sprintf(opnstr1, "%s", h->opn1.id);
            if (h->opn2.kind == INT) sprintf(opnstr2, "#%d", h->opn2.const_int);
            if (h->opn2.kind == CHAR) sprintf(opnstr2, "#%c", h->opn2.const_char);
            if (h->opn2.kind == FLOAT) sprintf(opnstr2, "#%f", h->opn2.const_float);
            if (h->opn2.kind == ID) sprintf(opnstr2, "%s", h->opn2.id);
            sprintf(resultstr, "%s", h->result.id);
            switch (h->op)
            {
            case ASSIGNOP: printf("  %s := %s\n", resultstr, opnstr1); break;
            case PLUS: case MINUS: case STAR: case DIV: case MOD:
                printf("  %s := %s %c %s\n", resultstr, opnstr1,
                    h->op == PLUS ? '+' : h->op == MINUS ? '-' : h->op == STAR ? '*' : h->op == DIV ? '\\' : '%', opnstr2);
                break;
            case FUNCTION: printf("\nFUNCTION %s :\n", h->result.id); break;
            case PARAM: printf("  PARAM %s\n", h->result.id); break;
            case LABEL: printf("LABEL %s :\n", h->result.id); break;
            case GOTO: printf("  GOTO %s\n", h->result.id); break;
            case JLE: printf("  IF %s <= %s GOTO %s\n", opnstr1, opnstr2, resultstr); break;
            case JLT: printf("  IF %s < %s GOTO %s\n", opnstr1, opnstr2, resultstr); break;
            case JGE: printf("  IF %s >= %s GOTO %s\n", opnstr1, opnstr2, resultstr); break;
            case JGT: printf("  IF %s > %s GOTO %s\n", opnstr1, opnstr2, resultstr); break;
            case EQ: printf("  IF %s == %s GOTO %s\n", opnstr1, opnstr2, resultstr); break;
            case NEQ: printf("  IF %s != %s GOTO %s\n", opnstr1, opnstr2, resultstr); break;
            case ARG: printf("  ARG %s\n", h->result.id); break;
            case CALL: printf("  %s := CALL %s\n", resultstr, opnstr1); break;
            case RETURN:
                if (h->result.kind) printf("  RETURN %s\n", resultstr);
                else printf("  RETURN\n");
                break;
            case EXP_POINT: printf("  %s := * %s\n", resultstr, opnstr1); break;
            case POINT_EXP: printf("  * %s := %s\n", resultstr, opnstr1); break;
            }
            h = h->next;
        } while (h != head);
    }
}
