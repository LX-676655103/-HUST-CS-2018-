
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     INT = 258,
     FLOAT = 259,
     CHAR = 260,
     ID = 261,
     RELOP = 262,
     TYPE = 263,
     ERRORID = 264,
     NULL_P = 265,
     TRUE = 266,
     FALSE = 267,
     VOID = 268,
     BOOL = 269,
     CLASS = 270,
     THIS = 271,
     NEW = 272,
     DELETE = 273,
     BREAK = 274,
     CONTINUE = 275,
     RETURN = 276,
     IF = 277,
     ELSE = 278,
     WHILE = 279,
     FOR = 280,
     PRINT = 281,
     SCAN = 282,
     ASSIGNOP = 283,
     PLUS = 284,
     MINUS = 285,
     STAR = 286,
     DIV = 287,
     MOD = 288,
     AND = 289,
     OR = 290,
     NOT = 291,
     AUTOPLUS = 292,
     AUTOMINUS = 293,
     PLUSASSIGNOP = 294,
     MINUSASSIGNOP = 295,
     STARASSIGNOP = 296,
     DIVASSIGNOP = 297,
     MODASSIGNOP = 298,
     DOT = 299,
     SEMI = 300,
     COMMA = 301,
     LP = 302,
     RP = 303,
     LC = 304,
     RC = 305,
     LB = 306,
     RB = 307,
     EOL = 308,
     CLASS_DEF_LIST = 309,
     CLASS_DEF = 310,
     FIELD_LIST = 311,
     VAR_DEF = 312,
     FUNC_DEF = 313,
     TYPE_COL = 314,
     VAR_DEF_LIST = 315,
     ID_DEF_LIST = 316,
     FUNC_DEF_ACT = 317,
     FORMALS_DEF = 318,
     VAR_DEF_S = 319,
     NEW_ID_ARR = 320,
     STMT_BLOCK = 321,
     STMT_LIST = 322,
     PRINT_STMT = 323,
     SCAN_STMT = 324,
     RETURN_EXP = 325,
     NEW_ID = 326,
     IF_STMT = 327,
     IF_ELSE_STMT = 328,
     FOR_STMT = 329,
     WHILE_STMT = 330,
     BREAK_STMT = 331,
     CONTINUE_STMT = 332,
     EXP_EXP = 333,
     EXP_ID = 334,
     ID_ACTUALS = 335,
     EXP_ID_ACTUALS = 336,
     ACTUALS = 337,
     EXP_LIST = 338,
     DELETE_ID = 339,
     DELETE_EXP_ID = 340,
     FUNCTION = 341,
     PARAM = 342,
     ARG = 343,
     LABEL = 344,
     GOTO = 345,
     JLT = 346,
     JLE = 347,
     JGT = 348,
     JGE = 349,
     EQ = 350,
     NEQ = 351,
     CALL = 352,
     EXP_POINT = 353,
     POINT_EXP = 354,
     UMINUS = 355,
     LOWER_THEN_ELSE = 356
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 1676 of yacc.c  */
#line 19 "parser.y"

	int    type_int;
	float  type_float;
	char   type_id[32];
                char   type_string[128];
	struct ASTNode *ptr;



/* Line 1676 of yacc.c  */
#line 163 "parser.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYLTYPE yylloc;

