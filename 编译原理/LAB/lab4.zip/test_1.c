class test_class_1
{
    int int_num_1;
    int int_num_2, int_num_3;
    int[5] int_array_1;
}
class test_class_3
{
    int m, n, i;
    int[5][6][6] array;
    class test_class_1 class_var_1;

    void test_func_1(){}
    int test_func_2(int a){return 1;}


    int fibo(int a)
    {
        if(a==1||a==2) return 1;
        return fibo(a-1)+fibo(a-2);
    }
    char char_var_1, char_var_2;

    int main()
    {
        int a,b,c;
        int[5][5] int_array_1;
        char char_1, char_2;

        char_1='a';
        char_2='a'+'1';

        m=5;
        this.m=5;

        array[2][4][3]=10;


        a=a+fibo(4);
        b=this.fibo(5);

        n = -i + n;
        i++; i--; ++i; --i;

        if(a) Print(i);
        else if(b){
            Print(i);
        }
        else Print(i);

        while(i<=m)
        {
            n=fibo(i);
            Print(i);
            i=i+1;
            if(i = 5) break;
            if(i!=5) continue;
        }

        for(a=1; a<10; a++)
        {
            Scan(i);
            Print(i);
        }

        return 1;
    }
}



















