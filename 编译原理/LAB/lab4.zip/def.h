#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "stdarg.h"
#include "parser.tab.h"
#define MAXLENGTH   1000
#define INT_TYPE    1
#define FLOAT_TYPE  2
#define CHAR_TYPE   3
/*活动记录控制信息需要的单元数，这个根据实际系统调整*/
#define DX 3*sizeof(int)

int LEV;      //层号
struct opn{
    int kind;    //标识联合成员的属性
    int type;    //标识操作数的数据类型
    union {
        int     const_int;      //整常数值，立即数
        float   const_float;    //浮点常数值，立即数
        char    const_char;     //字符常数值，立即数
        char    id[33];         //变量或临时变量的别名或标号字符串
        };
    int level;                  //变量的层号，0表示是全局变量，数据保存在静态数据区
    int offset;                 //偏移量，目标代码生成时用
    };

struct codenode {   //三地址TAC代码结点,采用单链表存放中间语言代码
        int  op;
        struct opn opn1,opn2,result;
        struct codenode  *next,*prior;
    };

/* 语法分析树结点 */
struct ASTNode {
    struct ASTNode *ptr[4];
	int kind;  /* 结点的类型 */
	/* 存储标识符以及常数信息 */
	union {
		  char type_id[33];
		  int type_int;
		  float type_float;
          char type_char;
          char type_string[33];
	      };

    int pos; /* 语法单位所在位置行号 */
    /* 符号表相关 */
    int place;  /* 符号表的地址 */
	int type;   /* 结点表达式的类型 */
	char flag;  /* 结点表达式的类别，与符号表的类别标识相同 */
    int offset; /* 偏移量 */
    int width;  /* 占数据字节数 */
    int num;    /* 函数参数个数 */
    int col_num;      /* 数组维数 */
    int index_class;  /* 类变量的类定义符号表地址 */
    int return_flag, return_pos; /* 标识函数中是否存在返回语句 */
    /* 中间代码生成相关 */
    /* 对布尔表达式的翻译时，真假转移目标的标号 */
    char Etrue[15],Efalse[15];
    /* 结点对应语句S执行后的下一条语句位置标号 */
    char Snext[15];
    char Sbreak[15], Scontinue[15];
    /* 中间代码链表头指针 */
    struct codenode *code;
    };

struct symbol {       //这里只列出了一个符号表项的部分属性，没考虑属性间的互斥
    char name[128];   //变量或函数名
    int level;        //层号
    int type;         //变量类型（包括数组）或函数返回值类型或类的定义
    int  paramnum;    //对函数适用，记录形式参数个数 & 对于数组变量记录数组的层数
    char alias[10];   //别名，为解决嵌套层次使用
    char flag;       //符号标记，函数：'F'  变量：'V'   参数：'P'  参数数组：'Q'  临时变量：'T' 类定义：'C' 数组定义：'A'
    char offset;      //外部变量和局部变量在其静态数据区或活动记录中的偏移量，
    int index_class;
//或记录函数活动记录大小，目标代码生成时使用
    //函数入口等实验可能会用到的属性...
    };
//符号表
struct symboltable{
    struct symbol symbols[MAXLENGTH];
    int index;
    } symbolTable;

struct symbol_scope_begin {
    //当前作用域的符号在符号表的起始位置序号,这是一个栈结构,当使用顺序表作为符号表时，进入、退出一个作用域时需要对其操作，以完成符号表的管理。对其它形式的符号表，不一定需要此数据结构
    int TX[100];
    int top;
    } symbol_scope_TX;

struct class_index {
    int TX[100];
    int index;
    } class_index;

/*generate AST*/
struct ASTNode * mknode(int num,int kind,int pos,...);

/*generate symbol table*/
char *str_catch(char *s1, char *s2);
char *strcat0(char *s1,char *s2);
char *newTemp();
char *newAlias();
void semantic_error(int line,char *msg1,char *msg2);
void prn_symbol();
int searchSymbolTable(char *name);
int fillSymbolTable(char *name,char *alias,int level,int type,char flag,int offset);
int fill_Temp(char *name,int level,int type,char flag,int offset);
void type_find(struct ASTNode *T);
void id_list(struct ASTNode *T);
int match_param(int i,int pos,struct ASTNode *T);
void assign_op(struct ASTNode *T);

/*semantic analysis*/
void semantic_Analysis0(struct ASTNode *T);
void semantic_Analysis(struct ASTNode *T);
void boolExp(struct ASTNode *T);
void Exp(struct ASTNode *T);
void objectCode(struct codenode *head);
void displayArrayExp(struct ASTNode * T);


