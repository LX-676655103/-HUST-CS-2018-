#include "def.h"
#include "parser.tab.h"
#define OFFSET 3

struct ASTNode * mknode(int num,int kind,int pos,...){
    struct ASTNode *T=(struct ASTNode *)calloc(sizeof(struct ASTNode),1);
    int i=0;
    T->kind=kind;
    T->pos=pos;
    T->offset=0;
    T->num=0;
    T->col_num=0;
    T->width=0;
    T->index_class=-1;
    va_list pArgs;
    va_start(pArgs, pos);
    for(i=0;i<num;i++)
        T->ptr[i]= va_arg(pArgs, struct ASTNode *);
    while (i<4) T->ptr[i++]=NULL;
    va_end(pArgs);
    return T;
}

void displayRoot(){
    printf("Program Root根节点\n");
}
void display(struct ASTNode *T,int indent)
{//对抽象语法树的先根遍历
  int i=1;
  struct ASTNode *T0;
  if (T)
	{
    switch (T->kind)
    {
    case CLASS_DEF_LIST:
        display(T->ptr[0],indent);    //显示第一个类的定义
        display(T->ptr[1],indent);    //显示其他类列表的类定义
        break;
    case CLASS_DEF:
        printf("%*c类定义：%s (%d)\n",indent,' ',T->type_id,T->pos); //显示类名称
        display(T->ptr[1],indent+OFFSET);   //显示变量与函数定义与实现
        break;
    case FIELD_LIST:
        printf("%*c类成员定义：(%d)\n",indent,' ',T->pos);
        display(T->ptr[0],indent);
        display(T->ptr[1],indent);
        break;
    case VAR_DEF:
        display(T->ptr[0],indent+OFFSET);
        printf("%*c变量名：\n",indent+OFFSET,' ');
        display(T->ptr[1],indent+OFFSET*2);        //显示变量列表
        break;
    case TYPE:
        printf("%*c类型：%s\n",indent,' ',T->type_id);
        break;
    case TYPE_COL:
        display(T->ptr[0],indent);
        printf("%*c[]类型：\n",indent,' ');
        break;
    case ID_DEF_LIST:
        printf("%*cID：%s\n",indent,' ',T->type_id);
        display(T->ptr[1],indent);
        break;
    case ID:
        printf("%*cID：%s\n",indent,' ',T->type_id);
        break;
    case FUNC_DEF_ACT:
        display(T->ptr[0],indent+OFFSET);      //显示函数返回类型
        printf("%*c函数名：%s\n",indent+OFFSET,' ',T->type_id); //显示函数名
        if (T->ptr[2])
            display(T->ptr[2],indent+OFFSET);      //显示参数列表
        else printf("%*c无参数\n",indent+OFFSET,' ');
        display(T->ptr[3],indent+OFFSET);      //显示函数体
        break;
    case FORMALS_DEF:
        printf("%*c函数形式参数：(%d)\n",indent,' ',T->pos);
        display(T->ptr[0],indent+OFFSET);
        break;
	case VAR_DEF_LIST:
        display(T->ptr[0],indent);
        display(T->ptr[1],indent);
        break;
    case VAR_DEF_S:
        display(T->ptr[0],indent+OFFSET);
        printf("%*c参数名：%s\n",indent,' ',T->type_id);
        break;
	case STMT_BLOCK:
	    if (T->ptr[0])
	    {
	        printf("%*c复合语句：(%d)\n",indent,' ',T->pos);
	        display(T->ptr[0],indent+OFFSET);
	    }
        else printf("%*c无复合语句\n",indent,' ');
        break;
	case STMT_LIST:
	    if(T->ptr[0]->kind == VAR_DEF)
            printf("%*c复合语句的变量定义部分：\n",indent,' ');
        else printf("%*c复合语句的语句部分：\n",indent,' ');
        display(T->ptr[0],indent+OFFSET);
        display(T->ptr[1],indent);
        break;
	case IF_STMT:
        printf("%*c条件语句(IF)：(%d)\n",indent,' ',T->pos);
        printf("%*c条件：\n",indent+OFFSET,' ');
        display(T->ptr[0],indent+OFFSET*2);      //显示条件
        printf("%*cIF子句：(%d)\n",indent+OFFSET,' ',T->pos);
        display(T->ptr[1],indent+OFFSET*2);      //显示if子句
        break;
	case IF_ELSE_STMT:
        printf("%*c条件语句(IF_ELSE)：(%d)\n",indent,' ',T->pos);
        printf("%*c条件：\n",indent+OFFSET,' ');
        display(T->ptr[0],indent+OFFSET*2);      //显示条件
        printf("%*cIF子句：(%d)\n",indent+OFFSET,' ',T->pos);
        display(T->ptr[1],indent+OFFSET*2);      //显示if子句
        printf("%*cELSE子句：(%d)\n",indent+OFFSET,' ',T->pos);
        display(T->ptr[2],indent+OFFSET*2);      //显示else子句
        break;
    case FOR_STMT:
        printf("%*cFor(循环)：(%d)\n", indent, ' ', T->pos);
        printf("%*c循环初始语句(%d)\n", indent+OFFSET, ' ', T->pos);
        display(T->ptr[0], indent+OFFSET*2);
        printf("%*c循环判断语句(%d)\n", indent+OFFSET, ' ', T->pos);
        display(T->ptr[1], indent+OFFSET*2);
        printf("%*c循环处理语句(%d)\n", indent+OFFSET, ' ', T->pos);
        display(T->ptr[2], indent+OFFSET*2);
        printf("%*c循环体：(%d)\n", indent+OFFSET, ' ', T->pos);
        display(T->ptr[3], indent+OFFSET*2); //显示循环体
        break;
    case WHILE_STMT:
        printf("%*cWHILE(语句)：(%d)\n",indent,' ',T->pos);
        printf("%*c循环条件：\n",indent+OFFSET,' ');
        display(T->ptr[0],indent+OFFSET*2);      //显示循环条件
        printf("%*c循环体：(%d)\n",indent+OFFSET,' ',T->pos);
        display(T->ptr[1],indent+OFFSET*2);      //显示循环体
        break;
    case CONTINUE_STMT:
	    printf("%*c CONTINUE语句(%d)\n", indent, ' ', T->pos);
	    break;
	case BREAK_STMT:
	    printf("%*c BREAK语句(%d)\n", indent, ' ', T->pos);
	    break;
	case RETURN:
        printf("%*c返回语句：(%d)\n",indent,' ',T->pos);
        break;
    case RETURN_EXP:
        printf("%*c返回语句：(%d)\n",indent,' ',T->pos);
        display(T->ptr[0],indent+OFFSET);
        break;



    case DELETE_ID:
        printf("%*c删除语句：(%d)\n",indent,' ',T->pos);
        printf("%*c变量名：%s\n",indent+OFFSET,' ',T->type_id);
        break;
    case PRINT_STMT:
        printf("%*c输出语句：(%d)\n",indent,' ',T->pos);
        display(T->ptr[0],indent+OFFSET);
        break;
    case SCAN_STMT:
        printf("%*c输入语句：(%d)\n",indent,' ',T->pos);
        display(T->ptr[0],indent+OFFSET);
        break;
	case ASSIGNOP:
	    printf("%*c赋值语句：(%d)\n",indent,' ',T->pos);
        printf("%*cASSIGNOP\n",indent+OFFSET,' ');
        display(T->ptr[0],indent+OFFSET*2);
        display(T->ptr[1],indent+OFFSET*2);
	    break;
	case EXP_EXP:
	    printf("%*c数组：(%d)\n",indent,' ',T->pos);
	    printf("%*c数组名称：(%d)\n",indent+OFFSET,' ',T->pos);
        display(T->ptr[0],indent+OFFSET*2);
        printf("%*c数组下标：(%d)\n",indent+OFFSET,' ',T->pos);
        display(T->ptr[1],indent+OFFSET*2);
	    break;
	case EXP_ID:
	    printf("%*cExpr.ID：(%d)\n",indent,' ',T->pos);
	    printf("%*c作用域：(%d)\n",indent+OFFSET,' ',T->pos);
        display(T->ptr[0],indent+OFFSET*2);
        printf("%*cID：\n",indent+OFFSET,' ');
        printf("%*c%s\n",indent+OFFSET*2,' ',T->type_id);
	    break;
    case ID_ACTUALS:
        printf("%*c函数调用：(%d)\n",indent,' ',T->pos);
        printf("%*c函数名：%s\n",indent+OFFSET,' ',T->type_id);
        display(T->ptr[1],indent+OFFSET);
        break;
    case EXP_ID_ACTUALS:
        printf("%*c函数调用：(%d)\n",indent,' ',T->pos);
        printf("%*c作用域：(%d)\n",indent+OFFSET,' ',T->pos);
        display(T->ptr[0],indent+OFFSET*2);
        printf("%*c函数名：%s\n",indent+OFFSET,' ',T->type_id);
        display(T->ptr[2],indent+OFFSET*2);
        break;
    case ACTUALS:
        printf("%*c参数列表：(%d)\n",indent,' ',T->pos);
        display(T->ptr[0],indent+OFFSET);
        break;
	case EXP_LIST:
        display(T->ptr[0],indent);
        display(T->ptr[1],indent);
        break;

	case INT:
        printf("%*cINT：%d\n",indent,' ',T->type_int);
        break;
	case FLOAT:
        printf("%*cFLAOT：%f\n",indent,' ',T->type_float);
        break;
    case CHAR:
        printf("%*cCHAR: %s\n", indent, ' ', T->type_string);//STRING
        break;
    case NULL_P:
        printf("%*cNULL: %s\n", indent, ' ', T->type_id);//STRING
        break;
    case TRUE:
        printf("%*cTRUE: %s\n", indent, ' ', T->type_id);//STRING
        break;
    case FALSE:
        printf("%*cFALSE: %s\n", indent, ' ', T->type_id);//STRING
        break;
    case THIS:
        printf("%*cTHIS: %s\n", indent, ' ', T->type_id);//STRING
        break;
    case NEW_ID:
        printf("%*cnew语句：%s(%d)\n",indent,' ',T->type_id,T->pos);
        display(T->ptr[0],indent+OFFSET);
        break;
    case NEW_ID_ARR:
        printf("%*c数组new语句：(%d)\n",indent,' ',T->pos);
        display(T->ptr[0],indent+OFFSET);
        display(T->ptr[1],indent+OFFSET);
        break;
    case PLUSASSIGNOP:
    case MINUSASSIGNOP:
    case STARASSIGNOP:
    case DIVASSIGNOP:
    case MODASSIGNOP:
	case AND:
	case OR:
	case RELOP:
	case PLUS:
    case AUTOPLUS:
    case AUTOMINUS:
	case MINUS:
	case STAR:
	case DIV:
    case MOD:
        printf("%*c%s\n",indent,' ',T->type_id);
        display(T->ptr[0],indent+OFFSET);
        display(T->ptr[1],indent+OFFSET);
        break;
	case NOT:
	case UMINUS:
        printf("%*c%s\n",indent,' ',T->type_id);
        display(T->ptr[0],indent+OFFSET);
        break;
    default:
        printf("%*c未找到该类型：(%d)\n",indent,' ',T->pos);
        break;
        }
    }
}
