#include "def.h"
#define DEBUG 0
#define PRINT 1
#define CLASS_BEGIN 20
int flag_loop;
char *strcat0(char *s1,char *s2)
{
    static char result[10];
    strcpy(result,s1);
    strcat(result,s2);
    return result;
}
char *str_catch(char *s1, char *s2)
{
    static char result[10];
    strcpy(result, s1);
    strcat(result, s2);
    return result;
}
char *newTemp()
{
    static int no = 1;
    char s[10];
    snprintf(s, 10, "%d", no++);
    return str_catch("temp", s);
}
/* 生成新的标识符别名 */
char *newAlias()
{
    static int no=1;
    char s[10];
    itoa(no++,s,10);
    return strcat0("v",s);
}

/* 显示错误信息 */
void semantic_error(int line,char *msg1,char *msg2)
{
    printf("在%d行,%s %s\n",line,msg1,msg2);
}

/* 显示符号表 */
void prn_symbol() {
	int i = 0;
	printf("----------------------------------------------------------------------------------\n");
	printf("|                               Symbol Table                                     |\n");
	printf("----------------------------------------------------------------------------------\n");
	printf("|       %-18s|  %-6s  | %-4s |\t%s\t|%s|%s|%s|%s|\n", "变量名",  "别名", "层号", "类型", "类索引", "维数","标 记","偏移量");
	printf("----------------------------------------------------------------------------------\n");


	for (i = 0; i < symbolTable.index; ++i) {
		if (!strcmp(symbolTable.symbols[i].name, " "))
			continue;
		printf("| %-20s ", symbolTable.symbols[i].name);
		printf("| %-7s", symbolTable.symbols[i].alias);
		printf("|  %-3d ", symbolTable.symbols[i].level);
		switch (symbolTable.symbols[i].type)
		{
		case INT:
			if (symbolTable.symbols[i].flag != 'A'&&symbolTable.symbols[i].flag != 'Q')
				printf("|\t%s\t", "int");
			else printf("|\t%s\t", "int[]");
			break;
		case FLOAT:
			if (symbolTable.symbols[i].flag != 'A'&&symbolTable.symbols[i].flag != 'Q')
				printf("|\t%s\t", "float");
			else printf("|\t%s\t","float[]");
			break;
		case CHAR:
			if (symbolTable.symbols[i].flag != 'A'&&symbolTable.symbols[i].flag != 'Q')
				printf("|\t%s\t", "char");
			else printf("|\t%s\t", "char[]");
			break;
        case CLASS:
            if (symbolTable.symbols[i].flag != 'A'&&symbolTable.symbols[i].flag != 'Q')
				printf("|\t%s\t", "class");
			else printf("|\t%s\t", "class[]");
			break;
        case VOID: printf("|\t%s\t", "void"); break;
		case NULL_P: printf("|\t%s\t", "null"); break;
        case TRUE:printf("|\t%s\t", "bool"); break;
        case FALSE:printf("|\t%s\t", "bool"); break;
		default:printf("|\t%s\t", "");
			break;
		}
		if(symbolTable.symbols[i].type==CLASS)
            printf("|  %-3d ", (symbolTable.symbols[i].index_class));
        else printf("|      " );
        if(symbolTable.symbols[i].paramnum > 0)
            printf("| %-3d", (symbolTable.symbols[i].paramnum));
        else printf("|    ");
		printf("|  %c  ", (symbolTable.symbols[i].flag));
		/*if (symbolTable.symbols[i].flag == 'F')
			printf("%s %d\t|\n", "Func panramnum:", symbolTable.symbols[i].paramnum);
		else*/
			printf("| %-4d |\n",symbolTable.symbols[i].offset);
	}
	printf("----------------------------------------------------------------------------------\n");
}

/* 搜索符号表，查找当前符号是否已经存在 */
int searchSymbolTable(char *name)
{
    int i;
    for(i=symbolTable.index-1; i>=0; i--)
    {
        //if (symbolTable.symbols[i].flag == 'P'||symbolTable.symbols[i].flag == 'Q') continue;
        if (!strcmp(symbolTable.symbols[i].name, name))  return i;
    }
    return -1;
}

/* 生成新的符号表项 */
int fillSymbolTable(char *name,char *alias,int level,int type,char flag,int offset)
{
    /* 符号查重 */
    int i;
    /* 函数形参名 & 类数据成员名称可以相同 */
    if(flag == 'C')
    {
        for(i=0; i<class_index.index; i++)
            if (!strcmp(symbolTable.symbols[class_index.TX[i]].name, name))
                return -1;
    }
    else
    {
        /* 类数据成员以及外层变量可以被内层变量覆盖 */
        for(i=symbolTable.index-1; i>=0 && (symbolTable.symbols[i].level==level || level==1) ; i--)
        {
            /* 同名函数查找 */
            if (symbolTable.symbols[i].level==0) break;
            if (level==1 && symbolTable.symbols[i].level==2) continue;
            if (!strcmp(symbolTable.symbols[i].name, name)) return -1;
        }
    }
/* 填写符号表内容 */
    strcpy(symbolTable.symbols[symbolTable.index].name,name);
    strcpy(symbolTable.symbols[symbolTable.index].alias,alias);
    symbolTable.symbols[symbolTable.index].level=level;
    symbolTable.symbols[symbolTable.index].type=type;
    symbolTable.symbols[symbolTable.index].flag=flag;
    symbolTable.symbols[symbolTable.index].offset=offset;

    /* 返回的是符号在符号表中的位置序号，中间代码生成时可用序号取到符号别名 */
    return symbolTable.index++;
}

/* 填写临时变量到符号表，返回临时变量在符号表中的位置 */
int fill_Temp(char *name,int level,int type,char flag,int offset)
{
    strcpy(symbolTable.symbols[symbolTable.index].name,"");
    strcpy(symbolTable.symbols[symbolTable.index].alias,name);
    symbolTable.symbols[symbolTable.index].level=level;
    symbolTable.symbols[symbolTable.index].type=type;
    symbolTable.symbols[symbolTable.index].flag=flag;
    symbolTable.symbols[symbolTable.index].offset=offset;
    return symbolTable.index++; //返回的是临时变量在符号表中的位置序号
}


/* 标识符类型函数 */
void type_find(struct ASTNode *T)
{
    int i;
    switch (T->kind)
    {
        case TYPE:
            # if(DEBUG)
            printf("TYPE:\n");
            # endif
            T->col_num = 0;
            T->index_class = -1;
            /* 如果当前类型为类类型 */
            if(T->type==CLASS)
                /* 查找当前类是否已经定义 */
                for(i=0; i<class_index.index; i++)
                    if (!strcmp(symbolTable.symbols[class_index.TX[i]].name, T->type_id))
                        T->index_class = class_index.TX[i];
            return;
        case TYPE_COL:
            # if(DEBUG)
            printf("TYPE[]:\n");
            # endif
            type_find(T->ptr[0]);
            T->col_num = T->ptr[0]->col_num + 1;
            T->index_class = T->ptr[0]->index_class;
            T->type = T->ptr[0]->type;
            strcpy(T->type_id,T->ptr[0]->type_id);
            break;
    }
}

/* 处理变量列表函数 */
void id_list(struct ASTNode *T)
{
    char temp;
    int rtn,num=1;
    switch (T->kind)
    {
        case ID_DEF_LIST:
            # if(DEBUG)
            printf("IDList: ID COMMA IDList\n");
            # endif

            /* 将第一个结点放入符号表 */
            if(T->col_num > 0) temp = 'A';
            else temp = 'V';
            rtn=fillSymbolTable(T->type_id,newAlias(),LEV,T->type,temp,T->offset);
            if (rtn==-1) semantic_error(T->pos, "error(3): 变量重复定义",T->type_id);
            else if(T->type == CLASS)
                symbolTable.symbols[rtn].index_class=T->index_class;
            else symbolTable.symbols[rtn].index_class=-1;
            symbolTable.symbols[rtn].paramnum=T->col_num;

            /* 处理第二个结点 */
            T->ptr[1]->type=T->type;
            T->ptr[1]->offset=T->offset+T->width;
            T->ptr[1]->width=T->width;
            T->ptr[1]->col_num = T->col_num;
            T->ptr[1]->index_class = T->index_class;
            id_list(T->ptr[1]);
            T->num=T->ptr[1]->num+1;
            break;
        case ID:
            # if(DEBUG)
            printf("IDList: ID\n");
            # endif

            if(T->col_num > 0) temp = 'A';
            else temp = 'V';
            rtn=fillSymbolTable(T->type_id,newAlias(),LEV,T->type,temp,T->offset);
            if (rtn==-1){ semantic_error(T->pos, "error(3): 变量重复定义",T->type_id);  T->num=1; break;}
            else T->place=rtn;
            if(T->type == CLASS)
                symbolTable.symbols[rtn].index_class=T->index_class;
            else symbolTable.symbols[rtn].index_class=-1;
            symbolTable.symbols[rtn].paramnum=T->col_num;
            T->num=1;
            break;

    }
}


void boolExp(struct ASTNode *T)   //布尔表达式，参考文献[2]p84的思想
{
    struct opn opn1,opn2,result;
    int op;
    int rtn;
    if (T)
    {
        switch (T->kind)
        {
        case INT:
        case FLOAT:
        case ID:
        case ID_ACTUALS:
        case EXP_ID:
        case EXP_ID_ACTUALS:
        case EXP_EXP:
        case CHAR:
        case NULL_P:
        case TRUE:
        case FALSE:
        case THIS:
            Exp(T);break;

        /* 处理关系运算表达式,2个操作数都按基本表达式处理 */
        case RELOP:
            T->ptr[0]->offset=T->ptr[1]->offset=T->offset;
            Exp(T->ptr[0]);
            T->width=T->ptr[0]->width;
            Exp(T->ptr[1]);
            if (T->ptr[0]->type!=T->ptr[1]->type){
                semantic_error(T->pos,"", "error(15): RELOP运算数类型不匹配");
                break;
            }
            if(T->ptr[0]->type==CLASS
               || T->ptr[0]->col_num > 0
               || T->ptr[1]->col_num > 0){
                semantic_error(T->pos,"", "error(25): 不可对数组量以及类类型量进行比较运算");
                break;
            }
            if (T->width<T->ptr[1]->width) T->width=T->ptr[1]->width;
            break;
        case AND:
        case OR:
            # if(DEBUG)
            printf("Expr: Expr && || Expr\n");
            # endif
            T->ptr[0]->offset=T->ptr[1]->offset=T->offset;
            boolExp(T->ptr[0]);
            T->width=T->ptr[0]->width;
            boolExp(T->ptr[1]);
            if (T->width<T->ptr[1]->width) T->width=T->ptr[1]->width;
            break;
        case NOT:
            T->ptr[0]->offset=T->offset;
            boolExp(T->ptr[0]);
            break;
        default:
            Exp(T);
            break;
        }
    }
}

void assign_op(struct ASTNode *T)
{
    if (T)
    {
        if (T->ptr[0]->kind!=ID
                && T->ptr[0]->kind!=EXP_EXP
                && T->ptr[0]->kind!=EXP_ID)
            semantic_error(T->pos,"", "error(12): 赋值号左边不是左值表达式");
        else
        {
            T->ptr[0]->offset=T->offset;
            Exp(T->ptr[0]);
            if(T->ptr[0]->col_num > 0){
                semantic_error(T->pos,"", "error(12): 赋值号左边不是左值表达式(数组维数错误)");
                return;
            }
            T->ptr[1]->offset=T->offset+T->ptr[0]->width;
            Exp(T->ptr[1]);
            if(T->ptr[1]->type!=T->ptr[0]->type)
                semantic_error(T->pos,"", "error(15): 赋值语句两端类型不匹配");
            T->type=T->ptr[0]->type;
            T->width=T->ptr[0]->width+T->ptr[1]->width;
        }
    }
}

void Exp(struct ASTNode *T)
{
    //处理基本表达式，参考文献[2]p82的思想
    int i, find_flag=0;
    int rtn,num,width;
    struct ASTNode *T0;
    struct opn opn1,opn2,result;
    if (T)
    {
        switch (T->kind)
        {
            /* 查符号表，获得符号表中的位置，类型送type */
            case ID:
                # if(DEBUG)
                printf("Expr: ID\n");
                # endif
                rtn=searchSymbolTable(T->type_id);
                if (rtn==-1) semantic_error(T->pos, "error(1): 使用未定义的变量", T->type_id);
                if (symbolTable.symbols[rtn].flag=='F')
                    semantic_error(T->pos, "error(5): 对函数名采用非函数调用形式访问", T->type_id);
                if (symbolTable.symbols[rtn].flag=='C')
                    semantic_error(T->pos, "error(5): 对类名非法访问", T->type_id);
                else
                {
                    T->col_num=symbolTable.symbols[rtn].paramnum;
                    T->place=rtn;       //结点保存变量在符号表中的位置
                    T->index_class=symbolTable.symbols[rtn].index_class;
                    T->type=symbolTable.symbols[rtn].type;
                    T->offset=symbolTable.symbols[rtn].offset;
                    T->width=0;         //未再使用新单元
                    T->flag=symbolTable.symbols[rtn].flag;
                    T->code=NULL;       //标识符不需要生成TAC
                }
                break;

            case ID_ACTUALS:
                # if(DEBUG)
                printf("Expr: ID (Actuals)\n");
                # endif

                rtn=searchSymbolTable(T->type_id);
                if (rtn==-1){
                    semantic_error(T->pos, "error(2): 调用未定义或未声明的函数 " ,T->type_id);
                    break;
                }
                if (symbolTable.symbols[rtn].flag!='F'){
                    semantic_error(T->pos, "error(4): 对非函数名采用函数调用形式 ", T->type_id);
                    break;
                }
                T->type=symbolTable.symbols[rtn].type;
                width = T->type == CHAR ? 1 : T->type == VOID ? 0 : 4;
                if (T->ptr[1])
                {
                    T->ptr[1]->offset=T->offset; T->place=rtn;
                    semantic_Analysis(T->ptr[1]);
                    //累加上计算实参使用临时变量的单元数
                    T->width=T->ptr[1]->width+width;
                }
                match_param(rtn,T->pos,T->ptr[1]); //处理所有参数的匹配
                break;

            case EXP_ID:
                # if(DEBUG)
                printf("Expr: Expr.ID\n");
                # endif
                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                if(T->ptr[0]->type!=CLASS || T->ptr[0]->col_num>0){
                    semantic_error(T->pos,"", "error(10): 对非结构变量采用成员选择运算符‘.’");
                    break;
                }
                /* 查找当前变量是否含有数据成员ID */

                i = T->ptr[0]->index_class, find_flag=0;
                while(symbolTable.symbols[++i].level != 0)
                    if(!strcmp(symbolTable.symbols[i].name, T->type_id)
                        && symbolTable.symbols[i].level == 1
                        && (symbolTable.symbols[i].flag=='V'
                            || symbolTable.symbols[i].flag=='A')){
                        find_flag = 1;
                        break;
                    }
                if(!find_flag)
                semantic_error(T->pos,"", "error(11): 结构成员不存在");
                else{
                    T->col_num=symbolTable.symbols[i].paramnum;
                    T->place=i;       //结点保存变量在符号表中的位置
                    T->index_class=symbolTable.symbols[i].index_class;
                    T->type=symbolTable.symbols[i].type;
                    T->width=T->ptr[0]->width;
                    T->flag=symbolTable.symbols[i].flag;
                }
                break;

            case EXP_ID_ACTUALS:
                # if(DEBUG)
                printf("Expr: Expr.ID (Actuals)\n");
                # endif
                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                if(T->ptr[0]->type!=CLASS || T->ptr[0]->col_num>0){
                    semantic_error(T->pos,"", "error(10): 对非结构变量采用成员选择运算符‘.’(数组或其他非变量类型)");
                    break;
                }

                /* 查找当前变量是否含有函数成员ID */

                    i = T->ptr[0]->index_class, find_flag=0;
                    while(symbolTable.symbols[++i].level != 0)
                        if(!strcmp(symbolTable.symbols[i].name, T->type_id)
                           && symbolTable.symbols[i].level == 1
                            && symbolTable.symbols[i].flag=='F'){
                            find_flag = 1;
                            break;
                        }
                    if(!find_flag){
                        semantic_error(T->pos,"", "error(11): 结构成员不存在");
                        break;
                    }
                    width = T->type == CHAR ? 1 : T->type == VOID ? 0 : 4;
                    T->flag=symbolTable.symbols[i].flag;
                    T->place=i;       //结点保存变量在符号表中的位置
                    T->index_class=symbolTable.symbols[i].index_class;
                    T->type=symbolTable.symbols[i].type;
                    if (T->ptr[2]){
                        T->ptr[2]->offset=T->offset+T->ptr[0]->width;
                        semantic_Analysis(T->ptr[2]);
                        //累加上计算实参使用临时变量的单元数
                        T->width=T->ptr[0]->width+T->ptr[2]->width+width;
                    }
                    match_param(i,T->pos,T->ptr[2]); //处理所有参数的匹配
                break;
            case EXP_EXP:
                # if(DEBUG)
                printf("Expr: Expr[Expr]\n");
                # endif
                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                if(T->ptr[0]->col_num==0
                   || (T->ptr[0]->flag!='Q'
                    && T->ptr[0]->flag!='A')){
                    semantic_error(T->pos,"", "error(8): 对非数组变量采用下标变量的形式访问");
                    break;
                }
                /* 查找当前变量是否含有数据成员ID */
                T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                Exp(T->ptr[1]);
                if(T->ptr[1]->type!=INT)
                    semantic_error(T->pos,"", "error(9): 数组变量的下标不是整型表达式");
                else
                {
                    T->flag=T->ptr[0]->flag;
                    /* 数组维数下降 */
                    T->col_num=T->ptr[0]->col_num-1;
                    T->place=T->ptr[0]->place;       //结点保存变量在符号表中的位置
                    T->index_class=T->ptr[0]->index_class;
                    T->type=T->ptr[0]->type;
                    T->offset=T->ptr[0]->offset;
                    T->width=T->ptr[0]->width+T->ptr[1]->width;
                }
                break;
            case INT:
                # if(DEBUG)
                printf("Expr: INT\n");
                # endif
                /* 为整常量生成一个临时变量 */
                //T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type=INT; T->width=4; break;
            case FLOAT:
                # if(DEBUG)
                printf("Expr: FLOAT\n");
                # endif
                /* 为浮点常量生成一个临时变量 */
                //T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type=FLOAT; T->width=4; break;
            case CHAR:
                //为字符常量生成一个临时变量
                //T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type = CHAR; T->width = 1; break;
            case NULL_P:
                # if(DEBUG)
                printf("Expr: null\n");
                # endif
                //为空常量生成一个临时变量
                //T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type = NULL_P; T->width = 1; break;
            case TRUE:
                # if(DEBUG)
                printf("Expr: true\n");
                # endif
                //T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type = TRUE; T->width = 1; break;
            case FALSE:
                # if(DEBUG)
                printf("Expr: false\n");
                # endif
                //T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type = TRUE; T->width = 1; break;
            case THIS:
                # if(DEBUG)
                printf("Expr: this\n");
                # endif
                T->flag='V'; T->col_num=0; T->type=CLASS;
                T->index_class=class_index.TX[class_index.index-1];
                break;

            /* 赋值语句的类型检查 */
            case ASSIGNOP:
                # if(DEBUG)
                printf("Expr: Expr = Expr\n");
                # endif
                assign_op(T); break;
            case PLUSASSIGNOP:
                # if(DEBUG)
                printf("Expr: Expr += Expr\n");
                # endif
                assign_op(T); break;
            case MINUSASSIGNOP:
                # if(DEBUG)
                printf("Expr: Expr -= Expr\n");
                # endif
                assign_op(T); break;
            case STARASSIGNOP:
                # if(DEBUG)
                printf("Expr: Expr *= Expr\n");
                # endif
                assign_op(T); break;
            case DIVASSIGNOP:
                # if(DEBUG)
                 printf("Expr: Expr /= Expr\n");
                # endif
                assign_op(T); break;
            case MODASSIGNOP:
                # if(DEBUG)
                printf("Expr: Expr %= Expr\n");
                # endif
                assign_op(T); break;

            /* 逻辑运算语句的类型检查 */
            case AND: case OR: case NOT: case RELOP:
                semantic_error(T->pos,"", "error(23): 逻辑运算不可出现在除if/while/for的函数体中");
                break;

            /* 负号只可以对int以及float量起效果 */
            case UMINUS:
                T->ptr[0]->offset = T->offset;
                Exp(T->ptr[0]);
                T->type = T->ptr[0]->type;
                if(T->type!=INT && T->type!=FLOAT)
                    semantic_error(T->pos,"", "error(24): 负号只能对int/float进行操作");
                else{
                    T->flag=T->ptr[0]->flag;
                    T->type=T->ptr[0]->type;
                    T->width=T->ptr[0]->width;
                    T->col_num=T->ptr[0]->col_num;
                }
                break;

            case PLUS:
            case MINUS:
            case STAR:
            case DIV:
            case MOD:
                # if(DEBUG)
                printf("Expr: Expr +-*/% Expr\n");
                # endif

                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                Exp(T->ptr[1]);
                if (T->ptr[0]->type!=T->ptr[1]->type){
                    semantic_error(T->pos,"", "error(15): +-*/%运算的运算数类型不匹配");
                    break;
                }
                if(T->ptr[0]->type==CLASS||T->ptr[0]->col_num > 0||T->ptr[1]->col_num > 0){
                    semantic_error(T->pos,"", "error(25): 不可对数组量以及类类型量进行运算");
                    break;
                }
                T->type=T->ptr[0]->type;
                T->col_num=T->ptr[0]->col_num;
                T->offset=T->offset+T->ptr[0]->width+T->ptr[1]->width;
                //T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->width=T->ptr[0]->width+T->ptr[1]->width+4;
                break;

            case AUTOPLUS:
            case AUTOMINUS:
                if (T->ptr[0]->kind!=ID &&
                    T->ptr[0]->kind!=EXP_EXP && T->ptr[0]->kind!=EXP_ID)
                    semantic_error(T->pos,"", "error(13): 对非左值表达式进行自增、自减运算");
                else
                {
                    T->ptr[0]->offset=T->offset;
                    Exp(T->ptr[0]);
                    if(T->ptr[0]->col_num > 0){
                        semantic_error(T->pos,"", "error(13): 对非左值表达式进行自增、自减运算");
                        break;
                    }
                    if (T->ptr[0]->type != INT) {
                        semantic_error(T->pos, "", "error(14): 对非int型变量进行自增、自减运算");
                        break;
                    }
                    T->type=T->ptr[0]->type;
                    T->width=T->ptr[0]->width;
                    T->col_num=T->ptr[0]->col_num;
                    break;
                }
                break;
        }
    }
}

int match_param(int i,int pos,struct ASTNode *T)
{
    int j,num=symbolTable.symbols[i].paramnum;
    int type1,type2;
    if (num==0 && T==NULL) return 1;
    else if(T==NULL){
        semantic_error(pos,"", "error(6): 函数调用时参数个数不匹配，实参个数太少");
        return 0;
    }
    else T=T->ptr[0];

    for (j=1; j<=num; j++)
    {
        type1=symbolTable.symbols[i+j].type;  //形参类型
        if (T->kind==EXP_LIST) type2=T->ptr[0]->type;
        else type2=T->type;
        if (type1!=type2){
            semantic_error(pos,"", "error(7): 函数调用时实参和形参类型不匹配");
            return 0;
        }
        if (T->kind!=EXP_LIST && j<num){
            semantic_error(pos,"", "error(6): 函数调用时参数个数不匹配，实参个数太少");
            return 0;
        }
        else if (T->kind!=EXP_LIST)
            break;
        T=T->ptr[1];
    }
    if(j>num)
        semantic_error(pos,"", "error(6): 函数调用时参数个数不匹配，实参个数太多");
    return 1;
}

void semantic_Analysis(struct ASTNode *T)
{
    //对抽象语法树的先根遍历,按display的控制结构修改完成符号表管理和语义检查和TAC生成（语句部分）
    int rtn,num,width;
    struct ASTNode *T0;
    struct opn opn1,opn2,result;
    if (T)
    {

        switch (T->kind)
        {
            /* 类列表定义 */
            case CLASS_DEF_LIST:
                if (!T->ptr[0]) break;
                # if(DEBUG)
                printf("ClassDefList: ClassDef ClassDefList\n");
                # endif
                /* 访问类定义列表的第一个项目 */
                T->ptr[0]->offset=0;
                semantic_Analysis(T->ptr[0]);

                /* 将类的大小回填进偏移量中 */
                T->offset=T->ptr[0]->width;
                symbolTable.symbols[T->ptr[0]->place].offset=T->offset;

                # if(PRINT)
                prn_symbol();
                # endif

                /* 访问其他类的定义 */
                if (T->ptr[1]){
                    T->ptr[1]->offset=0;
                    semantic_Analysis(T->ptr[1]);
                }
                break;

            /* 处理类的定义，类名标识符偏移量为0，width为当前类的大小 */
            case CLASS_DEF:
                # if(DEBUG)
                printf("ClassDef: CLASS ID LC FieldList RC\n");
                # endif
                rtn=fillSymbolTable(T->type_id,newAlias(),0,CLASS_BEGIN+class_index.index ,'C',0);
                if (rtn==-1){
                    semantic_error(T->pos,T->type_id, "error(3): 类重复定义");
                    break;
                }
                else T->place=rtn;
                class_index.TX[class_index.index++] = rtn;
                if(T->ptr[1])
                {
                    T->ptr[1]->offset=0;
                    LEV++; semantic_Analysis(T->ptr[1]); LEV--;
                    T->width=T->ptr[1]->width;
                }
                break;

            /* 类函数与数据成员定义 */
            case FIELD_LIST:
                # if(DEBUG)
                printf("FieldList: Field FieldList\n");
                printf("Field: VariableDef | FunctionDef\n");
                # endif
                /* 访问类函数与数据集成员定义列表 */
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->width=T->ptr[0]->width;
                if (T->ptr[1])
                {
                    T->ptr[1]->offset = T->offset + T->ptr[0]->width;
                    semantic_Analysis(T->ptr[1]);
                    T->width+=T->ptr[1]->width;
                }
                break;

            /* 变量定义，将(TYPE结点)的type送到IDlist的type域 */
            case VAR_DEF:
                # if(DEBUG)
                printf("VariableDef: Type IDList SEMI\n");
                # endif
                type_find(T->ptr[0]);
                T->type = T->ptr[0]->type;
                T->col_num = T->ptr[0]->col_num;
                T->index_class = T->ptr[0]->index_class;
                if(T->type==VOID)
                {
                    semantic_error(T->pos ,"error(20): 不得声明void类型的参数或变量 ", T->type_id);
                    break;
                }
                /* 将类型信息向变量定义列表传递，
                    如果类型为基本类型int、float、char则只需要传递type信息，
                    如果类型为类类型，则type为CLASS，需要传递类名的索引index_class，
                    如果是数组类型，则col_num数值大于0
                    */
                if(T->type == CLASS)
                {
                    if(T->index_class < 0)
                    {
                        semantic_error(T->pos, "error(21): 使用未定义的类 ", T->ptr[0]->type_id);
                        break;
                    }
                    /* 该类中不得声明自身变量 */
                    if(LEV==1 && T->index_class==class_index.TX[class_index.index-1])
                    {
                        semantic_error(T->pos,"", "error(22): 嵌套定义当前正在定义的类");
                        break;
                    }
                }

                T->ptr[1]->offset = T->offset;
                T->ptr[1]->type = T->type;
                T->ptr[1]->col_num = T->col_num;
                T->ptr[1]->index_class = T->index_class;
                /* 类类型与数组类型使用引用变量的形式存在，使用地址存放 */
                if(T->type==CHAR) T->ptr[1]->width=1;
                else T->ptr[1]->width=4;

                id_list(T->ptr[1]);
                T->num=T->ptr[1]->num;
                if(T->type==CHAR && T->col_num==0) T->width=T->ptr[1]->num;
                else T->width=4 * T->ptr[1]->num;
                break;

            /* 函数定义 */
            case FUNC_DEF_ACT:
                # if(DEBUG)
                printf("FunctionDef: Type ID LP Formals RP StmtBlock\n");
                # endif
                type_find(T->ptr[0]);
                T->type = T->ptr[0]->type;
                T->col_num = T->ptr[0]->col_num;
                T->width=0;     //函数的宽度设置为0
                T->offset=DX;   //设置局部变量在活动记录中的偏移量初值
                //函数不在数据区中分配单元，偏移量为0
                rtn=fillSymbolTable(T->type_id,"",LEV,T->type,'F',0);
                if (rtn==-1){
                    semantic_error(T->pos, "error(3): 函数重复定义 ",T->type_id);
                    break;
                }
                else T->place=rtn;
                //判断是否有参数
                if (T->ptr[2])
                {
                    T->ptr[2]->offset=T->offset;
                    semantic_Analysis(T->ptr[2]);  //处理函数参数列表
                    T->width=T->ptr[2]->width;
                    symbolTable.symbols[rtn].paramnum=T->ptr[2]->num;

                    //用形参单元宽度修改函数局部变量的起始偏移量
                    T->offset+=T->ptr[2]->width;
                }
                else symbolTable.symbols[rtn].paramnum=0,T->width=0;

                # if(PRINT)
                prn_symbol();
                # endif

                T->ptr[3]->offset=T->offset;
                flag_loop=0;
                semantic_Analysis(T->ptr[3]);         //处理函数体结点
                num = symbolTable.index;
                do num--;
                while (symbolTable.symbols[num].flag != 'F');

                if(T->ptr[3]->return_flag==0 && symbolTable.symbols[num].type!=VOID)
                    semantic_error(T->pos, "error(17): 函数没有返回语句（当函数返回值类型不是void时） ",T->type_id);
                //计算活动记录大小,这里offset属性存放的是活动记录大小，不是偏移
                T->width=0;
                symbolTable.symbols[T->place].offset=T->offset+T->ptr[3]->width;

                # if(PRINT)
                prn_symbol();
                # endif

                break;

            /* 函数参数定义 */
            case FORMALS_DEF:
                # if(DEBUG)
                printf("Formals: VariableList\n");
                # endif
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->num=T->ptr[0]->num;        //统计参数个数
                T->width=T->ptr[0]->width;    //累加参数单元宽度
                break;

            /* 函数参数列表定义 */
            case VAR_DEF_LIST:
                # if(DEBUG)
                printf("VariableList: Variable COMMA VariableList\n");
                # endif
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                semantic_Analysis(T->ptr[1]);
                T->num=1+T->ptr[1]->num;        //统计参数个数
                T->width=T->ptr[0]->width+T->ptr[1]->width;  //累加参数单元宽度
                break;

            /* 函数参数声明 */
            case VAR_DEF_S:
                # if(DEBUG)
                printf("Variable: Type ID\n");
                # endif
                type_find(T->ptr[0]);
                T->type = T->ptr[0]->type;
                T->col_num = T->ptr[0]->col_num;
                T->index_class = T->ptr[0]->index_class;
                if(T->type==VOID)
                {
                    semantic_error(T->pos, "error(20): 不得声明void类型的参数或变量 ",T->type_id);
                    break;
                }

                /* 将类型信息向变量定义列表传递，
                    如果类型为基本类型int、float、char则只需要传递type信息，
                    如果类型为类类型，则type为CLASS，需要传递类名的索引index_class，
                    如果是数组类型，则col_num数值大于0
                    */
                if(T->type==CLASS && T->index_class<0){
                        semantic_error(T->pos, "error(21): 使用未定义的类 ", T->ptr[0]->type_id);
                        break;
                }

                char temp; if(T->col_num > 0) temp = 'Q'; else temp = 'P';
                rtn=fillSymbolTable(T->type_id,newAlias(),2,T->type,temp,T->offset);
                if (rtn==-1){
                    semantic_error(T->pos,"error(3): 参数重复定义 ",T->type_id);
                    T->num=0; break;
                }
                else T->place=rtn;
                if(T->type == CLASS)
                    symbolTable.symbols[symbolTable.index-1].index_class=T->index_class;
                else symbolTable.symbols[symbolTable.index-1].index_class=-1;
                T->num=1;
                if(T->type==CHAR && T->col_num==0) T->width=1;
                else T->width=4;
                break;

            case STMT_BLOCK:
                # if(DEBUG)
                printf("StmtBlock: LC StmtList RC\n");
                # endif
                /* 层号加1，保存该层局部变量在符号表中的起始位置 */
                LEV++; symbol_scope_TX.TX[symbol_scope_TX.top++]=symbolTable.index;
                if (T->ptr[0])
                {
                    T->ptr[0]->offset=T->offset;
                    semantic_Analysis(T->ptr[0]);
                    T->width=T->ptr[0]->width;
                    T->return_flag=T->ptr[0]->return_flag;
                    T->return_pos=T->ptr[0]->return_pos;
                }
                else{
                    T->width=0;
                    T->return_flag=0;
                    T->return_pos=T->pos;
                }

                /* 层号减1，删除该作用域中的符号 */
                # if(PRINT)
                prn_symbol();
                # endif
                LEV--;  symbolTable.index=symbol_scope_TX.TX[--symbol_scope_TX.top]; //
                break;

            case STMT_LIST:
                # if(DEBUG)
                printf("StmtList: Stmt StmtList\n");
                # endif

                if(T->ptr[0])
                {
                    T->ptr[0]->offset=T->offset;
                    semantic_Analysis(T->ptr[0]);
                    T->width=T->ptr[0]->width;  //累加参数单元宽度

                    T->return_flag=T->ptr[0]->return_flag;
                    T->return_pos=T->ptr[0]->return_pos;
                }
                if(T->ptr[1])
                {
                    if(T->ptr[0]) T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                    else T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);

                    /* 如果当前的块为复杂块，且比原活动记录大则替换 */
                    if(T->ptr[0] && T->ptr[1]->width>T->width && (T->ptr[0]->kind==IF_STMT
                                     || T->ptr[0]->kind==WHILE_STMT
                                     || T->ptr[0]->kind==IF_ELSE_STMT
                                     || T->ptr[0]->kind==FOR_STMT
                                     || T->ptr[0]->kind==STMT_BLOCK )) T->width=T->ptr[1]->width;
                    else T->width+=T->ptr[1]->width;
                    T->return_flag=T->ptr[1]->return_flag;
                    T->return_pos=T->ptr[1]->return_pos;
                }
                break;

            case IF_STMT:
                # if(DEBUG)
                printf("IfStmt: IF LP Expr RP Stmt\n");
                # endif
                T->ptr[0]->offset=T->offset;
                boolExp(T->ptr[0]);
                T->width=T->ptr[0]->width;
                if(T->ptr[1])
                {
                    T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);
                    T->width+=T->ptr[1]->width;
                    T->return_flag=T->ptr[1]->return_flag;
                    T->return_pos=T->ptr[1]->return_pos;
                }
                break;

            case IF_ELSE_STMT:
                # if(DEBUG)
                printf("IfStmt: IF LP Expr RP Stmt ELSE Stmt\n");
                # endif
                T->ptr[0]->offset=T->offset;
                boolExp(T->ptr[0]);
                if(T->ptr[1])
                {
                    T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);
                    T->width=T->ptr[1]->width;
                    T->return_flag=T->ptr[1]->return_flag;
                    T->return_pos=T->ptr[1]->return_pos;
                }
                if(T->ptr[2])
                {
                    T->ptr[2]->offset=T->offset;
                    semantic_Analysis(T->ptr[2]);
                    if(T->width<T->ptr[2]->width)
                        T->width=T->ptr[2]->width;
                    if(T->ptr[2]->return_flag==0)
                    {
                        T->return_flag=T->ptr[2]->return_flag;
                        T->return_pos=T->ptr[2]->return_pos;
                    }
                }
                T->width+=T->ptr[0]->width;
                break;

            case FOR_STMT:
                # if(DEBUG)
                printf("FOR LP SimpleStmt SEMI SimpleStmt SEMI SimpleStmt RP Stmt\n");
                # endif
                if(T->ptr[0])
                {
                    T->ptr[0]->offset=T->offset;
                    semantic_Analysis(T->ptr[0]);
                }
                if(T->ptr[1])
                {
                    T->ptr[1]->offset=T->offset;
                    boolExp(T->ptr[1]);
                }
                if(T->ptr[2])
                {
                    T->ptr[2]->offset=T->offset;
                    semantic_Analysis(T->ptr[2]);
                }
                if(T->ptr[3])
                {
                    flag_loop++;
                    T->ptr[3]->offset=T->offset;
                    semantic_Analysis(T->ptr[3]);
                    T->width=T->ptr[3]->width;
                    T->return_flag=T->ptr[3]->return_flag;
                    T->return_pos=T->ptr[3]->return_pos;
                    flag_loop--;
                }
                break;

            case WHILE_STMT:
                # if(DEBUG)
                printf("WhileStmt: WHILE LP Expr RP Stmt\n");
                # endif

                T->ptr[0]->offset=T->offset;
                boolExp(T->ptr[0]);
                if(T->ptr[1])
                {
                    flag_loop++;
                    T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);
                    T->width=T->ptr[1]->width;
                    T->return_flag=T->ptr[1]->return_flag;
                    T->return_pos=T->ptr[1]->return_pos;
                    flag_loop--;
                }
                break;

            case CONTINUE_STMT:
                # if(DEBUG)
                printf("ContinueStmt: CONTINUE\n");
                # endif
                T->return_flag=0;
                T->return_pos=T->pos;
                if(flag_loop==0)
                    semantic_error(T->pos, "error(19): continue语句不在循环语句中 ", "");

                break;
            case BREAK_STMT:
                # if(DEBUG)
                printf("BreakStmt: BREAK\n");
                # endif
                T->return_flag=0;
                T->return_pos=T->pos;
                if(flag_loop==0)
                    semantic_error(T->pos, "error(18): break语句不在循环语句中 ", "");
                break;

            /*  */
            case RETURN:
                # if(DEBUG)
                printf("ReturnStmt: RETURN\n");
                # endif
                num = symbolTable.index;
                do num--;
                while (symbolTable.symbols[num].flag != 'F');
                if(symbolTable.symbols[num].type != VOID)
                    semantic_error(T->pos,"", "error(16): 函数返回值类型与函数定义的返回值类型不匹配");
                T->return_flag=1;
                T->return_pos=T->pos;
                break;

            /*  */
            case RETURN_EXP:
                # if(DEBUG)
                printf("ReturnStmt: RETURN EXPR\n");
                # endif

                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                num = symbolTable.index;
                do num--;
                while (symbolTable.symbols[num].flag != 'F');
                if (T->ptr[0]->type != symbolTable.symbols[num].type)
                    semantic_error(T->pos,"", "error(16): 函数返回值类型与函数定义的返回值类型不匹配");
                T->return_flag=1;
                T->return_pos=T->pos;
                break;

            case PRINT_STMT:
            case SCAN_STMT:
                # if(DEBUG)
                printf("PRINT_STMT | SCAN_STMT\n");
                # endif
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->num=T->ptr[0]->num;
                T->return_flag=0;
                T->return_pos=T->pos;
                break;

            case ACTUALS:
                # if(DEBUG)
                printf("Actuals: ExprList\n");
                # endif
                T->ptr[0]->place=T->place;
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->num=T->ptr[0]->num;
                T->width=T->ptr[0]->width;
                break;

            case EXP_LIST:
                # if(DEBUG)
                printf("ExprList: Expr COMMA ExprList | Expr \n");
                # endif

                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                T->ptr[1]->place=T->place+1;
                Exp(T->ptr[1]);
                T->num=T->ptr[0]->num+T->ptr[1]->num;        //统计参数个数
                T->width=T->ptr[0]->width+T->ptr[1]->width;  //累加参数单元宽度
                break;

            /*  */
            case ID:
            case INT:
            case FLOAT:
            case NULL_P:
            case TRUE:
            case FALSE:
            case THIS:
            case PLUSASSIGNOP:
            case MINUSASSIGNOP:
            case STARASSIGNOP:
            case DIVASSIGNOP:
            case MODASSIGNOP:
            case ASSIGNOP:
            case AND:
            case OR:
            case RELOP:
            case PLUS:
            case MINUS:
            case STAR:
            case DIV:
            case MOD:
            case AUTOPLUS:
            case AUTOMINUS:
            case NOT:
            case UMINUS:
            case NEW_ID:
            case ID_ACTUALS:
            case EXP_ID_ACTUALS:
            case EXP_EXP:
            case EXP_ID:
            case NEW_ID_ARR:
                Exp(T);          //处理基本表达式
                break;
        }
    }
}













