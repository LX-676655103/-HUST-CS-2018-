该实验采用DAG优化，并进行了在全局删除未引用变量。

请在windows系统下执行auto.bat批处理文件，优化的结果将输出到result.txt中。