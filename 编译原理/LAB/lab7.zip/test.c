class Point
{
    int x,y;
    int trans()
    {
        int temp;
        temp = x;
        x = y;
        y = temp;
        return 0;
    }
}

class Main
{
    int main()
    {
        int a,i;
        class Point[5] p_array;

        for(i=0;i<a;i++)
        {
            p_array[i].x=i;
            p_array[i].y=20-i;
            p_array[i].trans();
        }
        return 0;
    }
}









