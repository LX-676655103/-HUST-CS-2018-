#include "def.h"
#define DEBUG 0
#define PRINT 0
#define CLASS_BEGIN 20
int flag_loop;
int this_place;

/* 搜索符号表，查找当前符号是否已经存在 */
int searchSymbolTable(char *name)
{
    int i;
    for(i=symbolTable.index-1; i>=0; i--)
    {
        if (symbolTable.symbols[i].level==0) break;
        if (!strcmp(symbolTable.symbols[i].name, name))  return i;
    }
    return -1;
}

/* 生成新的符号表项 */
int fillSymbolTable(char *name,char *alias,int level,int type,char flag,int offset)
{
    /* 符号查重 */
    int i;
    /* 函数形参名 & 类数据成员名称可以相同 */
    if(flag == 'C')
    {
        for(i=0; i<class_index.index; i++)
            if (!strcmp(symbolTable.symbols[class_index.TX[i]].name, name))
                return -1;
    }
    else
    {
        /* 类数据成员以及外层变量可以被内层变量覆盖 */
        for(i=symbolTable.index-1; i>=0 && (symbolTable.symbols[i].level==level || level==1) ; i--)
        {
            /* 同名函数查找 */
            if (symbolTable.symbols[i].level==0) break;
            if (level==1 && symbolTable.symbols[i].level==2) continue;
            if (!strcmp(symbolTable.symbols[i].name, name)) return -1;
        }
    }
/* 填写符号表内容 */
    strcpy(symbolTable.symbols[symbolTable.index].name,name);
    strcpy(symbolTable.symbols[symbolTable.index].alias,alias);
    symbolTable.symbols[symbolTable.index].level=level;
    symbolTable.symbols[symbolTable.index].type=type;
    symbolTable.symbols[symbolTable.index].flag=flag;
    symbolTable.symbols[symbolTable.index].offset=offset;
    symbolTable.symbols[symbolTable.index].is_pointer=0;

    /* 返回的是符号在符号表中的位置序号，中间代码生成时可用序号取到符号别名 */
    return symbolTable.index++;
}

/* 填写临时变量到符号表，返回临时变量在符号表中的位置 */
int fill_Temp(char *name,int level,int type,char flag,int offset)
{
    strcpy(symbolTable.symbols[symbolTable.index].name,"");
    strcpy(symbolTable.symbols[symbolTable.index].alias,name);
    symbolTable.symbols[symbolTable.index].level=level;
    symbolTable.symbols[symbolTable.index].type=type;
    symbolTable.symbols[symbolTable.index].flag=flag;
    symbolTable.symbols[symbolTable.index].offset=offset;
    return symbolTable.index++; //返回的是临时变量在符号表中的位置序号
}

/* 标识符类型函数 */
void type_find(struct ASTNode *T)
{
    int i;
    switch (T->kind)
    {
        case TYPE:
            # if(DEBUG)
            printf("TYPE:\n");
            # endif
            T->col_num = 0;
            T->index_class = -1;
            /* 如果当前类型为类类型 */
            if(T->type==CLASS)
                /* 查找当前类是否已经定义 */
                for(i=0; i<class_index.index; i++)
                    if (!strcmp(symbolTable.symbols[class_index.TX[i]].name, T->type_id))
                        T->index_class = class_index.TX[i];
            return;
        case TYPE_COL:
            # if(DEBUG)
            printf("TYPE[]:\n");
            # endif
            type_find(T->ptr[0]);
            /* 数组的维数+1，内情向量记录数组的上限 */
            T->col_num = T->ptr[0]->col_num + 1;
            index_array[T->ptr[0]->col_num] = T->type_int;

            /* 向上传递类型信息 */
            T->index_class = T->ptr[0]->index_class;
            T->type = T->ptr[0]->type;
            strcpy(T->type_id,T->ptr[0]->type_id);
            break;
    }
}

/* 生成内情向量，将数组的各个维度的上限存入符号表中 */
void fill_array(int num, int index)
{
    int i;
    for(i=0;i<num;i++)
        symbolTable.symbols[index].index_array[i]=index_array[i];
}

/* 处理变量列表函数 */
void id_list(struct ASTNode *T)
{
    char temp;
    int rtn,num=1;
    switch (T->kind)
    {
        case ID_DEF_LIST:
            # if(DEBUG)
            printf("IDList: ID COMMA IDList\n");
            # endif
            /* 将第一个结点放入符号表 */
            if(T->col_num > 0) temp = 'A';
            else temp = 'V';
            rtn=fillSymbolTable(T->type_id,newAlias(),LEV,T->type,temp,T->offset);
            if (rtn==-1) semantic_error(T->pos, "error(3): 变量重复定义",T->type_id);

            /* 如果定义的变量是类变量，则将对应的类定义下标存入符号表 */
            else if(T->type == CLASS)  symbolTable.symbols[rtn].index_class=T->index_class;
            else symbolTable.symbols[rtn].index_class=-1;

            /* 如果变量为数组变量，则将内情向量填入符号表 */
            if(rtn!=-1 && T->col_num > 0) fill_array(T->col_num, rtn);
            symbolTable.symbols[rtn].paramnum=T->col_num;

            /* 处理第二个结点 */
            T->ptr[1]->type=T->type;
            T->ptr[1]->offset=T->offset+T->width;
            T->ptr[1]->width=T->width;
            T->ptr[1]->col_num = T->col_num;
            T->ptr[1]->index_class = T->index_class;
            id_list(T->ptr[1]);
            T->num=T->ptr[1]->num+1;
            break;

        case ID:
            # if(DEBUG)
            printf("IDList: ID\n");
            # endif
            if(T->col_num > 0) temp = 'A';
            else temp = 'V';
            rtn=fillSymbolTable(T->type_id,newAlias(),LEV,T->type,temp,T->offset);
            if (rtn==-1){ semantic_error(T->pos, "error(3): 变量重复定义",T->type_id);  T->num=1; break;}
            else T->place=rtn;

            /* 如果定义的变量是类变量，则将对应的类定义下标存入符号表 */
            if(T->type == CLASS) symbolTable.symbols[rtn].index_class=T->index_class;
            else symbolTable.symbols[rtn].index_class=-1;

            /* 如果变量为数组变量，则将内情向量填入符号表 */
            symbolTable.symbols[rtn].paramnum=T->col_num;
            if(rtn!=-1 && T->col_num > 0) fill_array(T->col_num, rtn);
            T->num=1;
            break;

    }
}

/* 处理bool表达式 */
void boolExp(struct ASTNode *T)
{
    struct opn opn1,opn2,result;
    int op;
    int rtn;
    if (T)
    {
        switch (T->kind)
        {
        case INT:
            if (T->type_int != 0) T->code = genGoto(T->Etrue);
			else T->code = genGoto(T->Efalse);
			T->width = 0;
			break;

        case FLOAT:
            if (T->type_float != 0.0) T->code = genGoto(T->Etrue);
			else T->code = genGoto(T->Efalse);
			T->width = 0;
			break;

        case CHAR:
            if (T->type_char != '0') T->code = genGoto(T->Etrue);
			else T->code = genGoto(T->Efalse);
			T->width = 0;
			break;

        case ID:
            rtn=searchSymbolTable(T->type_id);
            if (rtn==-1) semantic_error(T->pos, "error(1): 使用未定义的变量", T->type_id);
            else if (symbolTable.symbols[rtn].flag=='F') semantic_error(T->pos, "error(5): 对函数名采用非函数调用形式访问", T->type_id);
            else if (symbolTable.symbols[rtn].flag=='C') semantic_error(T->pos, "error(5): 对类名非法访问", T->type_id);
            else{
                if(symbolTable.symbols[rtn].type!=INT || symbolTable.symbols[rtn].paramnum > 0){
                    semantic_error(T->pos, "error(26): bool表达式中不可使用除int类型以外的变量", T->type_id);
                    break;
                }
                /* 中间代码生成
                    if ID!=0 goto true
                        else goto false */
                opn1.kind = ID;
				strcpy(opn1.id, symbolTable.symbols[rtn].alias);
				opn1.offset = symbolTable.symbols[rtn].offset;
				opn2.kind = INT;
				opn2.const_int = 0;
				result.kind = ID;
				strcpy(result.id, T->Etrue);
				T->code = genIR(NEQ, opn1, opn2, result);
				T->code = merge(2, T->code, genGoto(T->Efalse));
            }
            T->width = 0;
            break;

        case ID_ACTUALS:
            /* 查找符号表，并生成临时变量保存函数返回值 */
            Exp(T);
            if(symbolTable.symbols[T->place].type!=INT){
                semantic_error(T->pos, "error(26): bool表达式中直接调用函数，返回值只能使用int类型", T->type_id);
                break;
            }
            /* 中间代码生成
                    if returnTemp!=0 goto true
                        else goto false */
            opn1.kind = ID;
            strcpy(opn1.id, symbolTable.symbols[T->place].alias);
            opn1.offset = symbolTable.symbols[T->place].offset;
            opn2.kind = INT;
            opn2.const_int = 0;
            result.kind = ID;
            strcpy(result.id, T->Etrue);
            T->code = merge(2, T->code, genIR(NEQ, opn1, opn2, result));
            T->code = merge(2, T->code, genGoto(T->Efalse));
            break;

        case EXP_ID: case EXP_ID_ACTUALS:
        case EXP_EXP: case THIS:
            semantic_error(T->pos, "error(26): bool表达式中禁止此行为", T->type_id);
            break;
        case NULL_P: case FALSE:
            T->code = genGoto(T->Efalse);
			T->width = 0;
			break;
        case TRUE:
            T->code = genGoto(T->Etrue);
			T->width = 0;
			break;

        /* 处理关系运算表达式,2个操作数都按基本表达式处理 */
        case RELOP:
            T->ptr[0]->offset=T->ptr[1]->offset=T->offset;
            Exp(T->ptr[0]);
            T->width=T->ptr[0]->width;
            Exp(T->ptr[1]);
            if (T->ptr[0]->type!=T->ptr[1]->type){
                semantic_error(T->pos,"", "error(15): RELOP运算数类型不匹配");
                break;
            }
            if(T->ptr[0]->type==CLASS || T->ptr[0]->col_num>0 || T->ptr[1]->col_num>0){
                semantic_error(T->pos,"", "error(25): 不可对数组量以及类类型量进行比较运算");
                break;
            }
            if (T->width<T->ptr[1]->width) T->width=T->ptr[1]->width;
            opn1.kind = ID;
			strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
			opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
			opn2.kind = ID;
			strcpy(opn2.id, symbolTable.symbols[T->ptr[1]->place].alias);
			opn2.offset = symbolTable.symbols[T->ptr[1]->place].offset;
			result.kind = ID;
			strcpy(result.id, T->Etrue);
			if (strcmp(T->type_id, "<") == 0) op = JLT;
			else if (strcmp(T->type_id, "<=") == 0) op = JLE;
			else if (strcmp(T->type_id, ">") == 0) op = JGT;
			else if (strcmp(T->type_id, ">=") == 0) op = JGE;
			else if (strcmp(T->type_id, "==") == 0) op = EQ;
			else if (strcmp(T->type_id, "!=") == 0) op = NEQ;
			T->code = merge(4, T->ptr[0]->code, T->ptr[1]->code,
                   genIR(op, opn1, opn2, result), genGoto(T->Efalse));
			break;
        case AND:
        case OR:
            # if(DEBUG)
            printf("Expr: Expr && || Expr\n");
            # endif
            if (T->kind == AND){
				strcpy(T->ptr[0]->Etrue, newLabel());
				strcpy(T->ptr[0]->Efalse, T->Efalse);
			}
			else{
				strcpy(T->ptr[0]->Etrue, T->Etrue);
				strcpy(T->ptr[0]->Efalse, newLabel());
			}
			strcpy(T->ptr[1]->Etrue, T->Etrue);
			strcpy(T->ptr[1]->Efalse, T->Efalse);

            T->ptr[0]->offset=T->ptr[1]->offset=T->offset;
            boolExp(T->ptr[0]);
            T->width=T->ptr[0]->width;
            boolExp(T->ptr[1]);
            if (T->width<T->ptr[1]->width) T->width=T->ptr[1]->width;
            if (T->kind == AND) T->code = merge(3, T->ptr[0]->code, genLabel(T->ptr[0]->Etrue), T->ptr[1]->code);
			else T->code = merge(3, T->ptr[0]->code, genLabel(T->ptr[0]->Efalse), T->ptr[1]->code);
			break;
        case NOT:
            strcpy(T->ptr[0]->Etrue, T->Efalse);
			strcpy(T->ptr[0]->Efalse, T->Etrue);
            T->ptr[0]->offset=T->offset;
            boolExp(T->ptr[0]);
            T->code = T->ptr[0]->code;
            break;
        default:
            Exp(T);
            break;
        }
    }
}

/* 赋值以及+=等符号的类型检查 */
void assign_op(struct ASTNode *T)
{
    if (T)
    {
        if (T->ptr[0]->kind!=ID && T->ptr[0]->kind!=EXP_EXP && T->ptr[0]->kind!=EXP_ID)
            semantic_error(T->pos,"", "error(12): 赋值号左边不是左值表达式");
        else{
            T->ptr[0]->offset=T->offset;
            Exp(T->ptr[0]);
            if(T->ptr[0]->col_num > 0){
                semantic_error(T->pos,"", "error(12): 赋值号左边不是左值表达式(数组维数错误)");
                return;
            }
            T->ptr[1]->offset=T->offset+T->ptr[0]->width;
            Exp(T->ptr[1]);
            /* 类型匹配 */
            if(T->ptr[1]->type!=T->ptr[0]->type)
                semantic_error(T->pos,"", "error(15): 赋值语句两端类型不匹配");
            T->type=T->ptr[0]->type;
            T->width=T->ptr[0]->width+T->ptr[1]->width;
        }
    }
}

/* 处理函数的参数个数以类型的匹配 */
int match_param(int i,int pos,struct ASTNode *T)
{
    int j,num=symbolTable.symbols[i].paramnum;
    int type1,type2;

    /* 如果函数形参与实参个数都为0 */
    if (num==1 && T==NULL) return 1;
    else if(T==NULL){
        semantic_error(pos,"", "error(6): 函数调用时参数个数不匹配，实参个数太少");
        return 0;
    }
    else T=T->ptr[0];

    for (j=2; j<=num; j++)
    {
        type1=symbolTable.symbols[i+j].type;  //形参类型
        if (T->kind==EXP_LIST) type2=T->ptr[0]->type;
        else type2=T->type;
        if (type1!=type2){
            semantic_error(pos,"", "error(7): 函数调用时实参和形参类型不匹配");
            return 0;
        }
        if (T->kind!=EXP_LIST && j<num){
            semantic_error(pos,"", "error(6): 函数调用时参数个数不匹配，实参个数太少");
            return 0;
        }
        else if (T->kind!=EXP_LIST) break;
        T=T->ptr[1];
    }
    if(j>num)
        semantic_error(pos,"", "error(6): 函数调用时参数个数不匹配，实参个数太多");
    return 1;
}
/* 处理一般表达式，函数体中出现bool表达式不合法 */
void Exp(struct ASTNode *T)
{
    int i, find_flag=0,op;
    int rtn,num,width;
    struct ASTNode *T0;
    struct opn opn1,opn2,result;
    if (T)
    {
        switch (T->kind)
        {
            /* 查符号表，获得符号表中的位置，类型送type */
            case ID:
                # if(DEBUG)
                printf("Expr: ID\n");
                # endif
                /* 查找符号表 */
                rtn=searchSymbolTable(T->type_id);
                if (rtn==-1) semantic_error(T->pos, "error(1): 使用未定义的变量", T->type_id);
                else if (symbolTable.symbols[rtn].flag=='F')
                    semantic_error(T->pos, "error(5): 对函数名采用非函数调用形式访问", T->type_id);
                else if (symbolTable.symbols[rtn].flag=='C')
                    semantic_error(T->pos, "error(5): 对类名非法访问", T->type_id);
                else{
                    /* 向上传递信息 */
                    T->col_num=symbolTable.symbols[rtn].paramnum;
                    T->place=rtn;       //结点保存变量在符号表中的位置
                    T->index_class=symbolTable.symbols[rtn].index_class;
                    T->type=symbolTable.symbols[rtn].type;
                    T->width=0;         //未再使用新单元
                    T->flag=symbolTable.symbols[rtn].flag;
                    T->code=NULL;       //标识符不需要生成TAC
                }
                /* 如果当前变量为类变量 */
                if(symbolTable.symbols[rtn].level==1)
                {
                    /* 如果当前变量为类变量 newtemp=this+offset(v) */
                    rtn=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);

                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[this_place].alias);
                    opn1.offset = symbolTable.symbols[this_place].offset;
                    opn2.kind = INT;
                    opn2.const_int = symbolTable.symbols[T->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[rtn].alias);
                    result.offset = symbolTable.symbols[rtn].offset;
                    T->code = genIR(PLUS, opn1, opn2, result);
                    symbolTable.symbols[rtn].is_pointer=1;
                    T->place=rtn;
                    T->width=4;
                }
                break;

            case ID_ACTUALS:
                # if(DEBUG)
                printf("Expr: ID (Actuals)\n");
                # endif
                /* 查找符号表 */
                rtn=searchSymbolTable(T->type_id); T->width=0;
                if (rtn==-1){
                    semantic_error(T->pos, "error(2): 调用未定义或未声明的函数 " ,T->type_id);
                    break;
                }
                if (symbolTable.symbols[rtn].flag!='F'){
                    semantic_error(T->pos, "error(4): 对非函数名采用函数调用形式 ", T->type_id);
                    break;
                }

                /* 参数不为空时，进行语义分析 */
                if (T->ptr[1])
                {
                    T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);
                    T->width=T->ptr[1]->width;
                    T->code=T->ptr[1]->code;
                }
                else T->code = NULL;

                /* 处理所有参数的匹配 */
                match_param(rtn,T->pos,T->ptr[1]);

                /* 中间代码生成，生成实参序列 */
                /* 生成this指针 */
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[class_index.TX[class_index.index-1]].alias);
                result.offset = symbolTable.symbols[class_index.TX[class_index.index-1]].offset;
                T->code = merge(2, T->code, genIR(ARG, opn1, opn2, result));

                /* 生成实参序列 */
                T0 = T->ptr[1];
                if(T0){
                    T0 = T0->ptr[0];
                    while (T0->kind==EXP_LIST)
                    {
                        result.kind = ID;
                        strcpy(result.id, symbolTable.symbols[T0->ptr[0]->place].alias);
                        result.offset = symbolTable.symbols[T0->ptr[0]->place].offset;
                        T->code = merge(2, T->code, genIR(ARG, opn1, opn2, result));
                        T0 = T0->ptr[1];
                    }
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T0->place].alias);
                    result.offset = symbolTable.symbols[T0->place].offset;
                    T->code = merge(2, T->code, genIR(ARG, opn1, opn2, result));
                }


                /* 类型检查，用于生成返回值临时变量 */
                T->type=symbolTable.symbols[rtn].type;
                /* 中间代码生成，保存函数调用 */
                T->place = fill_Temp(newTemp(),LEV, T->type,'T', T->offset+T->width);
                width = T->type == VOID ? 0 : 4;
                T->width+=width;

                opn1.kind = ID;
                strcpy(opn1.id, T->type_id);
                /* 这里offset用以保存函数定义入口，在目标代码生成时，能获取相应信息 */
                opn1.offset = rtn;
                strcpy(result.id, symbolTable.symbols[T->place].alias);
                result.offset = symbolTable.symbols[T->place].offset;
                T->code = merge(2, T->code, genIR(CALL, opn1, opn2, result));
                break;

            case EXP_ID:
                # if(DEBUG)
                printf("Expr: Expr.ID\n");
                # endif
                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                if(T->ptr[0]->type!=CLASS || T->ptr[0]->col_num>0){
                    semantic_error(T->pos,"", "error(10): 对非结构变量采用成员选择运算符‘.’");
                    break;
                }

                /* 查找当前类中是否含有数据成员ID */
                i = T->ptr[0]->index_class, find_flag=0;
                while(symbolTable.symbols[++i].level != 0)
                    if(!strcmp(symbolTable.symbols[i].name, T->type_id)
                        && symbolTable.symbols[i].level == 1
                        && (symbolTable.symbols[i].flag=='V'
                            || symbolTable.symbols[i].flag=='A')){
                        find_flag = 1;
                        break;
                    }
                if(!find_flag) semantic_error(T->pos,"", "error(11): 结构成员不存在");
                else{
                    /* 存在该类成员，向上传递该类成员的信息 */
                    T->col_num=symbolTable.symbols[i].paramnum;
                    T->index_class=symbolTable.symbols[i].index_class;
                    T->type=symbolTable.symbols[i].type;
                    T->flag=symbolTable.symbols[i].flag;

                    /* 中间代码生成 */
                    /* 生成临时变量，用于计算目标变量的地址 */
                    rtn=fill_Temp(newTemp(),LEV,T->type,'T',T->offset+T->ptr[0]->width);
                    symbolTable.symbols[rtn].is_pointer=1;
                    T->width=T->ptr[0]->width + 4;

                    /* 生成*temp */
                    /* 如果子节点计算的临时变量保存的信息为地址信息 */
                    if(symbolTable.symbols[T->ptr[0]->place].is_pointer)
                    {
                        opn1.kind = ID;
                        strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                        opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                        result.kind = ID;
                        strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                        result.offset = opn1.offset;
                        T->code = merge(2, T->ptr[0]->code, genIR(EXP_POINT, opn1, opn2, result));
                        symbolTable.symbols[T->ptr[0]->place].is_pointer=0;
                    }
                    /* 生成temp=class+offset */
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    opn2.kind = INT;
                    opn2.const_int = symbolTable.symbols[i].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[rtn].alias);
                    result.offset = symbolTable.symbols[rtn].offset;
                    T->code = merge(2, T->code, genIR(PLUS, opn1, opn2, result));
                    T->place=rtn;
                }
                break;

            case EXP_ID_ACTUALS:
                # if(DEBUG)
                printf("Expr: Expr.ID (Actuals)\n");
                # endif
                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                if(T->ptr[0]->type!=CLASS || T->ptr[0]->col_num>0){
                    semantic_error(T->pos,"", "error(10): 对非结构变量采用成员选择运算符‘.’(数组或其他非变量类型)");
                    break;
                }

                /* 中间代码生成 */
                T->code=T->ptr[0]->code;

                /* 查找当前变量是否含有函数成员ID */
                i = T->ptr[0]->index_class, find_flag=0;
                while(symbolTable.symbols[++i].level != 0)
                    if(!strcmp(symbolTable.symbols[i].name, T->type_id)
                            && symbolTable.symbols[i].level == 1
                            && symbolTable.symbols[i].flag=='F'){
                        find_flag = 1;
                        break;
                    }
                if(!find_flag){
                    semantic_error(T->pos,"", "error(11): 结构成员不存在");
                    break;
                }

                /* 如果子节点计算的临时变量保存的信息为地址信息 */
                if(symbolTable.symbols[T->ptr[0]->place].is_pointer)
                {
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    result.offset = opn1.offset;
                    T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                    symbolTable.symbols[T->ptr[0]->place].is_pointer=0;
                }

                /* 向上传递信息 */
                T->flag=symbolTable.symbols[i].flag;
                T->index_class=symbolTable.symbols[i].index_class;
                T->type=symbolTable.symbols[i].type;
                T->flag=symbolTable.symbols[i].flag;

                if (T->ptr[2])
                {
                    T->ptr[2]->offset=T->offset+T->ptr[0]->width;
                    semantic_Analysis(T->ptr[2]);
                    T->width=T->ptr[0]->width+T->ptr[2]->width;
                    T->code=merge(2, T->code, T->ptr[2]->code);
                }
                /* 处理所有参数的匹配 */
                match_param(i,T->pos,T->ptr[2]);

                /* 中间代码生成，生成实参序列，首先生成类变量指针 */
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                result.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                T->code = merge(2, T->code, genIR(ARG, opn1, opn2, result));

                T0 = T->ptr[2];
                if(T0)
                {
                    T0=T0->ptr[0];
                    while (T0->kind==EXP_LIST)
                    {
                        result.kind = ID;
                        strcpy(result.id, symbolTable.symbols[T0->ptr[0]->place].alias);
                        result.offset = symbolTable.symbols[T0->ptr[0]->place].offset;
                        T->code = merge(2, T->code, genIR(ARG, opn1, opn2, result));
                        T0 = T0->ptr[1];
                    }
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T0->place].alias);
                    result.offset = symbolTable.symbols[T0->place].offset;
                    T->code = merge(2, T->code, genIR(ARG, opn1, opn2, result));
                }

                /* 中间代码生成，保存函数调用 */
                T->place = fill_Temp(newTemp(), LEV, T->type, 'T', T->offset+T->width);
                width = T->type == VOID ? 0 : 4; T->width+=width;

                opn1.kind = ID;
                strcpy(opn1.id, T->type_id); //保存函数名
                opn1.offset = rtn; //这里offset用以保存函数定义入口,在目标代码生成时，能获取相应信息
                strcpy(result.id, symbolTable.symbols[T->place].alias);
                result.offset = symbolTable.symbols[T->place].offset;
                T->code = merge(2, T->code, genIR(CALL, opn1, opn2, result));
                break;

            case EXP_EXP:
                # if(DEBUG)
                printf("Expr: Expr[Expr]\n");
                # endif
                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                if(T->ptr[0]->col_num==0
                   || (T->ptr[0]->flag!='Q'
                    && T->ptr[0]->flag!='A')){
                    semantic_error(T->pos,"", "error(8): 对非数组变量采用下标变量的形式访问");
                    break;
                }
                T->code = T->ptr[0]->code;

                /* 查找当前变量是否含有数据成员ID */
                T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                Exp(T->ptr[1]);
                if(T->ptr[1]->type!=INT)
                    semantic_error(T->pos,"", "error(9): 数组变量的下标不是整型表达式");
                else
                {
                    T->flag=T->ptr[0]->flag;
                    /* 数组维数下降 */
                    T->col_num=T->ptr[0]->col_num-1;
                    T->index_class=T->ptr[0]->index_class;
                    T->type=T->ptr[0]->type;
                    T->offset=T->ptr[0]->offset;
                    T->width=T->ptr[0]->width+T->ptr[1]->width;
                    T->code = merge(2, T->code, T->ptr[1]->code);

                    /* 中间代码生成 */
                    /* 如果0号子结点为ID或EXP.ID类型的结点，
                        将数组place存入T->num中*/
                    if(T->ptr[0]->kind==ID || T->ptr[0]->kind==EXP_ID)
                    {
                        T->num=T->ptr[0]->place;
                        /* 一维数组的处理 */
                        if(T->ptr[0]->col_num==1)
                        {
                            /* 生成语句temp=a+i*4 */
                            rtn = fill_Temp(newTemp(),LEV,INT,'T',T->offset+T->width);
                            T->width+=4;
                            opn1.kind = ID;
                            strcpy(opn1.id, symbolTable.symbols[T->ptr[1]->place].alias);
                            opn1.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                            opn2.kind = INT;
                            opn2.const_int=4;
                            result.kind = ID;
                            strcpy(result.id, symbolTable.symbols[rtn].alias);
                            result.offset = symbolTable.symbols[rtn].offset;
                            T->code = merge(2, T->code, genIR(STAR, opn1, opn2, result));
                            T->place=rtn;

                            opn1.kind = ID;
                            strcpy(opn1.id, symbolTable.symbols[T->place].alias);
                            opn1.offset = symbolTable.symbols[T->place].offset;
                            opn2.kind = ID;
                            strcpy(opn2.id, symbolTable.symbols[T->num].alias);
                            opn2.offset = symbolTable.symbols[T->num].offset;
                            result.kind = ID;
                            rtn = fill_Temp(newTemp(),LEV,INT,'T',T->offset+T->width);
                            symbolTable.symbols[rtn].is_pointer=1;
                            strcpy(result.id, symbolTable.symbols[rtn].alias);
                            result.offset = symbolTable.symbols[rtn].offset;
                            T->code = merge(2, T->code, genIR(PLUS, opn1, opn2, result));
                            T->place=rtn;
                            T->width+=4;
                        }
                        else
                        {
                            /* 多维数组第一个维度的处理 */
                            rtn = fill_Temp(newTemp(),LEV,INT,'T',T->offset+T->width);
                            symbolTable.symbols[rtn].is_pointer=1;
                            /* 生成语句i1*n2 */
                            opn1.kind = ID;
                            strcpy(opn1.id, symbolTable.symbols[T->ptr[1]->place].alias);
                            opn1.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                            opn2.kind = INT;
                            opn2.const_int = symbolTable.symbols[T->num].index_array[1];
                            result.kind = ID;
                            strcpy(result.id, symbolTable.symbols[rtn].alias);
                            result.offset = symbolTable.symbols[rtn].offset;
                            T->code = merge(2, T->code, genIR(STAR, opn1, opn2, result));
                            T->place=rtn;
                            T->width+=4;
                        }
                    }
                    else
                    {
                        T->num=T->ptr[0]->num;
                        rtn = fill_Temp(newTemp(),LEV,INT,'T',T->offset+T->width);
                        symbolTable.symbols[rtn].is_pointer=1;
                        /* 生成语句 （temp + in）*/
                        opn1.kind = ID;
                        strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                        opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                        opn2.kind = ID;
                        strcpy(opn2.id, symbolTable.symbols[T->ptr[1]->place].alias);
                        opn2.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                        result.kind = ID;
                        strcpy(result.id, symbolTable.symbols[rtn].alias);
                        result.offset = symbolTable.symbols[rtn].offset;
                        T->code = merge(2, T->code, genIR(PLUS, opn1, opn2, result));
                        T->place=rtn;
                        T->width+=4;

                        /* 最后一个维度的处理，不包括一维数组 */
                        if(T->ptr[0]->col_num==1)
                        {
                            /* 生成语句 （temp + in）+ a */
                            rtn = fill_Temp(newTemp(),LEV,INT,'T',T->offset+T->width);
                            T->width+=4;
                            opn1.kind = ID;
                            strcpy(opn1.id, symbolTable.symbols[T->place].alias);
                            opn1.offset = symbolTable.symbols[T->place].offset;
                            opn2.kind = INT;
                            opn2.const_int=4;
                            result.kind = ID;
                            strcpy(result.id, symbolTable.symbols[rtn].alias);
                            result.offset = symbolTable.symbols[rtn].offset;
                            T->code = merge(2, T->code, genIR(STAR, opn1, opn2, result));
                            T->place=rtn;

                            rtn = fill_Temp(newTemp(),LEV,INT,'T',T->offset+T->width);
                            symbolTable.symbols[rtn].is_pointer=1;
                            opn1.kind = ID;
                            strcpy(opn1.id, symbolTable.symbols[T->place].alias);
                            opn1.offset = symbolTable.symbols[T->place].offset;
                            opn2.kind = ID;
                            strcpy(opn2.id, symbolTable.symbols[T->num].alias);
                            opn2.offset = symbolTable.symbols[T->num].offset;
                            result.kind = ID;
                            strcpy(result.id, symbolTable.symbols[rtn].alias);
                            result.offset = symbolTable.symbols[rtn].offset;
                            T->code = merge(2, T->code, genIR(PLUS, opn1, opn2, result));
                            T->place=rtn;
                            T->width+=4;

                        }
                        else
                        {
                            /* 生成语句 （temp + in）* n_n+1 */
                            rtn = fill_Temp(newTemp(),LEV,INT,'T',T->offset+T->width);
                            symbolTable.symbols[rtn].is_pointer=1;
                            opn1.kind = ID;
                            strcpy(opn1.id, symbolTable.symbols[T->place].alias);
                            opn1.offset = symbolTable.symbols[T->place].offset;

                            opn2.kind = INT;
                            opn2.const_int = symbolTable.symbols[T->num].index_array[symbolTable.symbols[T->num].paramnum-T->col_num];
                            result.kind = ID;
                            strcpy(result.id, symbolTable.symbols[rtn].alias);
                            result.offset = symbolTable.symbols[rtn].offset;
                            T->code = merge(2, T->code, genIR(STAR, opn1, opn2, result));
                            T->place=rtn;
                            T->width+=4;
                        }
                    }
                }
                break;

            case INT:
                # if(DEBUG)
                printf("Expr: INT\n");
                # endif
                /* 为整常量生成一个临时变量 */
                T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type=INT; T->width=4;

                /* 中间代码生成 */
                opn1.kind = INT;
                opn1.const_int = T->type_int;
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[T->place].alias);
                result.offset = symbolTable.symbols[T->place].offset;
                T->code = genIR(ASSIGNOP, opn1, opn2, result);
                break;

            case FLOAT:
                # if(DEBUG)
                printf("Expr: FLOAT\n");
                # endif
                /* 为浮点常量生成一个临时变量 */
                T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type=FLOAT; T->width=4;

                /* 中间代码生成 */
                opn1.kind = FLOAT;
                opn1.const_float = T->type_float;
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[T->place].alias);
                result.offset = symbolTable.symbols[T->place].offset;
                T->code = genIR(ASSIGNOP, opn1, opn2, result);
                break;
            case CHAR:
                /* 为字符常量生成一个临时变量 */
                T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type = CHAR; T->width = 4;

                /* 中间代码生成 */
                opn1.kind = CHAR;
                opn1.const_char=T->type_char;
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[T->place].alias);
                result.offset = symbolTable.symbols[T->place].offset;
                T->code = genIR(ASSIGNOP, opn1, opn2, result);
                break;

            case NULL_P:
                # if(DEBUG)
                printf("Expr: null\n");
                # endif
                /* 为空常量生成一个临时变量 */
                T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->type = NULL_P; T->width = 4;

                /* 中间代码生成 */
                opn1.kind = INT;
                opn1.const_int = 0;
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[T->place].alias);
                result.offset = symbolTable.symbols[T->place].offset;
                T->code = genIR(ASSIGNOP, opn1, opn2, result);
                break;

            case TRUE:
            case FALSE:
                semantic_error(T->pos,"", "error(27): 非布尔表达式中不可使用true/false");
                break;

            case THIS:
                # if(DEBUG)
                printf("Expr: this\n");
                # endif
                T->flag='V'; T->col_num=0; T->type=CLASS;
                T->index_class=class_index.TX[class_index.index-1];
                T->place=this_place;
                break;

            /* 赋值语句的类型检查 */
            case ASSIGNOP:
                # if(DEBUG)
                printf("Expr: Expr = Expr\n");
                # endif
                assign_op(T);
                 T->code = merge(2, T->ptr[0]->code, T->ptr[1]->code);

                /* 如果赋值量为指针量，则生成语句 newtemp = *temp1 */
                if(symbolTable.symbols[T->ptr[1]->place].is_pointer==1)
                {
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[1]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[1]->place].offset;

                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->ptr[1]->place].alias);
                    result.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                    T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                }

                opn1.kind = ID;
                strcpy(opn1.id, symbolTable.symbols[T->ptr[1]->place].alias);
                opn1.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                result.offset = symbolTable.symbols[T->ptr[0]->place].offset;

                if(symbolTable.symbols[T->ptr[0]->place].is_pointer==1)
                    T->code = merge(2, T->code, genIR(POINT_EXP, opn1, opn2, result));
                else T->code = merge(2, T->code, genIR(ASSIGNOP, opn1, opn2, result));
                symbolTable.symbols[T->ptr[0]->place].is_pointer=0;
                break;

            case PLUSASSIGNOP:
            case MINUSASSIGNOP:
            case STARASSIGNOP:
            case DIVASSIGNOP:
            case MODASSIGNOP:
                # if(DEBUG)
                printf("Expr: Expr += -= *= /= %= Expr\n");
                # endif
                assign_op(T);
                if(T->kind==PLUSASSIGNOP) op=PLUS;
                if(T->kind==MINUSASSIGNOP) op=MINUS;
                if(T->kind==STARASSIGNOP) op=STAR;
                if(T->kind==DIVASSIGNOP) op=DIV;
                if(T->kind==MODASSIGNOP) op=MOD;
                T->place = T->ptr[0]->place;
                T->width = T->ptr[0]->width + T->ptr[1]->width;
                T->code = merge(2, T->ptr[0]->code, T->ptr[1]->code);

                if(symbolTable.symbols[T->ptr[1]->place].is_pointer)
                {
                    semantic_error(T->pos,"", "error(27): 右部非法，不得使用类成员以及数组变量");
                    break;
                }
                /* 如果子节点计算的临时变量保存的信息为地址信息
                    if(is_pointer) newtemp = *temp0
                    newtemp = newtemp + temp1
                    *temp0 = newtemp
                */
                if(symbolTable.symbols[T->ptr[0]->place].is_pointer)
                {
                    T->place=fill_Temp(newTemp(),LEV,T->ptr[0]->type,'T',T->offset+T->width);
                    T->width+=4;
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->place].alias);
                    result.offset = symbolTable.symbols[T->place].offset;
                    T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                }

                opn1.kind = ID;
                strcpy(opn1.id, symbolTable.symbols[T->place].alias);
                opn1.type = T->ptr[0]->type;
                opn1.offset = symbolTable.symbols[T->place].offset;
                opn2.kind = ID;
                strcpy(opn2.id, symbolTable.symbols[T->ptr[1]->place].alias);
                opn2.type = T->ptr[1]->type;
                opn2.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[T->place].alias);
                result.type = T->type;
                result.offset = symbolTable.symbols[T->place].offset;
                T->code = merge(2, T->code, genIR(op, opn1, opn2, result));

                if(symbolTable.symbols[T->ptr[0]->place].is_pointer)
                {
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->place].alias);
                    opn1.offset = symbolTable.symbols[T->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    result.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    T->code = merge(2, T->code, genIR(POINT_EXP, opn1, opn2, result));
                }
                break;

            /* 逻辑运算语句的类型检查 */
            case AND: case OR: case NOT: case RELOP:
                semantic_error(T->pos,"", "error(23): 逻辑运算不可出现在除if/while/for的函数体中");
                break;

            /* 负号只可以对int以及float量起效果 */
            case UMINUS:
                T->ptr[0]->offset = T->offset;
                Exp(T->ptr[0]);
                T->type = T->ptr[0]->type;
                if(T->type!=INT && T->type!=FLOAT)
                    semantic_error(T->pos,"", "error(24): 负号只能对int/float进行操作");
                else{
                    T->flag=T->ptr[0]->flag;
                    T->type=T->ptr[0]->type;
                    T->width=T->ptr[0]->width;
                    T->col_num=T->ptr[0]->col_num;

                    rtn = fill_Temp(newTemp(),LEV,INT,'T',T->offset+T->width);
                    opn1.kind = INT;
                    opn1.const_int = 0;
                    opn2.kind = ID;
                    strcpy(opn2.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    opn2.type = T->ptr[0]->type;
                    opn2.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[rtn].alias);
                    result.type = T->ptr[0]->type;
                    result.offset = symbolTable.symbols[rtn].offset;
                    T->code = merge(2, T->ptr[0]->code, genIR(MINUS, opn1, opn2, result));
                    T->width += 4;
                }
                break;

            case PLUS:
            case MINUS:
            case STAR:
            case DIV:
            case MOD:
                # if(DEBUG)
                printf("Expr: Expr +-*/% Expr\n");
                # endif

                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                Exp(T->ptr[1]);
                if (T->ptr[0]->type!=T->ptr[1]->type){
                    semantic_error(T->pos,"", "error(15): +-*/%运算的运算数类型不匹配");
                    break;
                }
                if(T->ptr[0]->type==CLASS||T->ptr[0]->col_num > 0||T->ptr[1]->col_num > 0){
                    semantic_error(T->pos,"", "error(25): 不可对数组量以及类类型量进行运算");
                    break;
                }
                T->type=T->ptr[0]->type;
                T->col_num=T->ptr[0]->col_num;
                T->offset=T->offset+T->ptr[0]->width+T->ptr[1]->width;
                T->place=fill_Temp(newTemp(),LEV,T->type,'T',T->offset);
                T->width=T->ptr[0]->width+T->ptr[1]->width+4;
                T->code = merge(2, T->ptr[0]->code, T->ptr[1]->code);

                /* 如果子节点计算的临时变量保存的信息为地址信息 */
                if(symbolTable.symbols[T->ptr[0]->place].is_pointer)
                {
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    result.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                    symbolTable.symbols[T->ptr[0]->place].is_pointer=0;
                }
                /* 如果子节点计算的临时变量保存的信息为地址信息 */
                if(symbolTable.symbols[T->ptr[1]->place].is_pointer)
                {
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[1]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->ptr[1]->place].alias);
                    result.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                    T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                    symbolTable.symbols[T->ptr[1]->place].is_pointer=0;
                }

                opn1.kind = ID;
                strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                opn1.type = T->ptr[0]->type;
                opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                opn2.kind = ID;
                strcpy(opn2.id, symbolTable.symbols[T->ptr[1]->place].alias);
                opn2.type = T->ptr[1]->type;
                opn2.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[T->place].alias);
                result.type = T->type;
                result.offset = symbolTable.symbols[T->place].offset;
                T->code = merge(2, T->code, genIR(T->kind, opn1, opn2, result));

                break;

            case AUTOPLUS:
            case AUTOMINUS:
                if (T->ptr[0]->kind!=ID &&
                    T->ptr[0]->kind!=EXP_EXP && T->ptr[0]->kind!=EXP_ID)
                    semantic_error(T->pos,"", "error(13): 对非左值表达式进行自增、自减运算");
                else
                {
                    T->ptr[0]->offset=T->offset;
                    Exp(T->ptr[0]);
                    T->code = T->ptr[0]->code;
                    if(T->ptr[0]->col_num > 0){
                        semantic_error(T->pos,"", "error(13): 对非左值表达式进行自增、自减运算");
                        break;
                    }
                    if (T->ptr[0]->type != INT) {
                        semantic_error(T->pos, "", "error(14): 对非int型变量进行自增、自减运算");
                        break;
                    }
                    T->type=T->ptr[0]->type;
                    T->width=T->ptr[0]->width;
                    T->col_num=T->ptr[0]->col_num;
                    T->place = T->ptr[0]->place;

                    /* 如果子节点计算的临时变量保存的信息为地址信息
                        if(is_pointer) newtemp = *temp0
                        newtemp = newtemp + 1
                        *temp0 = newtemp
                    */
                    if(symbolTable.symbols[T->ptr[0]->place].is_pointer)
                    {
                        T->place=fill_Temp(newTemp(),LEV,T->ptr[0]->type,'T',T->offset+T->width);
                        T->width+=4;
                        opn1.kind = ID;
                        strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                        opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                        result.kind = ID;
                        strcpy(result.id, symbolTable.symbols[T->place].alias);
                        result.offset = symbolTable.symbols[T->place].offset;
                        T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                    }

                    if(T->kind==AUTOPLUS) op=PLUS;
                    else op=MINUS;
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->place].alias);
                    opn1.type = T->ptr[0]->type;
                    opn1.offset = symbolTable.symbols[T->place].offset;
                    opn2.kind = INT;
                    opn2.const_int=1;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->place].alias);
                    result.type = T->type;
                    result.offset = symbolTable.symbols[T->place].offset;
                    T->code = merge(2, T->code, genIR(op, opn1, opn2, result));

                    if(symbolTable.symbols[T->ptr[0]->place].is_pointer)
                    {
                        opn1.kind = ID;
                        strcpy(opn1.id, symbolTable.symbols[T->place].alias);
                        opn1.offset = symbolTable.symbols[T->place].offset;
                        result.kind = ID;
                        strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                        result.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                        T->code = merge(2, T->code, genIR(POINT_EXP, opn1, opn2, result));
                    }
                    T->place = T->ptr[0]->place;
                }
                break;
        }
    }
}

/* 语义分析 */
void semantic_Analysis(struct ASTNode *T)
{
    int rtn,num,width;
    struct ASTNode *T0;
    struct opn opn1,opn2,result;
    if (T)
    {

        switch (T->kind)
        {
            /* 类列表定义 */
            case CLASS_DEF_LIST:
                if (!T->ptr[0]) break;
                # if(DEBUG)
                printf("ClassDefList: ClassDef ClassDefList\n");
                # endif
                /* 访问类定义列表的第一个项目 */
                T->ptr[0]->offset=0;
                semantic_Analysis(T->ptr[0]);
                T->code = T->ptr[0]->code;

                /* 将类的大小回填进偏移量中 */
                T->offset=T->ptr[0]->width;
                symbolTable.symbols[T->ptr[0]->place].offset=T->offset;

                # if(PRINT)
                prn_symbol();
                # endif

                /* 访问其他类的定义 */
                if (T->ptr[1]){
                    T->ptr[1]->offset=0;
                    semantic_Analysis(T->ptr[1]);
                    T->code = merge(2, T->code, T->ptr[1]->code);
                }
                break;

            /* 处理类的定义，类名标识符偏移量为0，width为当前类的大小 */
            case CLASS_DEF:
                # if(DEBUG)
                printf("ClassDef: CLASS ID LC FieldList RC\n");
                # endif
                rtn=fillSymbolTable(T->type_id,newAlias(),0,CLASS_BEGIN+class_index.index ,'C',0);
                if (rtn==-1){
                    semantic_error(T->pos,T->type_id, "error(3): 类重复定义");
                    break;
                }
                else T->place=rtn;
                class_index.TX[class_index.index++] = rtn;
                if(T->ptr[1])
                {
                    T->ptr[1]->offset=0;
                    LEV++; semantic_Analysis(T->ptr[1]); LEV--;
                    T->width=T->ptr[1]->width;
                    T->code = T->ptr[1]->code;
                }
                break;

            /* 类函数与数据成员定义 */
            case FIELD_LIST:
                # if(DEBUG)
                printf("FieldList: Field FieldList\n");
                printf("Field: VariableDef | FunctionDef\n");
                # endif
                /* 访问类函数与数据集成员定义列表 */
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->code = T->ptr[0]->code;
                T->width=T->ptr[0]->width;
                if (T->ptr[1])
                {
                    T->ptr[1]->offset = T->offset + T->ptr[0]->width;
                    semantic_Analysis(T->ptr[1]);
                    T->code = merge(2, T->code, T->ptr[1]->code);
                    T->width+=T->ptr[1]->width;
                }
                break;

            /* 变量定义，将(TYPE结点)的type送到IDlist的type域 */
            case VAR_DEF:
                # if(DEBUG)
                printf("VariableDef: Type IDList SEMI\n");
                # endif
                type_find(T->ptr[0]);
                T->type = T->ptr[0]->type;
                T->col_num = T->ptr[0]->col_num;
                T->index_class = T->ptr[0]->index_class;
                if(T->type==VOID)
                {
                    semantic_error(T->pos ,"error(20): 不得声明void类型的参数或变量 ", T->type_id);
                    break;
                }
                /* 将类型信息向变量定义列表传递，
                    如果类型为基本类型int、float、char则只需要传递type信息，
                    如果类型为类类型，则type为CLASS，需要传递类名的索引index_class，
                    如果是数组类型，则col_num数值大于0
                    */
                if(T->type == CLASS)
                {
                    if(T->index_class < 0){
                        semantic_error(T->pos, "error(21): 使用未定义的类 ", T->ptr[0]->type_id);
                        break;
                    }
                    /* 该类中不得声明自身变量 */
                    if(LEV==1 && T->index_class==class_index.TX[class_index.index-1]){
                        semantic_error(T->pos,"", "error(22): 嵌套定义当前正在定义的类");
                        break;
                    }
                }

                T->ptr[1]->offset = T->offset;
                T->ptr[1]->type = T->type;
                T->ptr[1]->col_num = T->col_num;
                T->ptr[1]->index_class = T->index_class;
                /* 类类型与数组类型使用引用变量的形式存在，使用地址存放 */
                T->ptr[1]->width=4;

                id_list(T->ptr[1]);
                T->num=T->ptr[1]->num;
                T->width=4 * T->ptr[1]->num;
                T->code = NULL;
                break;

            /* 函数定义 */
            case FUNC_DEF_ACT:
                # if(DEBUG)
                printf("FunctionDef: Type ID LP Formals RP StmtBlock\n");
                # endif

                type_find(T->ptr[0]);
                T->type = T->ptr[0]->type;
                T->col_num = T->ptr[0]->col_num;
                T->width=0;     //函数的宽度设置为0
                T->offset=DX;   //设置局部变量在活动记录中的偏移量初值
                //函数不在数据区中分配单元，偏移量为0
                rtn=fillSymbolTable(T->type_id,"",LEV,T->type,'F',0);
                if (rtn==-1){
                    semantic_error(T->pos, "error(3): 函数重复定义 ",T->type_id);
                    break;
                }
                else T->place=rtn;
                result.kind = ID;
                strcpy(result.id, T->type_id);
                result.offset = rtn;
                T->code = genIR(FUNCTION, opn1, opn2, result);

                /* 预先写入一个this指针 */
                rtn=fillSymbolTable("this",newAlias(),2,CLASS,'P',T->offset);
                if (rtn==-1){
                    semantic_error(T->pos,"error(3): 参数重复定义 ",T->type_id);
                    T->num=0; break;
                }
                this_place=rtn;
                symbolTable.symbols[symbolTable.index-1].index_class=class_index.TX[class_index.index-1];
                T->width=4;

                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[rtn].alias);
                result.offset = T->offset;
                T->code = merge(2, T->code, genIR(PARAM, opn1, opn2, result));


                //判断是否有参数
                if (T->ptr[2])
                {
                    T->ptr[2]->offset=T->offset+T->width;
                    semantic_Analysis(T->ptr[2]);  //处理函数参数列表
                    T->width=T->ptr[2]->width+T->width;
                    symbolTable.symbols[T->place].paramnum=T->ptr[2]->num+1;

                    //用形参单元宽度修改函数局部变量的起始偏移量
                    T->code=merge(2, T->code, T->ptr[2]->code);
                }
                else symbolTable.symbols[T->place].paramnum=1;

                # if(PRINT)
                prn_symbol();
                # endif

                T->ptr[3]->offset=T->offset+T->width;
                flag_loop=0;
                strcpy(T->ptr[3]->Snext, newLabel());
                semantic_Analysis(T->ptr[3]);         //处理函数体结点
                num = symbolTable.index;
                do num--;
                while (symbolTable.symbols[num].flag != 'F');

                if(T->ptr[3]->return_flag==0 && symbolTable.symbols[num].type!=VOID)
                    semantic_error(T->pos, "error(17): 函数没有返回语句（当函数返回值类型不是void时） ",T->type_id);
                //计算活动记录大小,这里offset属性存放的是活动记录大小，不是偏移
                //T->width=4;
                T->width+=T->ptr[3]->width;
                symbolTable.symbols[T->place].offset=T->offset+T->width;
                T->code=merge(3, T->code, T->ptr[3]->code, genLabel(T->ptr[3]->Snext));

                # if(PRINT)
                prn_symbol();
                # endif
                break;

            /* 函数参数定义 */
            case FORMALS_DEF:
                # if(DEBUG)
                printf("Formals: VariableList\n");
                # endif
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->num=T->ptr[0]->num;        //统计参数个数
                T->width=T->ptr[0]->width;    //累加参数单元宽度
                T->code=T->ptr[0]->code;
                break;

            /* 函数参数列表定义 */
            case VAR_DEF_LIST:
                # if(DEBUG)
                printf("VariableList: Variable COMMA VariableList\n");
                # endif
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                semantic_Analysis(T->ptr[1]);
                T->num=1+T->ptr[1]->num;        //统计参数个数
                T->width=T->ptr[0]->width+T->ptr[1]->width;  //累加参数单元宽度
                T->code=merge(2, T->ptr[0]->code, T->ptr[1]->code);
                break;

            /* 函数参数声明 */
            case VAR_DEF_S:
                # if(DEBUG)
                printf("Variable: Type ID\n");
                # endif
                type_find(T->ptr[0]);
                T->type = T->ptr[0]->type;
                T->col_num = T->ptr[0]->col_num;
                T->index_class = T->ptr[0]->index_class;
                if(T->type==VOID)
                {
                    semantic_error(T->pos, "error(20): 不得声明void类型的参数或变量 ",T->type_id);
                    break;
                }

                /* 将类型信息向变量定义列表传递，
                    如果类型为基本类型int、float、char则只需要传递type信息，
                    如果类型为类类型，则type为CLASS，需要传递类名的索引index_class，
                    如果是数组类型，则col_num数值大于0
                    */
                if(T->type==CLASS && T->index_class<0){
                        semantic_error(T->pos, "error(21): 使用未定义的类 ", T->ptr[0]->type_id);
                        break;
                }

                char temp; if(T->col_num > 0) temp = 'Q'; else temp = 'P';
                rtn=fillSymbolTable(T->type_id,newAlias(),2,T->type,temp,T->offset);
                if (rtn==-1){
                    semantic_error(T->pos,"error(3): 参数重复定义 ",T->type_id);
                    T->num=0; break;
                }
                else T->place=rtn;
                if(T->type == CLASS)
                    symbolTable.symbols[symbolTable.index-1].index_class=T->index_class;
                else symbolTable.symbols[symbolTable.index-1].index_class=-1;
                T->num=1; T->width=4;

                result.kind = ID;
                strcpy(result.id, symbolTable.symbols[rtn].alias);
                result.offset = T->offset;
                T->code = genIR(PARAM, opn1, opn2, result);
                break;

            case STMT_BLOCK:
                # if(DEBUG)
                printf("StmtBlock: LC StmtList RC\n");
                # endif
                /* 层号加1，保存该层局部变量在符号表中的起始位置 */
                T->code = NULL;
                LEV++; symbol_scope_TX.TX[symbol_scope_TX.top++]=symbolTable.index;
                if (T->ptr[0])
                {
                    strcpy(T->ptr[0]->Snext, T->Snext);
                    strcpy(T->ptr[0]->Sbreak, T->Sbreak);
                    strcpy(T->ptr[0]->Scontinue, T->Scontinue);

                    T->ptr[0]->offset=T->offset;
                    semantic_Analysis(T->ptr[0]);
                    T->width=T->ptr[0]->width;
                    T->return_flag=T->ptr[0]->return_flag;
                    T->return_pos=T->ptr[0]->return_pos;
                    T->code = T->ptr[0]->code;
                }
                else
                {
                    T->width=0;
                    T->return_flag=0;
                    T->return_pos=T->pos;
                }

                /* 层号减1，删除该作用域中的符号 */
                # if(PRINT)
                prn_symbol();
                # endif
                LEV--;  symbolTable.index=symbol_scope_TX.TX[--symbol_scope_TX.top]; //
                break;

            case STMT_LIST:
                # if(DEBUG)
                printf("StmtList: Stmt StmtList\n");
                # endif
                T->code = NULL; T->width = 0;
                if(T->ptr[0])
                {
                    strcpy(T->ptr[0]->Sbreak, T->Sbreak);
                    strcpy(T->ptr[0]->Scontinue, T->Scontinue);
                    if(T->ptr[1] && (T->ptr[0]->kind==STMT_BLOCK
                                     || T->ptr[0]->kind==IF_STMT
                                     || T->ptr[0]->kind==IF_ELSE_STMT
                                     || T->ptr[0]->kind==FOR_STMT
                                     || T->ptr[0]->kind==WHILE_STMT))
                        strcpy(T->ptr[0]->Snext, newLabel());
                    else strcpy(T->ptr[0]->Snext, T->Snext);

                    T->ptr[0]->offset=T->offset;
                    semantic_Analysis(T->ptr[0]);
                    T->width=T->ptr[0]->width;  //累加参数单元宽度
                    T->return_flag=T->ptr[0]->return_flag;
                    T->return_pos=T->ptr[0]->return_pos;

                    T->code = T->ptr[0]->code;
                }
                if(T->ptr[1])
                {
                    strcpy(T->ptr[1]->Snext, T->Snext);
                    strcpy(T->ptr[1]->Sbreak, T->Sbreak);
                    strcpy(T->ptr[1]->Scontinue, T->Scontinue);

                    if(T->ptr[0]) T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                    else T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);

                    /* 如果当前的块为复杂块，且比原活动记录大则替换 */
                    if(T->ptr[0] && T->ptr[1]->width>T->width
                       && (T->ptr[0]->kind==IF_STMT || T->ptr[0]->kind==WHILE_STMT
                            || T->ptr[0]->kind==IF_ELSE_STMT || T->ptr[0]->kind==FOR_STMT
                                     || T->ptr[0]->kind==STMT_BLOCK ))
                                        T->width=T->ptr[1]->width;
                    else T->width+=T->ptr[1]->width;
                    T->return_flag=T->ptr[1]->return_flag;
                    T->return_pos=T->ptr[1]->return_pos;

                    if(T->ptr[0] && (T->ptr[0]->kind==STMT_BLOCK
                                     || T->ptr[0]->kind==IF_STMT
                                     || T->ptr[0]->kind==IF_ELSE_STMT
                                     || T->ptr[0]->kind==FOR_STMT
                                     || T->ptr[0]->kind==WHILE_STMT))
                        T->code=merge(3,T->code,genLabel(T->ptr[0]->Snext),T->ptr[1]->code);
                    else if(T->ptr[0]) T->code=merge(2,T->code,T->ptr[1]->code);
                    else T->code=T->ptr[1]->code;
                }
                break;

            case IF_STMT:
                # if(DEBUG)
                printf("IfStmt: IF LP Expr RP Stmt\n");
                # endif
                strcpy(T->ptr[0]->Etrue, newLabel());
                strcpy(T->ptr[0]->Efalse, T->Snext);

                T->ptr[0]->offset=T->offset;
                boolExp(T->ptr[0]);
                T->width=T->ptr[0]->width;
                T->code=T->ptr[0]->code;
                if(T->ptr[1])
                {
                    strcpy(T->ptr[1]->Snext, T->Snext);
                    strcpy(T->ptr[1]->Sbreak, T->Sbreak);
                    strcpy(T->ptr[1]->Scontinue, T->Scontinue);

                    T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);
                    T->width+=T->ptr[1]->width;
                    T->return_flag=T->ptr[1]->return_flag;
                    T->return_pos=T->ptr[1]->return_pos;

                    T->code = merge(3,T->code,genLabel(T->ptr[0]->Etrue),T->ptr[1]->code);
                }
                break;

            case IF_ELSE_STMT:
                # if(DEBUG)
                printf("IfStmt: IF LP Expr RP Stmt ELSE Stmt\n");
                # endif
                strcpy(T->ptr[0]->Etrue, newLabel());
                strcpy(T->ptr[0]->Efalse, newLabel());

                T->ptr[0]->offset=T->offset;
                boolExp(T->ptr[0]);
                T->code=T->ptr[0]->code;
                if(T->ptr[1])
                {
                    strcpy(T->ptr[1]->Snext, T->Snext);
                    strcpy(T->ptr[1]->Sbreak, T->Sbreak);
                    strcpy(T->ptr[1]->Scontinue, T->Scontinue);
                    T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);
                    T->width=T->ptr[1]->width;
                    T->return_flag=T->ptr[1]->return_flag;
                    T->return_pos=T->ptr[1]->return_pos;
                    T->code=merge(4,T->code,genLabel(T->ptr[0]->Etrue),T->ptr[1]->code,genGoto(T->Snext));
                }
                if(T->ptr[2])
                {
                    strcpy(T->ptr[2]->Snext, T->Snext);
                    strcpy(T->ptr[2]->Sbreak, T->Sbreak);
                    strcpy(T->ptr[2]->Scontinue, T->Scontinue);
                    T->ptr[2]->offset=T->offset;
                    semantic_Analysis(T->ptr[2]);
                    if(T->width<T->ptr[2]->width)
                        T->width=T->ptr[2]->width;
                    if(T->ptr[2]->return_flag==0)
                    {
                        T->return_flag=T->ptr[2]->return_flag;
                        T->return_pos=T->ptr[2]->return_pos;
                    }
                    T->code=merge(3,T->code,genLabel(T->ptr[0]->Efalse), T->ptr[2]->code);
                }
                T->width+=T->ptr[0]->width;
                break;

            case FOR_STMT:
                # if(DEBUG)
                printf("FOR LP SimpleStmt SEMI SimpleStmt SEMI SimpleStmt RP Stmt\n");
                # endif
                T->code=NULL;
                if(T->ptr[0])
                {
                    T->ptr[0]->offset=T->offset;
                    semantic_Analysis(T->ptr[0]);
                    T->code=T->ptr[0]->code;
                }
                if(!T->ptr[1] || !T->ptr[2]){
                    semantic_error(T->pos,"error(27): for语句bool判断条件以及后置运算不得为空 ",T->type_id);
                    break;
                }

                strcpy(T->ptr[1]->Etrue, newLabel());
                strcpy(T->ptr[1]->Efalse, T->Snext);
                strcpy(T->ptr[2]->Snext, newLabel());

                T->ptr[1]->offset=T->offset;
                boolExp(T->ptr[1]);

                T->ptr[2]->offset=T->offset;
                semantic_Analysis(T->ptr[2]);

                T->code=merge(4,T->code,genLabel(T->ptr[2]->Snext), T->ptr[1]->code,
                              genLabel(T->ptr[1]->Etrue));

                if(T->ptr[3])
                {
                    flag_loop++;
                    strcpy(T->ptr[3]->Snext, newLabel());
                    strcpy(T->ptr[3]->Sbreak, T->Snext);
                    strcpy(T->ptr[3]->Scontinue, T->ptr[3]->Snext);
                    T->ptr[3]->offset=T->offset;
                    semantic_Analysis(T->ptr[3]);
                    T->width=T->ptr[3]->width;
                    T->return_flag=T->ptr[3]->return_flag;
                    T->return_pos=T->ptr[3]->return_pos;
                    flag_loop--;

                    T->code=merge(5,T->code, T->ptr[3]->code, genLabel(T->ptr[3]->Snext),
                               T->ptr[2]->code, genGoto(T->ptr[2]->Snext));
                }
                else T->code=merge(5,T->code, T->ptr[2]->code, genGoto(T->ptr[2]->Snext));
                break;

            case WHILE_STMT:
                # if(DEBUG)
                printf("WhileStmt: WHILE LP Expr RP Stmt\n");
                # endif
                strcpy(T->ptr[0]->Etrue, newLabel());
                strcpy(T->ptr[0]->Efalse, T->Snext);

                T->ptr[0]->offset=T->offset;
                boolExp(T->ptr[0]);
                if(T->ptr[1])
                {
                    strcpy(T->ptr[1]->Snext, newLabel());
                    strcpy(T->ptr[1]->Sbreak, T->Snext);
                    strcpy(T->ptr[1]->Scontinue, T->ptr[1]->Snext);
                    flag_loop++;
                    T->ptr[1]->offset=T->offset;
                    semantic_Analysis(T->ptr[1]);
                    T->width=T->ptr[1]->width;
                    T->return_flag=T->ptr[1]->return_flag;
                    T->return_pos=T->ptr[1]->return_pos;
                    flag_loop--;
                    T->code=merge(5, genLabel(T->ptr[1]->Snext), T->ptr[0]->code,
							genLabel(T->ptr[0]->Etrue), T->ptr[1]->code, genGoto(T->ptr[1]->Snext));
                }
                else T->code=merge(2, genLabel(T->ptr[0]->Etrue), T->ptr[0]->code);
                break;

            case CONTINUE_STMT:
                # if(DEBUG)
                printf("ContinueStmt: CONTINUE\n");
                # endif
                T->return_flag=0;
                T->return_pos=T->pos;
                if(flag_loop==0)
                    semantic_error(T->pos, "error(19): continue语句不在循环语句中 ", "");
                else T->code=genGoto(T->Scontinue);
                break;
            case BREAK_STMT:
                # if(DEBUG)
                printf("BreakStmt: BREAK\n");
                # endif
                T->return_flag=0;
                T->return_pos=T->pos;
                if(flag_loop==0)
                    semantic_error(T->pos, "error(18): break语句不在循环语句中 ", "");
                else T->code=genGoto(T->Sbreak);
                break;

            /*  */
            case RETURN:
                # if(DEBUG)
                printf("ReturnStmt: RETURN\n");
                # endif
                num = symbolTable.index;
                do num--;
                while (symbolTable.symbols[num].flag != 'F');
                if(symbolTable.symbols[num].type != VOID)
                    semantic_error(T->pos,"", "error(16): 函数返回值类型与函数定义的返回值类型不匹配");
                T->return_flag=1;
                T->return_pos=T->pos;
                T->code = genIR(RETURN, opn1, opn2, result);
                break;

            /*  */
            case RETURN_EXP:
                # if(DEBUG)
                printf("ReturnStmt: RETURN EXPR\n");
                # endif

                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                num = symbolTable.index;
                do num--;
                while (symbolTable.symbols[num].flag != 'F');
                if (T->ptr[0]->type != symbolTable.symbols[num].type)
                    semantic_error(T->pos,"", "error(16): 函数返回值类型与函数定义的返回值类型不匹配");
                T->return_flag=1;
                T->return_pos=T->pos;
                result.kind = ID;
				strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
				result.offset = symbolTable.symbols[T->ptr[0]->place].offset;
				T->code = merge(2, T->ptr[0]->code, genIR(RETURN, opn1, opn2, result));
                break;

            case PRINT_STMT:
            case SCAN_STMT:
                # if(DEBUG)
                printf("PRINT_STMT | SCAN_STMT\n");
                # endif
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->num=T->ptr[0]->num;
                T->return_flag=0;
                T->return_pos=T->pos;
                T->code =NULL;
                break;

            case ACTUALS:
                # if(DEBUG)
                printf("Actuals: ExprList\n");
                # endif
                T->ptr[0]->offset=T->offset;
                semantic_Analysis(T->ptr[0]);
                T->code=T->ptr[0]->code;
                if(T->ptr[0]->kind!=EXP_LIST&&symbolTable.symbols[T->ptr[0]->place].is_pointer)
                {
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    result.offset = opn1.offset;
                    T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                    symbolTable.symbols[T->ptr[0]->place].is_pointer=0;
                }
                T->num=T->ptr[0]->num;
                T->width=T->ptr[0]->width;
                break;

            case EXP_LIST:
                # if(DEBUG)
                printf("ExprList: Expr COMMA ExprList | Expr \n");
                # endif

                T->ptr[0]->offset=T->offset;
                Exp(T->ptr[0]);
                T->code=T->ptr[0]->code;
                if(symbolTable.symbols[T->ptr[0]->place].is_pointer)
                {
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[0]->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->ptr[0]->place].alias);
                    result.offset = opn1.offset;
                    T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                    symbolTable.symbols[T->ptr[0]->place].is_pointer=0;
                }
                T->ptr[1]->offset=T->offset+T->ptr[0]->width;
                Exp(T->ptr[1]);
                T->num=T->ptr[0]->num+T->ptr[1]->num;        //统计参数个数
                T->width=T->ptr[0]->width+T->ptr[1]->width;  //累加参数单元宽度
                T->code=merge(2, T->code, T->ptr[1]->code);

                if(T->ptr[1]->kind!=EXP_LIST&&symbolTable.symbols[T->ptr[1]->place].is_pointer)
                {
                    opn1.kind = ID;
                    strcpy(opn1.id, symbolTable.symbols[T->ptr[1]->place].alias);
                    opn1.offset = symbolTable.symbols[T->ptr[1]->place].offset;
                    result.kind = ID;
                    strcpy(result.id, symbolTable.symbols[T->ptr[1]->place].alias);
                    result.offset = opn1.offset;
                    T->code = merge(2, T->code, genIR(EXP_POINT, opn1, opn2, result));
                    symbolTable.symbols[T->ptr[1]->place].is_pointer=0;
                }
                break;

            /* 处理基本表达式 */
            case INT: case FLOAT: case CHAR:
            case NULL_P: case TRUE: case FALSE: case THIS:

            case PLUSASSIGNOP: case MINUSASSIGNOP: case STARASSIGNOP:
            case DIVASSIGNOP: case MODASSIGNOP: case ASSIGNOP:

            case AND: case OR: case NOT: case RELOP:

            case PLUS: case MINUS: case STAR: case DIV: case MOD: case UMINUS:
            case AUTOPLUS: case AUTOMINUS:

            case ID: case EXP_ID: case EXP_EXP:
            case ID_ACTUALS: case EXP_ID_ACTUALS:

                Exp(T);
                break;
        }
    }
}

/* 语义分析的入口函数，用于打印中间代码等 */
void semantic_Analysis0(struct ASTNode *T)
{
    semantic_Analysis(T);
    prnIR(T->code);
    printf("\n\n\n");
    //DAG_optimize(T->code);
    prnIR(DAG_optimize(T->code));
    printf("\n\n\n");
    prnIR(var_optimize());
    printf("原中间代码条数：%d\n现中间代码条数：%d\n",old_code,new_code);
    printf("优化率：%.2f %%\n",(float)(old_code-new_code)/old_code*100);
}











