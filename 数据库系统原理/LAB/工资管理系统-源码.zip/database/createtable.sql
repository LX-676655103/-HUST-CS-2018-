if not exists (select * from sys.databases where name = 'SalaryManagement')
	create database SalaryManagement;
go
use SalaryManagement;

drop table if exists attendance_editRecord;
drop table if exists extraWork_editRecord;
drop table if exists dbuser;
drop table if exists workerSalary;
drop table if exists extraWork;
drop table if exists attendance;
drop table if exists workerInfo;
drop table if exists department;
drop table if exists workerType;

-- ��1 ������Ϣ��(workerType)
 create table workerType(
     t_id int,
     t_name nchar(20) not null,
	 t_rank int not null,
     base_salary money not null,
     constraint pk_workerType primary key(t_id)
 );

 -- ��2 ������Ϣ��(department)
 create table department(
     d_id int,
     d_name nchar(20) not null,
     constraint pk_department primary key(d_id)
 );

-- ��3 Ա����Ϣ��(workerInfo)
 create table workerInfo(
     w_id int,
     w_name nchar(20) not null,
	 w_sex nchar(1) check(w_sex in(N'��',N'Ů')),
     w_telephone nchar(11) not null,
	 d_id int not null,
	 t_id int not null,
	 is_leave bit,
     constraint pk_workerInfo primary key(w_id),
	 constraint fk_workerInfo_department foreign key(d_id) 
		references department(d_id),
	 constraint fk_workerInfo_workerType foreign key(t_id) 
		references workerType(t_id)
 );

-- ��4 ���ڱ�(attendance)
-- ���ݿ���������ý��ͣ�1��ʾ������2��ʾ�ٵ���
--                       3��ʾȱ�ڣ�4��ʾ��٣�5��ʾ����
create table attendance(
     w_id int not null,
	 a_date date not null,
	 begin_time smalldatetime not null,
	 end_time smalldatetime,
	 a_status int not null check(a_status > 0 and a_status <= 5),
	 e_status bit,
	 payment money,
     constraint pk_attendance primary key(w_id, a_date),
	 constraint fk_attendance_workerInfo foreign key(w_id) 
		references workerInfo(w_id)
);

-- ��5 �Ӱ��(extraWork)
create table extraWork(
     w_id int not null,
	 e_date date not null,
	 begin_time smalldatetime not null,
	 end_time smalldatetime,
	 duration int not null,
	 type int not null,
	 e_status bit,
	 payment money,
     constraint pk_extraWork primary key(w_id, e_date),
	 constraint fk_extraWork_workerInfo foreign key(w_id) 
		references workerInfo(w_id)
);

-- ��6 Ա�������(workerSalary)
create table workerSalary(
     w_id int not null,
	 s_year int not null,
	 s_month int not null check( s_month between 1 and 12 ),
	 base_pay money not null,
	 merit_pay money not null,
	 extra_pay money not null,
     constraint pk_workerSalary primary key(w_id, s_year, s_month),
	 constraint fk_workerSalary_workerInfo foreign key(w_id) 
		references workerInfo(w_id)
);

-- ��7 ϵͳ�û���(dbuser)
create table dbuser(
     w_id int not null,
	 pwd nvarchar(50) not null,
	 permission int not null check(permission >= 1 and permission < 5),
     constraint pk_dbuser primary key(w_id),
	 constraint fk_dbuser_workerInfo foreign key(w_id) 
		references workerInfo(w_id)
);

-- ��8 �Ӱ��޸������(extraWork_editRecord)
create table extraWork_editRecord(
     w_id int not null,
	 edit_time datetime not null,
	 old_duration int not null,
	 old_type int not null,
	 new_duration int,
	 new_type int,
	 r_w_id int not null,
	 r_date date not null,
     constraint pk_extraWork_editRecord primary key(w_id, edit_time, r_w_id, r_date),
	 constraint fk_extraWork_editRecord_extraWork foreign key(r_w_id, r_date) 
		references extraWork(w_id, e_date),
	 constraint fk_extraWork_editRecord_workerInfo foreign key(w_id) 
		references workerInfo(w_id)
);

-- ��9 �����޸������(attendance_editRecord)
create table attendance_editRecord(
     w_id int not null,
	 edit_time datetime not null,
	 old_status int not null,
	 new_status int not null,
	 r_w_id int not null,
	 r_date date not null,
     constraint pk_attendance_editRecord primary key(w_id, edit_time, r_w_id, r_date),
	 constraint fk_attendance_editRecord_attendance foreign key(r_w_id, r_date) 
		references attendance(w_id, a_date),
	 constraint fk_attendance_editRecord_workerInfo foreign key(w_id) 
		references workerInfo(w_id)
);

-- �������
/* *********************************************************** */