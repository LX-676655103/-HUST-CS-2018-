use SalaryManagement;

drop view if exists year_salary;
drop view if exists month_salary;
go

-- ������нˮ���������»������ʣ�
 create view month_salary(w_id, w_name, d_id, d_name, t_name, s_year, 
						s_month, base_pay, merit_pay, extra_pay)
 as 
 select workerInfo.w_id, w_name, department.d_id, d_name, t_name, s_year, s_month,
					base_pay, merit_pay, extra_pay 
	from workerSalary, workerInfo, department, workerType
	where workerSalary.w_id = workerInfo.w_id and 
		workerInfo.t_id = workerType.t_id and workerInfo.d_id = department.d_id;
go

-- ������нˮ�����������ս���
 create view year_salary(w_id, w_name, d_id, d_name, t_name, s_year, year_pay, year_award)
 as 
 select workerInfo.w_id, w_name, department.d_id, d_name, t_name, s_year, 
 sum(base_pay + merit_pay + extra_pay), 
 sum(base_pay + merit_pay + extra_pay)/12 
	from workerSalary, workerInfo, workerType, department
	where workerSalary.w_id = workerInfo.w_id and 
		workerInfo.t_id = workerType.t_id and workerInfo.d_id = department.d_id
	group by workerInfo.w_id, w_name, department.d_id, d_name, t_name, s_year