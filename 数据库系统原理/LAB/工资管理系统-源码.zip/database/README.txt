本次使用的数据库软件为SQL Server，打开数据库管理软件，
依次执行创建基本表（createtable.sql）、创建视图（createview.sql）、
创建触发器（trigger.sql），最后执行数据插入文件（datainsert.sql）
数据库创建完成