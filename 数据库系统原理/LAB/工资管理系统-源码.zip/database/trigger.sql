use SalaryManagement;
drop trigger if exists merit_salary;
drop trigger if exists extra_salary;
go 

create trigger merit_salary on attendance
	after insert, update
as 
if update (a_status)
begin
    declare my_cursor cursor for select w_id, a_date, a_status from inserted;
    declare @newWid int;
	declare @newdate date;
	declare @newstatus int;
    open my_cursor;
    fetch next from my_cursor into @newWid, @newdate, @newstatus;
	while @@FETCH_STATUS = 0
		begin
			declare @base_salary money;
			declare @newpayment money;
			declare @oldpayment money;

			select @base_salary = base_salary from workerInfo, workerType 
				where workerInfo.w_id = @newWid and workerInfo.t_id = workerType.t_id;

			set @oldpayment = 0;
			if exists (select payment from deleted where w_id = @newWid and a_date = @newdate)
				select @oldpayment=payment from deleted where w_id = @newWid and a_date = @newdate

			-- ���ݿ���������ý��ͣ�1��ʾ������2��ʾ�ٵ���3��ʾȱ�ڣ�4��ʾ��٣�5��ʾ����
			if @newstatus = 1 set @newpayment = 0
			if @newstatus = 2 set @newpayment = 0 - @base_salary / 21.75 * 0.2
			if @newstatus = 3 set @newpayment = 0 - @base_salary / 21.75
			if @newstatus = 4 set @newpayment = 0
			if @newstatus = 5 set @newpayment = 0 - @base_salary / 21.75 * 0.2

			-- �޸�payment
			update attendance
				set payment = @newpayment
				where w_id = @newWid and a_date = @newdate;
				
			-- �޸�нˮ���е��¼�Ч����
			if not exists (select * from workerSalary 
				where w_id = @newWid and s_year = convert(int,year(@newdate))
					and s_month = convert(int,month(@newdate)))
				insert into workerSalary 
					values(@newWid,convert(int,year(@newdate)),
					convert(int,month(@newdate)),@base_salary, 0 , 0);

			update workerSalary
				set merit_pay = merit_pay - @oldpayment + @newpayment
				where w_id = @newWid and s_year = convert(int,year(@newdate))
					and s_month = convert(int,month(@newdate));
		    
            fetch next from my_cursor into @newWid, @newdate, @newstatus;
		end
    close my_cursor;
end
go

create trigger extra_salary on extraWork
	after insert, update
as 
if update (type) or update (duration)
begin
    declare my_cursor cursor for select w_id, e_date, type, duration from inserted;
    declare @newWid int;
	declare @newdate date;
	declare @newtype int;
	declare @newduration int;
    open my_cursor;
    fetch next from my_cursor into @newWid, @newdate, @newtype, @newduration;
	while @@FETCH_STATUS = 0
		begin
			declare @base_salary money;
			declare @newpayment money;
			declare @oldpayment money;

			select @base_salary = base_salary from workerInfo, workerType 
				where workerInfo.w_id = @newWid and workerInfo.t_id = workerType.t_id;

			set @oldpayment = 0;
			if not exists (select payment from deleted where w_id = @newWid and e_date = @newdate)
				select @oldpayment=payment from deleted where w_id = @newWid and e_date = @newdate;

			-- ���ݼӰ�������ý�����type��ʾ֧������Ϊ��������
			set @newpayment = @base_salary / 21.75 / 8 * @newtype * @newduration;

			-- �޸�payment
			update extraWork
				set payment = @newpayment
				where w_id = @newWid and e_date = @newdate;
				
			-- �޸�нˮ���е��½���
			if not exists (select * from workerSalary 
				where w_id = @newWid and s_year = convert(int,year(@newdate))
					and s_month = convert(int,month(@newdate)))
				insert into workerSalary 
					values(@newWid,convert(int,year(@newdate)),
					convert(int,month(@newdate)),@base_salary, 0, 0);

			update workerSalary
				set extra_pay = extra_pay - @oldpayment + @newpayment
				where w_id = @newWid and s_year = convert(int,year(@newdate))
					and s_month = convert(int,month(@newdate));
		    
            fetch next from my_cursor into @newWid, @newdate, @newtype, @newduration;
		end
    close my_cursor;
end