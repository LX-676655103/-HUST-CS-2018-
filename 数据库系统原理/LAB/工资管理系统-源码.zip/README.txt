1. 配置ODBC，具体的配置参见https://www.cnblogs.com/nufangrensheng/p/3816474.html
需要注意，数据源的名称应该命名为"QTDSN"，其他按照步骤即可；
2. 执行database下的文件，创建数据库，详见README文件
3. 使用QT打开工资管理系统项目（SalaryManagement），
进行合理路径配置（不得出现中文）且配置完成编译器，进行编译即可运行。