#include "widget.h"
#include "ui_widget.h"
#include <QMessageBox>
#include <QString>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
    ui->pPwdlineEdit->setEchoMode(QLineEdit::Password);

    /* 连接数据库 */
    dbinstance = DBInstance::getInstance();
    dbinstance->openDatabase();
}

Widget::~Widget()
{
    delete ui;
    dbinstance->closeDatabase();
}

void Widget::on_pLoginButton_clicked()
{
    /*用户名密码不为空*/
    if(ui->pUsrlineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请输入用户名后再登录");
        return;
    }
    if(ui->pPwdlineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请输入密码后再登录");
        return;
    }
    QString name = ui->pUsrlineEdit->text();
    QString pwd = ui->pPwdlineEdit->text();

    /* 查询用户并登录 */
    int is_user_exist = 0, is_pwd_right = 0;
    QSqlQuery query;
    QString permission;
    query.prepare("select * from dbuser;");
    query.exec();

    while(query.next())
    {
        QString id = query.value("w_id").toString();
        qDebug()<<"worker num:"<<id;
        if(id == name)
        {
            is_user_exist = 1;
            QString password = query.value("pwd").toString();
            qDebug()<<"password:"<<password;
            if(pwd == password)
            {
                is_pwd_right = 1;
                permission = query.value("permission").toString();
                qDebug()<<"permission:"<<permission;
            }
            break;
        }
    }

    /* 用户不存在 */
    if(is_user_exist == 0){
        QMessageBox::critical(this,"警告","用户不存在");
        return;
    }
    /* 密码错误 */
    else if(is_pwd_right == 0){
         QMessageBox::critical(this,"警告","密码错误");
         return;
    }
    /* 登录 */
    else
    {
        User user(name, pwd, permission);
        /* 隐藏原有的窗口 & 显示新的窗口 */
        this->hide();
        ui->pUsrlineEdit->clear();
        ui->pPwdlineEdit->clear();
        login = new Login(this);
        login->setUser(user);
        login->show();
    }
}
