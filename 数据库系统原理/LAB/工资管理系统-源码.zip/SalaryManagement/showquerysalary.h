#ifndef SHOWQUERYSALARY_H
#define SHOWQUERYSALARY_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QHeaderView>
#include <QString>
#include <QMessageBox>
#include <QDebug>

namespace Ui {
class ShowQuerySalary;
}

class ShowQuerySalary : public QDialog
{
    Q_OBJECT

public:
    explicit ShowQuerySalary(QWidget *parent, QString d_id, bool is_depart);
    ~ShowQuerySalary();

private slots:
    void on_pWorkerNum_clicked();
    void on_pQuery_clicked();
    void on_pPushOut_clicked();

private:
    QString d_id;
    bool is_depart;
    Ui::ShowQuerySalary *ui;
};

#endif // SHOWQUERYSALARY_H
