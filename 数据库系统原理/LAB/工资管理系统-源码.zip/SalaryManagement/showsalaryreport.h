#ifndef SHOWSALARYREPORT_H
#define SHOWSALARYREPORT_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QHeaderView>
#include <QString>
#include <QMessageBox>
#include <QDebug>


namespace Ui {
class ShowSalaryReport;
}

class ShowSalaryReport : public QDialog
{
    Q_OBJECT

public:
    explicit ShowSalaryReport(QWidget *parent, QString d_id, bool is_depart);
    ~ShowSalaryReport();

private slots:
    void on_pMonth_clicked();
    void on_pYear_clicked();
    void on_pPushOut_clicked();

private:
    QString d_id;
    bool is_depart;
    Ui::ShowSalaryReport *ui;
};

#endif // SHOWSALARYREPORT_H
