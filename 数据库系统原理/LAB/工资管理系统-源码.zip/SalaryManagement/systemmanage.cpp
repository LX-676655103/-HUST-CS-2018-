#include "systemmanage.h"
#include "ui_systemmanage.h"

SystemManage::SystemManage(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::SystemManage)
{
    ui->setupUi(this);
    this->setWindowTitle("系统管理");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
}

SystemManage::~SystemManage()
{
    delete ui;
}

void SystemManage::on_pEditBaseSalary_clicked()
{
    pEditBaseSalary = new EditBaseSalary(this, w_id);
    pEditBaseSalary->setWindowModality(Qt::ApplicationModal);
    pEditBaseSalary->show();
}

void SystemManage::on_pExit_clicked()
{
    this->hide();
}
