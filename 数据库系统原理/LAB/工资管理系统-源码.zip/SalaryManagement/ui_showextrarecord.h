/********************************************************************************
** Form generated from reading UI file 'showextrarecord.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWEXTRARECORD_H
#define UI_SHOWEXTRARECORD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ShowExtraRecord
{
public:
    QTableView *tableView;

    void setupUi(QDialog *ShowExtraRecord)
    {
        if (ShowExtraRecord->objectName().isEmpty())
            ShowExtraRecord->setObjectName(QStringLiteral("ShowExtraRecord"));
        ShowExtraRecord->resize(700, 300);
        tableView = new QTableView(ShowExtraRecord);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 15, 640, 260));

        retranslateUi(ShowExtraRecord);

        QMetaObject::connectSlotsByName(ShowExtraRecord);
    } // setupUi

    void retranslateUi(QDialog *ShowExtraRecord)
    {
        ShowExtraRecord->setWindowTitle(QApplication::translate("ShowExtraRecord", "Dialog", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ShowExtraRecord: public Ui_ShowExtraRecord {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWEXTRARECORD_H
