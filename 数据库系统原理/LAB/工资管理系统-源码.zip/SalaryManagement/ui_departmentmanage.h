/********************************************************************************
** Form generated from reading UI file 'departmentmanage.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DEPARTMENTMANAGE_H
#define UI_DEPARTMENTMANAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_DepartmentManage
{
public:
    QPushButton *pSalaryReport;
    QPushButton *pQuerySalary;
    QPushButton *pEditAttend;
    QPushButton *pEditExtraWork;
    QPushButton *pExit;

    void setupUi(QDialog *DepartmentManage)
    {
        if (DepartmentManage->objectName().isEmpty())
            DepartmentManage->setObjectName(QStringLiteral("DepartmentManage"));
        DepartmentManage->resize(392, 247);
        QFont font;
        font.setPointSize(9);
        DepartmentManage->setFont(font);
        pSalaryReport = new QPushButton(DepartmentManage);
        pSalaryReport->setObjectName(QStringLiteral("pSalaryReport"));
        pSalaryReport->setGeometry(QRect(50, 46, 120, 25));
        QFont font1;
        font1.setPointSize(10);
        pSalaryReport->setFont(font1);
        pQuerySalary = new QPushButton(DepartmentManage);
        pQuerySalary->setObjectName(QStringLiteral("pQuerySalary"));
        pQuerySalary->setGeometry(QRect(50, 86, 120, 25));
        pQuerySalary->setFont(font1);
        pEditAttend = new QPushButton(DepartmentManage);
        pEditAttend->setObjectName(QStringLiteral("pEditAttend"));
        pEditAttend->setGeometry(QRect(50, 126, 120, 25));
        pEditAttend->setFont(font1);
        pEditExtraWork = new QPushButton(DepartmentManage);
        pEditExtraWork->setObjectName(QStringLiteral("pEditExtraWork"));
        pEditExtraWork->setGeometry(QRect(50, 166, 120, 25));
        pEditExtraWork->setFont(font1);
        pExit = new QPushButton(DepartmentManage);
        pExit->setObjectName(QStringLiteral("pExit"));
        pExit->setGeometry(QRect(250, 163, 90, 30));
        pExit->setFont(font1);

        retranslateUi(DepartmentManage);

        QMetaObject::connectSlotsByName(DepartmentManage);
    } // setupUi

    void retranslateUi(QDialog *DepartmentManage)
    {
        DepartmentManage->setWindowTitle(QApplication::translate("DepartmentManage", "Dialog", Q_NULLPTR));
        pSalaryReport->setText(QApplication::translate("DepartmentManage", "\346\237\245\347\234\213\345\267\245\350\265\204\346\212\245\350\241\250", Q_NULLPTR));
        pQuerySalary->setText(QApplication::translate("DepartmentManage", "\346\237\245\350\257\242\345\221\230\345\267\245\345\267\245\350\265\204", Q_NULLPTR));
        pEditAttend->setText(QApplication::translate("DepartmentManage", "\344\277\256\346\224\271\345\221\230\345\267\245\350\200\203\345\213\244\347\212\266\346\200\201", Q_NULLPTR));
        pEditExtraWork->setText(QApplication::translate("DepartmentManage", "\344\277\256\346\224\271\345\221\230\345\267\245\345\212\240\347\217\255\350\256\260\345\275\225", Q_NULLPTR));
        pExit->setText(QApplication::translate("DepartmentManage", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class DepartmentManage: public Ui_DepartmentManage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DEPARTMENTMANAGE_H
