/********************************************************************************
** Form generated from reading UI file 'showmonthsalary.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWMONTHSALARY_H
#define UI_SHOWMONTHSALARY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ShowMonthSalary
{
public:
    QTableView *tableView;
    QPushButton *pFresh;

    void setupUi(QDialog *ShowMonthSalary)
    {
        if (ShowMonthSalary->objectName().isEmpty())
            ShowMonthSalary->setObjectName(QStringLiteral("ShowMonthSalary"));
        ShowMonthSalary->resize(610, 305);
        tableView = new QTableView(ShowMonthSalary);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 10, 551, 241));
        pFresh = new QPushButton(ShowMonthSalary);
        pFresh->setObjectName(QStringLiteral("pFresh"));
        pFresh->setGeometry(QRect(480, 267, 90, 30));
        QFont font;
        font.setPointSize(11);
        pFresh->setFont(font);

        retranslateUi(ShowMonthSalary);

        QMetaObject::connectSlotsByName(ShowMonthSalary);
    } // setupUi

    void retranslateUi(QDialog *ShowMonthSalary)
    {
        ShowMonthSalary->setWindowTitle(QApplication::translate("ShowMonthSalary", "Dialog", Q_NULLPTR));
        pFresh->setText(QApplication::translate("ShowMonthSalary", "\345\210\267\346\226\260", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ShowMonthSalary: public Ui_ShowMonthSalary {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWMONTHSALARY_H
