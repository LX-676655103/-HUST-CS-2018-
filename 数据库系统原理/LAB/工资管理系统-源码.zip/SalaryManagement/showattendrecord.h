#ifndef SHOWATTENDRECORD_H
#define SHOWATTENDRECORD_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QDateTime>
#include <QString>

namespace Ui {
class ShowAttendRecord;
}

class ShowAttendRecord : public QDialog
{
    Q_OBJECT

public:
    explicit ShowAttendRecord(QWidget *parent, QString id);
    ~ShowAttendRecord();

private:
    QString w_id;
    QSqlQueryModel *model;
    Ui::ShowAttendRecord *ui;
};

#endif // SHOWATTENDRECORD_H
