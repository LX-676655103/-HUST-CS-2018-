/********************************************************************************
** Form generated from reading UI file 'login.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Login
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QPushButton *pPersonInfo;
    QPushButton *pYearSalary;
    QPushButton *pMonSalary;
    QPushButton *pExtraRecord;
    QPushButton *pAttendRecord;
    QPushButton *pEditPwd;
    QPushButton *pDepartManage;
    QPushButton *pComManage;
    QPushButton *pSysManage;
    QPushButton *pExit;

    void setupUi(QDialog *Login)
    {
        if (Login->objectName().isEmpty())
            Login->setObjectName(QStringLiteral("Login"));
        Login->resize(381, 254);
        gridLayoutWidget = new QWidget(Login);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(40, 20, 161, 211));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pPersonInfo = new QPushButton(gridLayoutWidget);
        pPersonInfo->setObjectName(QStringLiteral("pPersonInfo"));

        gridLayout->addWidget(pPersonInfo, 0, 0, 1, 1);

        pYearSalary = new QPushButton(gridLayoutWidget);
        pYearSalary->setObjectName(QStringLiteral("pYearSalary"));

        gridLayout->addWidget(pYearSalary, 3, 0, 1, 1);

        pMonSalary = new QPushButton(gridLayoutWidget);
        pMonSalary->setObjectName(QStringLiteral("pMonSalary"));

        gridLayout->addWidget(pMonSalary, 2, 0, 1, 1);

        pExtraRecord = new QPushButton(gridLayoutWidget);
        pExtraRecord->setObjectName(QStringLiteral("pExtraRecord"));

        gridLayout->addWidget(pExtraRecord, 5, 0, 1, 1);

        pAttendRecord = new QPushButton(gridLayoutWidget);
        pAttendRecord->setObjectName(QStringLiteral("pAttendRecord"));

        gridLayout->addWidget(pAttendRecord, 4, 0, 1, 1);

        pEditPwd = new QPushButton(gridLayoutWidget);
        pEditPwd->setObjectName(QStringLiteral("pEditPwd"));

        gridLayout->addWidget(pEditPwd, 6, 0, 1, 1);

        pDepartManage = new QPushButton(Login);
        pDepartManage->setObjectName(QStringLiteral("pDepartManage"));
        pDepartManage->setGeometry(QRect(250, 28, 90, 30));
        pComManage = new QPushButton(Login);
        pComManage->setObjectName(QStringLiteral("pComManage"));
        pComManage->setGeometry(QRect(250, 69, 90, 30));
        pSysManage = new QPushButton(Login);
        pSysManage->setObjectName(QStringLiteral("pSysManage"));
        pSysManage->setGeometry(QRect(250, 110, 90, 30));
        pExit = new QPushButton(Login);
        pExit->setObjectName(QStringLiteral("pExit"));
        pExit->setGeometry(QRect(250, 194, 90, 30));

        retranslateUi(Login);

        QMetaObject::connectSlotsByName(Login);
    } // setupUi

    void retranslateUi(QDialog *Login)
    {
        Login->setWindowTitle(QApplication::translate("Login", "Dialog", Q_NULLPTR));
        pPersonInfo->setText(QApplication::translate("Login", "\346\237\245\347\234\213\344\270\252\344\272\272\345\237\272\346\234\254\344\277\241\346\201\257", Q_NULLPTR));
        pYearSalary->setText(QApplication::translate("Login", "\346\237\245\347\234\213\345\271\264\346\224\266\345\205\245", Q_NULLPTR));
        pMonSalary->setText(QApplication::translate("Login", "\346\237\245\347\234\213\346\257\217\346\234\210\346\224\266\345\205\245", Q_NULLPTR));
        pExtraRecord->setText(QApplication::translate("Login", "\346\237\245\347\234\213\345\212\240\347\217\255\350\256\260\345\275\225", Q_NULLPTR));
        pAttendRecord->setText(QApplication::translate("Login", "\346\237\245\347\234\213\350\200\203\345\213\244\350\256\260\345\275\225", Q_NULLPTR));
        pEditPwd->setText(QApplication::translate("Login", "\344\277\256\346\224\271\347\231\273\345\275\225\345\257\206\347\240\201", Q_NULLPTR));
        pDepartManage->setText(QApplication::translate("Login", "\351\203\250\351\227\250\347\256\241\347\220\206", Q_NULLPTR));
        pComManage->setText(QApplication::translate("Login", "\344\274\201\344\270\232\347\256\241\347\220\206", Q_NULLPTR));
        pSysManage->setText(QApplication::translate("Login", "\347\263\273\347\273\237\347\273\264\346\212\244", Q_NULLPTR));
        pExit->setText(QApplication::translate("Login", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Login: public Ui_Login {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
