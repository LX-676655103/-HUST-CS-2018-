#include "editbasesalary.h"
#include "ui_editbasesalary.h"

EditBaseSalary::EditBaseSalary(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::EditBaseSalary)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
    this->showBaseSalary();
}

EditBaseSalary::~EditBaseSalary()
{
    delete ui;
}

void EditBaseSalary::showBaseSalary()
{
    QSqlQueryModel *model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    QString str = "select t_id as '工种编号', t_name as '工种名',"
                  "t_rank as '工种等级', "
                  "base_salary as '基本工资'"
                  "from workerType order by t_id;";
    model->setQuery(str);
    ui->tableView->setModel(model);
}

void EditBaseSalary::on_pushButton_clicked()
{
    if(ui->pIDlineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请先输入工种编号！");
        return;
    }
    if(ui->pSalarylineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请先输入基本工资！");
        return;
    }
    QString id = ui->pIDlineEdit->text();
    QString salary = ui->pSalarylineEdit->text();


    /* 检验该记录是否存在 */
    QSqlQuery query;
    query.prepare("select * from workerType where t_id = " + id + ";");
    query.exec();
    if(!query.first()){
        QMessageBox::critical(this,"警告","该工种不存在！");
        return;
    }

    /* 修改基本工资 */
    QSqlQuery query_update;
    query_update.prepare("update workerType set base_salary=:b where t_id=:t;");
    query_update.bindValue(":t",id);
    query_update.bindValue(":b",salary);
    query_update.exec();
    this->showBaseSalary();
}
