/********************************************************************************
** Form generated from reading UI file 'showsalaryreport.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWSALARYREPORT_H
#define UI_SHOWSALARYREPORT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ShowSalaryReport
{
public:
    QTableView *tableView;
    QPushButton *pMonth;
    QPushButton *pYear;
    QPushButton *pPushOut;

    void setupUi(QDialog *ShowSalaryReport)
    {
        if (ShowSalaryReport->objectName().isEmpty())
            ShowSalaryReport->setObjectName(QStringLiteral("ShowSalaryReport"));
        ShowSalaryReport->resize(465, 300);
        tableView = new QTableView(ShowSalaryReport);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 15, 401, 220));
        pMonth = new QPushButton(ShowSalaryReport);
        pMonth->setObjectName(QStringLiteral("pMonth"));
        pMonth->setGeometry(QRect(90, 250, 100, 30));
        QFont font;
        font.setPointSize(10);
        pMonth->setFont(font);
        pYear = new QPushButton(ShowSalaryReport);
        pYear->setObjectName(QStringLiteral("pYear"));
        pYear->setGeometry(QRect(210, 250, 100, 30));
        pYear->setFont(font);
        pPushOut = new QPushButton(ShowSalaryReport);
        pPushOut->setObjectName(QStringLiteral("pPushOut"));
        pPushOut->setGeometry(QRect(330, 250, 100, 30));
        pPushOut->setFont(font);

        retranslateUi(ShowSalaryReport);

        QMetaObject::connectSlotsByName(ShowSalaryReport);
    } // setupUi

    void retranslateUi(QDialog *ShowSalaryReport)
    {
        ShowSalaryReport->setWindowTitle(QApplication::translate("ShowSalaryReport", "Dialog", Q_NULLPTR));
        pMonth->setText(QApplication::translate("ShowSalaryReport", "\346\214\211\346\234\210\346\237\245\347\234\213", Q_NULLPTR));
        pYear->setText(QApplication::translate("ShowSalaryReport", "\346\214\211\345\271\264\346\237\245\347\234\213", Q_NULLPTR));
        pPushOut->setText(QApplication::translate("ShowSalaryReport", "\345\257\274\345\207\272\344\270\272Excel", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ShowSalaryReport: public Ui_ShowSalaryReport {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWSALARYREPORT_H
