#ifndef SHOWYEARSALARY_H
#define SHOWYEARSALARY_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QDateTime>
#include <QString>

namespace Ui {
class ShowYearSalary;
}

class ShowYearSalary : public QDialog
{
    Q_OBJECT

public:
    explicit ShowYearSalary(QWidget *parent, QString id);
    ~ShowYearSalary();

private:
    QString w_id;
    QSqlQueryModel *model;
    Ui::ShowYearSalary *ui;
};

#endif // SHOWYEARSALARY_H
