/********************************************************************************
** Form generated from reading UI file 'showattendrecord.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWATTENDRECORD_H
#define UI_SHOWATTENDRECORD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ShowAttendRecord
{
public:
    QTableView *tableView;

    void setupUi(QDialog *ShowAttendRecord)
    {
        if (ShowAttendRecord->objectName().isEmpty())
            ShowAttendRecord->setObjectName(QStringLiteral("ShowAttendRecord"));
        ShowAttendRecord->resize(700, 300);
        tableView = new QTableView(ShowAttendRecord);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 15, 640, 260));

        retranslateUi(ShowAttendRecord);

        QMetaObject::connectSlotsByName(ShowAttendRecord);
    } // setupUi

    void retranslateUi(QDialog *ShowAttendRecord)
    {
        ShowAttendRecord->setWindowTitle(QApplication::translate("ShowAttendRecord", "Dialog", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ShowAttendRecord: public Ui_ShowAttendRecord {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWATTENDRECORD_H
