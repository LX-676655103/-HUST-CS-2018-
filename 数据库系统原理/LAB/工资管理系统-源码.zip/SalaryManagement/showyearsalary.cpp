#include "showyearsalary.h"
#include "ui_showyearsalary.h"

ShowYearSalary::ShowYearSalary(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::ShowYearSalary)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);

    /* 将数据模型与QTableView绑定 */
    model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    model->setQuery("select w_id as '员工编号', w_name as '姓名',"
                    "s_year as '年', "
                    "year_pay as '年工资',"
                    "year_award  as '年终奖金' "
                    "from year_salary "
                    "where w_id = " + id +
                    " order by s_year");
    ui->tableView->setModel(model);
}

ShowYearSalary::~ShowYearSalary()
{
    delete ui;
}
