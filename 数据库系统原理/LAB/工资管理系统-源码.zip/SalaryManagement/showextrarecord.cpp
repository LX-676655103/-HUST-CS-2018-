#include "showextrarecord.h"
#include "ui_showextrarecord.h"

ShowExtraRecord::ShowExtraRecord(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::ShowExtraRecord)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);

    model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    model->setQuery("select workerInfo.w_id as '员工编号', w_name as '姓名',"
                    "e_date as '加班日期', "
                    "begin_time as '开始时间',"
                    "end_time  as '结束时间',"
                    "duration as '加班时长',"
                    "type as '倍数',"
                    "(case e_status"
                    "   when 0 then '未修改' "
                    "   when 1 then '修改'"
                    "end)  as '是否修改',"
                    "payment as '加班津贴' "
                    "from extraWork, workerInfo "
                    "where workerInfo.w_id = " + id + " and workerInfo.w_id = extraWork.w_id"
                    " order by e_date;");
    ui->tableView->setModel(model);
}

ShowExtraRecord::~ShowExtraRecord()
{
    delete ui;
}
