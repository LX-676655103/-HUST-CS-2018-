#include "showquerysalary.h"
#include "ui_showquerysalary.h"
#include <QAxObject>
#include <QFileDialog>


ShowQuerySalary::ShowQuerySalary(QWidget *parent, QString d_id, bool is_depart) :
    QDialog(parent), d_id(d_id), is_depart(is_depart),
    ui(new Ui::ShowQuerySalary)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    this->on_pWorkerNum_clicked();
}

ShowQuerySalary::~ShowQuerySalary()
{
    delete ui;
}

void ShowQuerySalary::on_pWorkerNum_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel(ui->tableView);
    QString str = "select w_id as '员工编号', w_name as '姓名', w_sex as '性别',"
                  "w_telephone as '电话', "
                  "d_name as '部门',"
                  "t_name as '工种' "
                  "from workerInfo, workerType, department where ";
    if(is_depart) str = str + "department.d_id = " + d_id + " and ";
    str = str + "is_leave = 0 "
                "and department.d_id = workerInfo.d_id "
                "and workerInfo.t_id = workerType.t_id "
                "order by w_id;";
    model->setQuery(str);
    ui->tableView->setModel(model);
}

void ShowQuerySalary::on_pQuery_clicked()
{
    if(ui->pNumlineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请先输入员工编号！");
        return;
    }

    QString id = ui->pNumlineEdit->text();

    /* 查找当前员工是否存在记录 */
    QSqlQuery query;
    query.prepare("select * from workerInfo where w_id = " + id + ";");
    query.exec();
    if(!query.first()){
        QMessageBox::critical(this,"警告","该员工不存在！");
        return;
    }

    /* 显示记录 */
    QSqlQueryModel *model = new QSqlQueryModel(ui->tableView);
    QString str = "select w_id as '员工编号', w_name as '姓名',"
                  "d_name as '部门名称',"
                  "s_year as '年', s_month as '月',"
                  "base_pay as '基本工资', merit_pay  as '扣款', extra_pay as '加班津贴',"
                  "base_pay + merit_pay + extra_pay as '总月收入' "
                  "from month_salary "
                  " where w_id = " + id +
                  " order by s_year, s_month";

    model->setQuery(str);
    ui->tableView->setModel(model);
}

void ShowQuerySalary::on_pPushOut_clicked()
{
    QAxObject *excel;
    QAxObject *workBooks, *workBook;
    QAxObject *workSheets, *workSheet;
    QAxObject *range, *cell, *col;

    QString filepath = QFileDialog::getSaveFileName(this,tr("选择文件目录"),tr("d:\\"),tr("Files(*.xls *.xlsx)"));
    excel = new QAxObject("Excel.Application");
    if (!excel){
        qDebug() << "create excel file failed";
        QMessageBox::critical(this,"错误","文件创建失败！");
        return;
    }
    qDebug() << "create excel file successed";

    excel->dynamicCall("SetVisible (bool Visible)", true);
    excel->dynamicCall("SetUserControl(bool UserControl)", true);
    workBooks = excel->querySubObject("WorkBooks");
    workBooks->dynamicCall("Add");
    workBook = excel->querySubObject("ActiveWorkBook");
    workSheets = workBook->querySubObject("Sheets");
    workSheet = workSheets->querySubObject("Item(int)", 1);
    workSheet->setProperty("Name", "导出数据");

    int colCount = ui->tableView->model()->columnCount();
    int rowCount = ui->tableView->model()->rowCount();


    /* 写入数据到excel表格 */
    for (int i = 0; i < rowCount; i++)
        for (int j = 0; j < colCount; j++)
        {
            QModelIndex index = ui->tableView->model()->index(i, j);
            QString strData = ui->tableView->model()->data(index).toString();
            cell = workSheet->querySubObject("Cells(int, int)", i+2, j+1);
            cell->dynamicCall("SetValue(const QString&)", strData);
        }

    /* 设置列标题 */
    for (int i = 0; i < colCount; i++)
    {
        QString columnName;
        columnName.append(QChar(i + 'A'));
        columnName.append(QString::number(1));
        cell = workSheet->querySubObject("Range(const QString)", columnName);

        /* 单元格属性设置 */
        cell->setProperty("ColumnWidth", 500);
        cell->setProperty("RowHeight", 30);
        cell->querySubObject("Font")->setProperty("Bold", true);
        cell->querySubObject("Interior")->setProperty("Color", QColor(150, 150, 150));
        cell->setProperty("HorizontalAlignment", -4108);
        col = workSheet->querySubObject("Cells(int, int)", 1, i + 1);

        /* 获取tableView中的列标题数据 */
        columnName = ui->tableView->model()->headerData(i, Qt::Horizontal, Qt::DisplayRole).toString();
        col->dynamicCall("SetValue(const QString&)", columnName);
    }

    /* 对单元格画边框 */
    QString drawCellLine;
    drawCellLine.append("A1:");
    drawCellLine.append(colCount-1 + 'A');
    drawCellLine.append(QString::number(ui->tableView->model()->rowCount()));
    range = workSheet->querySubObject("Range(const QString&)", drawCellLine);
    range->querySubObject("Borders")->setProperty("LineStyle", QString::number(1));
    range->querySubObject("Borders")->setProperty("Color", QColor(0, 0, 0));

    /* 调整数据行高 */
    QString rowsName;
    rowsName.append("1:");
    rowsName.append(QString::number(ui->tableView->model()->rowCount()));
    range = workSheet->querySubObject("Range(const QString&)", rowsName);
    range->setProperty("RowHeight", 20);

    workBook->dynamicCall("SaveAs(const QString&)", QDir::toNativeSeparators(filepath));
    workBook->dynamicCall("Close()");
    excel->dynamicCall("Quit()");
    delete excel;
}
