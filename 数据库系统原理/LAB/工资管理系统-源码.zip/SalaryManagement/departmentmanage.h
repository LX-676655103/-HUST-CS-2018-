#ifndef DEPARTMENTMANAGE_H
#define DEPARTMENTMANAGE_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QDateTime>
#include <QString>
#include <QMessageBox>

#include "showsalaryreport.h"
#include "showquerysalary.h"
#include "editattendrecord.h"
#include "editextrarecord.h"

namespace Ui {
class DepartmentManage;
}

class DepartmentManage : public QDialog
{
    Q_OBJECT

public:
    explicit DepartmentManage(QWidget *parent, QString id);
    ~DepartmentManage();

private slots:
    void on_pSalaryReport_clicked();
    void on_pQuerySalary_clicked();
    void on_pEditAttend_clicked();
    void on_pEditExtraWork_clicked();
    void on_pExit_clicked();

private:
    QString w_id;
    Ui::DepartmentManage *ui;
    ShowSalaryReport* pShowSalaryReport;
    ShowQuerySalary* pShowQuerySalary;
    EditAttendRecord* pEditAttendRecord;
    EditExtraRecord* pEditExtraRecord;
};

#endif // DEPARTMENTMANAGE_H
