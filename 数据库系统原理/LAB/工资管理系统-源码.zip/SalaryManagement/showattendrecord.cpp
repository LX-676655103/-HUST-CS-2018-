#include "showattendrecord.h"
#include "ui_showattendrecord.h"

ShowAttendRecord::ShowAttendRecord(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::ShowAttendRecord)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);

    model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    model->setQuery("select workerInfo.w_id as '员工编号', w_name as '姓名',"
                    "a_date as '考勤日期', "
                    "begin_time as '签入时间',"
                    "end_time  as '签退时间',"
                    "(case a_status "
                    "   when 1 then '正常' "
                    "   when 2 then '迟到' "
                    "   when 3 then '缺勤' "
                    "   when 4 then '请假' "
                    "   when 5 then '早退'"
                    "end) as '考勤状态',"
                    "(case e_status"
                    "   when 0 then '未修改' "
                    "   when 1 then '修改'"
                    "end)  as '是否修改',"
                    "payment as '扣款' "
                    "from attendance, workerInfo "
                    "where workerInfo.w_id = " + id + " and workerInfo.w_id = attendance.w_id"
                    " order by a_date;");
    ui->tableView->setModel(model);
}

ShowAttendRecord::~ShowAttendRecord()
{
    delete ui;
}
