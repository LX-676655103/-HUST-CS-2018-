#ifndef SHOWMONTHSALARY_H
#define SHOWMONTHSALARY_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QDateTime>
#include <QString>

namespace Ui {
class ShowMonthSalary;
}

class ShowMonthSalary : public QDialog
{
    Q_OBJECT

public:
    explicit ShowMonthSalary(QWidget *parent, QString id);
    ~ShowMonthSalary();

private slots:
    void on_pFresh_clicked();

private:
    QString w_id;
    Ui::ShowMonthSalary *ui;
    QSqlQueryModel *model;
};

#endif // SHOWMONTHSALARY_H
