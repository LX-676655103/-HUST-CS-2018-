#ifndef EDITEXTRARECORD_H
#define EDITEXTRARECORD_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QHeaderView>
#include <QString>
#include <QMessageBox>
#include <QDebug>

namespace Ui {
class EditExtraRecord;
}

class EditExtraRecord : public QDialog
{
    Q_OBJECT

public:
    explicit EditExtraRecord(QWidget *parent, QString d_id, bool is_depart, QString w_id);
    ~EditExtraRecord();

private slots:
    void on_pushButton_clicked();

private:
    QString d_id;
    bool is_depart;
    QString w_id;
    Ui::EditExtraRecord *ui;
    void showExteaRecord();
};

#endif // EDITEXTRARECORD_H
