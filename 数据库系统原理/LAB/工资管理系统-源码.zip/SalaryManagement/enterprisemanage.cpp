#include "enterprisemanage.h"
#include "ui_enterprisemanage.h"

EnterpriseManage::EnterpriseManage(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::EnterpriseManage)
{
    ui->setupUi(this);
    this->setWindowTitle("企业管理");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
}

EnterpriseManage::~EnterpriseManage()
{
    delete ui;
}

void EnterpriseManage::on_pSalaryReport_clicked()
{
    pShowSalaryReport = new ShowSalaryReport(this, "0", 0);
    pShowSalaryReport->setWindowModality(Qt::ApplicationModal);
    pShowSalaryReport->show();
}

void EnterpriseManage::on_pQuerySalary_clicked()
{
    pShowQuerySalary = new ShowQuerySalary(this, "", 0);
    pShowQuerySalary->setWindowModality(Qt::ApplicationModal);
    pShowQuerySalary->show();
}

void EnterpriseManage::on_pEditAttend_clicked()
{
    pEditAttendRecord = new EditAttendRecord(this, "", 0, w_id);
    pEditAttendRecord->setWindowModality(Qt::ApplicationModal);
    pEditAttendRecord->show();
}

void EnterpriseManage::on_pEditExtraWork_clicked()
{
    pEditExtraRecord = new EditExtraRecord(this, "", 0, w_id);
    pEditExtraRecord->setWindowModality(Qt::ApplicationModal);
    pEditExtraRecord->show();
}

void EnterpriseManage::on_pExit_clicked()
{
    this->hide();
}
