#ifndef WIDGET_H
#define WIDGET_H

#include "dbinstance.h"
#include "user.h"
#include "login.h"
#include <QDebug>
#include <QSqlQuery>
#include <QApplication>
#include <QWidget>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pLoginButton_clicked();

private:
    Ui::Widget *ui;
    Login *login;
    DBInstance* dbinstance;
};

#endif // WIDGET_H
