/********************************************************************************
** Form generated from reading UI file 'showyearsalary.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWYEARSALARY_H
#define UI_SHOWYEARSALARY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ShowYearSalary
{
public:
    QTableView *tableView;

    void setupUi(QDialog *ShowYearSalary)
    {
        if (ShowYearSalary->objectName().isEmpty())
            ShowYearSalary->setObjectName(QStringLiteral("ShowYearSalary"));
        ShowYearSalary->resize(610, 305);
        tableView = new QTableView(ShowYearSalary);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 10, 551, 241));

        retranslateUi(ShowYearSalary);

        QMetaObject::connectSlotsByName(ShowYearSalary);
    } // setupUi

    void retranslateUi(QDialog *ShowYearSalary)
    {
        ShowYearSalary->setWindowTitle(QApplication::translate("ShowYearSalary", "Dialog", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ShowYearSalary: public Ui_ShowYearSalary {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWYEARSALARY_H
