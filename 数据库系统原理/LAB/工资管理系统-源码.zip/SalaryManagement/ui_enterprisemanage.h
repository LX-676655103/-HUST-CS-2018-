/********************************************************************************
** Form generated from reading UI file 'enterprisemanage.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENTERPRISEMANAGE_H
#define UI_ENTERPRISEMANAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_EnterpriseManage
{
public:
    QPushButton *pQuerySalary;
    QPushButton *pSalaryReport;
    QPushButton *pEditExtraWork;
    QPushButton *pEditAttend;
    QPushButton *pExit;

    void setupUi(QDialog *EnterpriseManage)
    {
        if (EnterpriseManage->objectName().isEmpty())
            EnterpriseManage->setObjectName(QStringLiteral("EnterpriseManage"));
        EnterpriseManage->resize(400, 231);
        pQuerySalary = new QPushButton(EnterpriseManage);
        pQuerySalary->setObjectName(QStringLiteral("pQuerySalary"));
        pQuerySalary->setGeometry(QRect(60, 73, 120, 25));
        QFont font;
        font.setPointSize(10);
        pQuerySalary->setFont(font);
        pSalaryReport = new QPushButton(EnterpriseManage);
        pSalaryReport->setObjectName(QStringLiteral("pSalaryReport"));
        pSalaryReport->setGeometry(QRect(60, 33, 120, 25));
        pSalaryReport->setFont(font);
        pEditExtraWork = new QPushButton(EnterpriseManage);
        pEditExtraWork->setObjectName(QStringLiteral("pEditExtraWork"));
        pEditExtraWork->setGeometry(QRect(60, 153, 120, 25));
        pEditExtraWork->setFont(font);
        pEditAttend = new QPushButton(EnterpriseManage);
        pEditAttend->setObjectName(QStringLiteral("pEditAttend"));
        pEditAttend->setGeometry(QRect(60, 113, 120, 25));
        pEditAttend->setFont(font);
        pExit = new QPushButton(EnterpriseManage);
        pExit->setObjectName(QStringLiteral("pExit"));
        pExit->setGeometry(QRect(260, 150, 90, 30));
        pExit->setFont(font);

        retranslateUi(EnterpriseManage);

        QMetaObject::connectSlotsByName(EnterpriseManage);
    } // setupUi

    void retranslateUi(QDialog *EnterpriseManage)
    {
        EnterpriseManage->setWindowTitle(QApplication::translate("EnterpriseManage", "Dialog", Q_NULLPTR));
        pQuerySalary->setText(QApplication::translate("EnterpriseManage", "\346\237\245\350\257\242\345\221\230\345\267\245\345\267\245\350\265\204", Q_NULLPTR));
        pSalaryReport->setText(QApplication::translate("EnterpriseManage", "\346\237\245\347\234\213\345\267\245\350\265\204\346\212\245\350\241\250", Q_NULLPTR));
        pEditExtraWork->setText(QApplication::translate("EnterpriseManage", "\344\277\256\346\224\271\345\221\230\345\267\245\345\212\240\347\217\255\350\256\260\345\275\225", Q_NULLPTR));
        pEditAttend->setText(QApplication::translate("EnterpriseManage", "\344\277\256\346\224\271\345\221\230\345\267\245\350\200\203\345\213\244\347\212\266\346\200\201", Q_NULLPTR));
        pExit->setText(QApplication::translate("EnterpriseManage", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class EnterpriseManage: public Ui_EnterpriseManage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENTERPRISEMANAGE_H
