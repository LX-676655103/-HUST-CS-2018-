/********************************************************************************
** Form generated from reading UI file 'editextrarecord.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITEXTRARECORD_H
#define UI_EDITEXTRARECORD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_EditExtraRecord
{
public:
    QTableView *tableView;
    QLabel *pDuralabel;
    QLabel *pTypelabel;
    QLabel *pIDlabel;
    QLabel *pDatelabel;
    QPushButton *pushButton;
    QLineEdit *pIDlineEdit;
    QLineEdit *pDatelineEdit;
    QLineEdit *pDuralineEdit;
    QLineEdit *pTypelineEdit;

    void setupUi(QDialog *EditExtraRecord)
    {
        if (EditExtraRecord->objectName().isEmpty())
            EditExtraRecord->setObjectName(QStringLiteral("EditExtraRecord"));
        EditExtraRecord->resize(700, 300);
        tableView = new QTableView(EditExtraRecord);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 15, 450, 260));
        pDuralabel = new QLabel(EditExtraRecord);
        pDuralabel->setObjectName(QStringLiteral("pDuralabel"));
        pDuralabel->setGeometry(QRect(490, 100, 70, 30));
        QFont font;
        font.setPointSize(10);
        pDuralabel->setFont(font);
        pTypelabel = new QLabel(EditExtraRecord);
        pTypelabel->setObjectName(QStringLiteral("pTypelabel"));
        pTypelabel->setGeometry(QRect(490, 140, 70, 30));
        pTypelabel->setFont(font);
        pIDlabel = new QLabel(EditExtraRecord);
        pIDlabel->setObjectName(QStringLiteral("pIDlabel"));
        pIDlabel->setGeometry(QRect(490, 20, 70, 30));
        pIDlabel->setFont(font);
        pDatelabel = new QLabel(EditExtraRecord);
        pDatelabel->setObjectName(QStringLiteral("pDatelabel"));
        pDatelabel->setGeometry(QRect(490, 60, 70, 30));
        pDatelabel->setFont(font);
        pushButton = new QPushButton(EditExtraRecord);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(590, 240, 90, 30));
        pIDlineEdit = new QLineEdit(EditExtraRecord);
        pIDlineEdit->setObjectName(QStringLiteral("pIDlineEdit"));
        pIDlineEdit->setGeometry(QRect(560, 20, 120, 30));
        pDatelineEdit = new QLineEdit(EditExtraRecord);
        pDatelineEdit->setObjectName(QStringLiteral("pDatelineEdit"));
        pDatelineEdit->setGeometry(QRect(560, 60, 120, 30));
        pDuralineEdit = new QLineEdit(EditExtraRecord);
        pDuralineEdit->setObjectName(QStringLiteral("pDuralineEdit"));
        pDuralineEdit->setGeometry(QRect(560, 100, 120, 30));
        pTypelineEdit = new QLineEdit(EditExtraRecord);
        pTypelineEdit->setObjectName(QStringLiteral("pTypelineEdit"));
        pTypelineEdit->setGeometry(QRect(560, 140, 120, 30));

        retranslateUi(EditExtraRecord);

        QMetaObject::connectSlotsByName(EditExtraRecord);
    } // setupUi

    void retranslateUi(QDialog *EditExtraRecord)
    {
        EditExtraRecord->setWindowTitle(QApplication::translate("EditExtraRecord", "Dialog", Q_NULLPTR));
        pDuralabel->setText(QApplication::translate("EditExtraRecord", "\345\212\240\347\217\255\346\227\266\351\225\277\357\274\232", Q_NULLPTR));
        pTypelabel->setText(QApplication::translate("EditExtraRecord", "\345\212\240\347\217\255\347\261\273\345\236\213\357\274\232", Q_NULLPTR));
        pIDlabel->setText(QApplication::translate("EditExtraRecord", "\345\221\230\345\267\245\347\274\226\345\217\267\357\274\232", Q_NULLPTR));
        pDatelabel->setText(QApplication::translate("EditExtraRecord", "\345\212\240\347\217\255\346\227\245\346\234\237\357\274\232", Q_NULLPTR));
        pushButton->setText(QApplication::translate("EditExtraRecord", "\347\241\256\350\256\244\344\277\256\346\224\271", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class EditExtraRecord: public Ui_EditExtraRecord {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITEXTRARECORD_H
