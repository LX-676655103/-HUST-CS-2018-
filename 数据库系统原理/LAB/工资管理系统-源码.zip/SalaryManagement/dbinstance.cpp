#include "dbinstance.h"
#include <QDebug>
#include <QString>
#include <QSqlError>
#include <QMessageBox>
#include <QApplication>

DBInstance *DBInstance::dbinstance = NULL;

DBInstance::DBInstance()
{
    db = QSqlDatabase::addDatabase("QODBC");
    QString dsn = QString::fromLocal8Bit("QTDSN");
    db.setHostName("localhost");
    db.setDatabaseName(dsn);
    db.setUserName("sa");
    db.setPassword("123456");
}
DBInstance *DBInstance::getInstance()
{
    if(dbinstance == NULL)
        dbinstance = new DBInstance();
    return dbinstance;
}

bool DBInstance:: openDatabase()
{
    if(!db.open())
    {
        qDebug() << db.lastError().text();
        QMessageBox::critical(0, QObject::tr("Database open error!"), db.lastError().text());
        return false;
    }
    else qDebug()<<"Database open success!\n";
    return true;
}

bool DBInstance:: closeDatabase()
{
    db.close();
    db.removeDatabase("QTDSN");
    qDebug()<<"Database close success!\n";
    return true;
}
