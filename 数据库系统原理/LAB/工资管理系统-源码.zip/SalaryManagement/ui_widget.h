/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLineEdit *pUsrlineEdit;
    QLabel *pPwdlabel;
    QPushButton *pLoginButton;
    QLabel *pUsrlabel;
    QLineEdit *pPwdlineEdit;
    QLabel *pSysNamelabel;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->setWindowModality(Qt::ApplicationModal);
        Widget->resize(465, 276);
        QFont font;
        font.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        Widget->setFont(font);
        gridLayoutWidget = new QWidget(Widget);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(30, 30, 361, 181));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setHorizontalSpacing(6);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pUsrlineEdit = new QLineEdit(gridLayoutWidget);
        pUsrlineEdit->setObjectName(QStringLiteral("pUsrlineEdit"));

        gridLayout->addWidget(pUsrlineEdit, 3, 1, 1, 1);

        pPwdlabel = new QLabel(gridLayoutWidget);
        pPwdlabel->setObjectName(QStringLiteral("pPwdlabel"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font1.setPointSize(10);
        pPwdlabel->setFont(font1);
        pPwdlabel->setTextFormat(Qt::PlainText);

        gridLayout->addWidget(pPwdlabel, 5, 0, 1, 1);

        pLoginButton = new QPushButton(gridLayoutWidget);
        pLoginButton->setObjectName(QStringLiteral("pLoginButton"));
        pLoginButton->setFont(font1);

        gridLayout->addWidget(pLoginButton, 6, 1, 1, 1);

        pUsrlabel = new QLabel(gridLayoutWidget);
        pUsrlabel->setObjectName(QStringLiteral("pUsrlabel"));
        pUsrlabel->setFont(font1);
        pUsrlabel->setTextFormat(Qt::PlainText);

        gridLayout->addWidget(pUsrlabel, 3, 0, 1, 1);

        pPwdlineEdit = new QLineEdit(gridLayoutWidget);
        pPwdlineEdit->setObjectName(QStringLiteral("pPwdlineEdit"));

        gridLayout->addWidget(pPwdlineEdit, 5, 1, 1, 1);

        pSysNamelabel = new QLabel(gridLayoutWidget);
        pSysNamelabel->setObjectName(QStringLiteral("pSysNamelabel"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\351\273\221\344\275\223"));
        font2.setPointSize(15);
        pSysNamelabel->setFont(font2);
        pSysNamelabel->setTextFormat(Qt::PlainText);
        pSysNamelabel->setScaledContents(false);
        pSysNamelabel->setAlignment(Qt::AlignCenter);
        pSysNamelabel->setMargin(0);

        gridLayout->addWidget(pSysNamelabel, 0, 1, 1, 1);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", Q_NULLPTR));
        pPwdlabel->setText(QApplication::translate("Widget", "\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        pLoginButton->setText(QApplication::translate("Widget", "\347\231\273\345\275\225", Q_NULLPTR));
        pUsrlabel->setText(QApplication::translate("Widget", "\345\221\230\345\267\245\347\274\226\345\217\267\357\274\232", Q_NULLPTR));
        pSysNamelabel->setText(QApplication::translate("Widget", "\346\254\242\350\277\216\344\275\277\347\224\250\345\267\245\350\265\204\347\256\241\347\220\206\347\263\273\347\273\237\357\274\201", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
