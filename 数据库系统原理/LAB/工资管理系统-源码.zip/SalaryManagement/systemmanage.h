#ifndef SYSTEMMANAGE_H
#define SYSTEMMANAGE_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QHeaderView>
#include <QString>
#include <QMessageBox>
#include <QDebug>
#include "editbasesalary.h"

namespace Ui {
class SystemManage;
}

class SystemManage : public QDialog
{
    Q_OBJECT

public:
    explicit SystemManage(QWidget *parent, QString id);
    ~SystemManage();

private slots:
    void on_pEditBaseSalary_clicked();

    void on_pExit_clicked();

private:
    QString w_id;
    Ui::SystemManage *ui;
    EditBaseSalary *pEditBaseSalary;
};

#endif // SYSTEMMANAGE_H
