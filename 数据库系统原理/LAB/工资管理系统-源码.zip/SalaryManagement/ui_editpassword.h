/********************************************************************************
** Form generated from reading UI file 'editpassword.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITPASSWORD_H
#define UI_EDITPASSWORD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_EditPassWord
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *pNewPwdLabel_2;
    QLabel *pNewPwdLabel_1;
    QLineEdit *plineEdit_1;
    QLineEdit *plineEdit_2;
    QPushButton *pConfirmButton;

    void setupUi(QDialog *EditPassWord)
    {
        if (EditPassWord->objectName().isEmpty())
            EditPassWord->setObjectName(QStringLiteral("EditPassWord"));
        EditPassWord->resize(400, 199);
        gridLayoutWidget = new QWidget(EditPassWord);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(37, 24, 311, 121));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pNewPwdLabel_2 = new QLabel(gridLayoutWidget);
        pNewPwdLabel_2->setObjectName(QStringLiteral("pNewPwdLabel_2"));
        QFont font;
        font.setPointSize(11);
        pNewPwdLabel_2->setFont(font);
        pNewPwdLabel_2->setFrameShape(QFrame::NoFrame);

        gridLayout->addWidget(pNewPwdLabel_2, 1, 0, 1, 1);

        pNewPwdLabel_1 = new QLabel(gridLayoutWidget);
        pNewPwdLabel_1->setObjectName(QStringLiteral("pNewPwdLabel_1"));
        pNewPwdLabel_1->setFont(font);

        gridLayout->addWidget(pNewPwdLabel_1, 0, 0, 1, 1);

        plineEdit_1 = new QLineEdit(gridLayoutWidget);
        plineEdit_1->setObjectName(QStringLiteral("plineEdit_1"));

        gridLayout->addWidget(plineEdit_1, 0, 1, 1, 1);

        plineEdit_2 = new QLineEdit(gridLayoutWidget);
        plineEdit_2->setObjectName(QStringLiteral("plineEdit_2"));

        gridLayout->addWidget(plineEdit_2, 1, 1, 1, 1);

        pConfirmButton = new QPushButton(EditPassWord);
        pConfirmButton->setObjectName(QStringLiteral("pConfirmButton"));
        pConfirmButton->setGeometry(QRect(268, 146, 90, 30));
        pConfirmButton->setFont(font);

        retranslateUi(EditPassWord);

        QMetaObject::connectSlotsByName(EditPassWord);
    } // setupUi

    void retranslateUi(QDialog *EditPassWord)
    {
        EditPassWord->setWindowTitle(QApplication::translate("EditPassWord", "Dialog", Q_NULLPTR));
        pNewPwdLabel_2->setText(QApplication::translate("EditPassWord", "\345\206\215\346\254\241\350\276\223\345\205\245\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        pNewPwdLabel_1->setText(QApplication::translate("EditPassWord", "\350\257\267\350\276\223\345\205\245\346\226\260\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        pConfirmButton->setText(QApplication::translate("EditPassWord", "\347\241\256\350\256\244", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class EditPassWord: public Ui_EditPassWord {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITPASSWORD_H
