#include "login.h"
#include "ui_login.h"
#include <QDebug>
#include <QIcon>


Login::Login(QWidget *parent) :
    QDialog(parent), parent(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
    puser = NULL;
}

Login::~Login()
{
    delete ui;
    if(puser) delete puser;
}

void Login::setUser(User &user)
{
    if(puser==NULL)
        puser = new User(user.getName(),user.getPwd(),user.getPermission());
    else
    {
        delete puser;
        puser = new User(user.getName(),user.getPwd(),user.getPermission());
    }
}

void Login::on_pPersonInfo_clicked()
{
    pShowWorkerInfo = new ShowWorkerInfo(this, puser->getName());
    pShowWorkerInfo->setWindowModality(Qt::ApplicationModal);
    pShowWorkerInfo->show();
}

void Login::on_pMonSalary_clicked()
{
    pShowMonthSalary = new ShowMonthSalary(this, puser->getName());
    pShowMonthSalary->setWindowModality(Qt::ApplicationModal);
    pShowMonthSalary->show();
}

void Login::on_pYearSalary_clicked()
{
    pShowYearSalary = new ShowYearSalary(this, puser->getName());
    pShowYearSalary->setWindowModality(Qt::ApplicationModal);
    pShowYearSalary->show();
}

void Login::on_pAttendRecord_clicked()
{
    pShowAttendRecord = new ShowAttendRecord(this, puser->getName());
    pShowAttendRecord->setWindowModality(Qt::ApplicationModal);
    pShowAttendRecord->show();
}

void Login::on_pExtraRecord_clicked()
{
    pShowExtraRecord = new ShowExtraRecord(this, puser->getName());
    pShowExtraRecord->setWindowModality(Qt::ApplicationModal);
    pShowExtraRecord->show();
}

void Login::on_pEditPwd_clicked()
{
    pEditPassWord = new EditPassWord(this, puser->getName());
    pEditPassWord->setWindowModality(Qt::ApplicationModal);
    pEditPassWord->show();
}

void Login::on_pExit_clicked()
{
    this->hide();
    parent->show();
}

void Login::on_pDepartManage_clicked()
{
    if(puser->getPermission().toInt() < 2){
        QMessageBox::critical(this,"警告","抱歉，您的权限过低！");
        return;
    }
    pDepartmentManage = new DepartmentManage(this, puser->getName());
    pDepartmentManage->setWindowModality(Qt::ApplicationModal);
    pDepartmentManage->show();
}

void Login::on_pComManage_clicked()
{
    if(puser->getPermission().toInt() < 3){
        QMessageBox::critical(this,"警告","抱歉，您的权限过低！");
        return;
    }
    pEnterpriseManage = new EnterpriseManage(this, puser->getName());
    pEnterpriseManage->setWindowModality(Qt::ApplicationModal);
    pEnterpriseManage->show();
}

void Login::on_pSysManage_clicked()
{
    if(puser->getPermission().toInt() < 4){
        QMessageBox::critical(this,"警告","抱歉，您的权限过低！");
        return;
    }
    pSystemManage = new SystemManage(this, puser->getName());
    pSystemManage->setWindowModality(Qt::ApplicationModal);
    pSystemManage->show();
}
