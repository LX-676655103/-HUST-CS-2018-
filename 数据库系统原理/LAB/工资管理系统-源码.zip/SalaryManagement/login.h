#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <QString>
#include <QMessageBox>
#include "user.h"

#include "showworkerinfo.h"
#include "showmonthsalary.h"
#include "showyearsalary.h"
#include "showattendrecord.h"
#include "showextrarecord.h"
#include "editpassword.h"
#include "departmentmanage.h"
#include "enterprisemanage.h"
#include "systemmanage.h"

namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = 0);
    ~Login();
    void setUser(User &user);

private slots:
    void on_pPersonInfo_clicked();
    void on_pMonSalary_clicked();
    void on_pYearSalary_clicked();
    void on_pAttendRecord_clicked();
    void on_pExtraRecord_clicked();
    void on_pEditPwd_clicked();
    void on_pExit_clicked();
    void on_pDepartManage_clicked();
    void on_pComManage_clicked();
    void on_pSysManage_clicked();

private:
    QWidget * parent;
    Ui::Login *ui;
    User *puser;
    ShowWorkerInfo *pShowWorkerInfo;
    ShowMonthSalary *pShowMonthSalary;
    ShowYearSalary *pShowYearSalary;
    ShowAttendRecord *pShowAttendRecord;
    ShowExtraRecord* pShowExtraRecord;
    EditPassWord* pEditPassWord;
    DepartmentManage* pDepartmentManage;
    EnterpriseManage* pEnterpriseManage;
    SystemManage* pSystemManage;
};

#endif // LOGIN_H
