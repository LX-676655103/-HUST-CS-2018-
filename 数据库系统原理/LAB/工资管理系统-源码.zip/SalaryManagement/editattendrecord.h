#ifndef EDITATTENDRECORD_H
#define EDITATTENDRECORD_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QHeaderView>
#include <QString>
#include <QMessageBox>
#include <QDebug>

namespace Ui {
class EditAttendRecord;
}

class EditAttendRecord : public QDialog
{
    Q_OBJECT

public:
    explicit EditAttendRecord(QWidget *parent, QString d_id, bool is_depart, QString w_id);
    ~EditAttendRecord();

private slots:
    void on_pushButton_clicked();

private:
    QString d_id;
    bool is_depart;
    QString w_id;
    Ui::EditAttendRecord *ui;
    void showAtttendRecord();
};

#endif // EDITATTENDRECORD_H
