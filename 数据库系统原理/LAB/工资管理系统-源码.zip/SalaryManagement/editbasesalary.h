#ifndef EDITBASESALARY_H
#define EDITBASESALARY_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QHeaderView>
#include <QString>
#include <QMessageBox>
#include <QDebug>

namespace Ui {
class EditBaseSalary;
}

class EditBaseSalary : public QDialog
{
    Q_OBJECT

public:
    explicit EditBaseSalary(QWidget *parent, QString id);
    ~EditBaseSalary();

private slots:
    void on_pushButton_clicked();

private:
    QString w_id;
    Ui::EditBaseSalary *ui;
    void showBaseSalary();
};

#endif // EDITBASESALARY_H
