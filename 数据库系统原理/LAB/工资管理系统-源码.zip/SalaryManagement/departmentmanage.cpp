#include "departmentmanage.h"
#include "ui_departmentmanage.h"

DepartmentManage::DepartmentManage(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::DepartmentManage)
{
    ui->setupUi(this);
    this->setWindowTitle("部门管理");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
}

DepartmentManage::~DepartmentManage()
{
    delete ui;
}

void DepartmentManage::on_pSalaryReport_clicked()
{
    QSqlQuery query;
    query.prepare(" select department.d_id from workerInfo, department"
                  " where workerInfo.w_id = " + w_id +
                  " and workerInfo.d_id = department.d_id;");
    query.exec();
    query.first();
    QString d_id = query.value(0).toString();

    pShowSalaryReport = new ShowSalaryReport(this, d_id,1);
    pShowSalaryReport->setWindowModality(Qt::ApplicationModal);
    pShowSalaryReport->show();
}

void DepartmentManage::on_pQuerySalary_clicked()
{
    QSqlQuery query;
    query.prepare(" select department.d_id from workerInfo, department"
                  " where workerInfo.w_id = " + w_id +
                  " and workerInfo.d_id = department.d_id;");
    query.exec();
    query.first();
    QString d_id = query.value(0).toString();

    pShowQuerySalary = new ShowQuerySalary(this, d_id,1);
    pShowQuerySalary->setWindowModality(Qt::ApplicationModal);
    pShowQuerySalary->show();
}

void DepartmentManage::on_pEditAttend_clicked()
{
    QSqlQuery query;
    query.prepare(" select department.d_id from workerInfo, department"
                  " where workerInfo.w_id = " + w_id +
                  " and workerInfo.d_id = department.d_id;");
    query.exec();
    query.first();
    QString d_id = query.value(0).toString();

    pEditAttendRecord = new EditAttendRecord(this, d_id, 1, w_id);
    pEditAttendRecord->setWindowModality(Qt::ApplicationModal);
    pEditAttendRecord->show();
}

void DepartmentManage::on_pEditExtraWork_clicked()
{
    QSqlQuery query;
    query.prepare(" select department.d_id from workerInfo, department"
                  " where workerInfo.w_id = " + w_id +
                  " and workerInfo.d_id = department.d_id;");
    query.exec();
    query.first();
    QString d_id = query.value(0).toString();

    pEditExtraRecord = new EditExtraRecord(this, d_id, 1, w_id);
    pEditExtraRecord->setWindowModality(Qt::ApplicationModal);
    pEditExtraRecord->show();
}

void DepartmentManage::on_pExit_clicked()
{
    this->hide();
}
