#ifndef ENTERPRISEMANAGE_H
#define ENTERPRISEMANAGE_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QDateTime>
#include <QString>
#include <QMessageBox>

#include "showsalaryreport.h"
#include "showquerysalary.h"
#include "editattendrecord.h"
#include "editextrarecord.h"

namespace Ui {
class EnterpriseManage;
}

class EnterpriseManage : public QDialog
{
    Q_OBJECT

public:
    explicit EnterpriseManage(QWidget *parent, QString id);
    ~EnterpriseManage();

private slots:
    void on_pSalaryReport_clicked();
    void on_pQuerySalary_clicked();
    void on_pEditAttend_clicked();
    void on_pEditExtraWork_clicked();
    void on_pExit_clicked();

private:
    QString w_id;
    Ui::EnterpriseManage *ui;
    ShowSalaryReport* pShowSalaryReport;
    ShowQuerySalary* pShowQuerySalary;
    EditAttendRecord* pEditAttendRecord;
    EditExtraRecord* pEditExtraRecord;

};

#endif // ENTERPRISEMANAGE_H
