/********************************************************************************
** Form generated from reading UI file 'systemmanage.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SYSTEMMANAGE_H
#define UI_SYSTEMMANAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_SystemManage
{
public:
    QPushButton *pEditBaseSalary;
    QPushButton *pExit;

    void setupUi(QDialog *SystemManage)
    {
        if (SystemManage->objectName().isEmpty())
            SystemManage->setObjectName(QStringLiteral("SystemManage"));
        SystemManage->resize(400, 250);
        pEditBaseSalary = new QPushButton(SystemManage);
        pEditBaseSalary->setObjectName(QStringLiteral("pEditBaseSalary"));
        pEditBaseSalary->setGeometry(QRect(40, 20, 120, 30));
        QFont font;
        font.setPointSize(10);
        pEditBaseSalary->setFont(font);
        pExit = new QPushButton(SystemManage);
        pExit->setObjectName(QStringLiteral("pExit"));
        pExit->setGeometry(QRect(270, 190, 90, 30));
        pExit->setFont(font);

        retranslateUi(SystemManage);

        QMetaObject::connectSlotsByName(SystemManage);
    } // setupUi

    void retranslateUi(QDialog *SystemManage)
    {
        SystemManage->setWindowTitle(QApplication::translate("SystemManage", "Dialog", Q_NULLPTR));
        pEditBaseSalary->setText(QApplication::translate("SystemManage", "\344\277\256\346\224\271\345\267\245\347\247\215\345\237\272\346\234\254\345\267\245\350\265\204", Q_NULLPTR));
        pExit->setText(QApplication::translate("SystemManage", "\351\200\200\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class SystemManage: public Ui_SystemManage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SYSTEMMANAGE_H
