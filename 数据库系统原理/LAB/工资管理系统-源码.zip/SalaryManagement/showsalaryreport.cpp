#include "showsalaryreport.h"
#include "ui_showsalaryreport.h"
#include <QAxObject>
#include <QFileDialog>

ShowSalaryReport::ShowSalaryReport(QWidget *parent, QString d_id, bool is_depart) :
    QDialog(parent), d_id(d_id), is_depart(is_depart),
    ui(new Ui::ShowSalaryReport)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
}

ShowSalaryReport::~ShowSalaryReport()
{
    delete ui;
}

void ShowSalaryReport::on_pMonth_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    QString str = "select d_name as '部门名称',"
                  "s_year as '年',"
                  "s_month as '月',"
                  "sum(base_pay + merit_pay + extra_pay) as '月部门工资支出' "
                  "from month_salary";
    if(is_depart) str = str + " where d_id = " + d_id ;
    str = str + " group by d_id, d_name, s_year, s_month"
                " order by s_year, s_month;";

    model->setQuery(str);
    ui->tableView->setModel(model);
}

void ShowSalaryReport::on_pYear_clicked()
{
    QSqlQueryModel *model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    QString str = "select d_name as '部门名称',"
                  "s_year as '年',"
                  "sum(base_pay + merit_pay + extra_pay) as '年部门工资支出' "
                  "from month_salary ";
    if(is_depart) str = str + " where d_id = " + d_id ;
    str = str + " group by d_id, d_name, s_year"
                " order by s_year;";

    model->setQuery(str);
    ui->tableView->setModel(model);
}

void ShowSalaryReport::on_pPushOut_clicked()
{
    QAxObject *excel;
    QAxObject *workBooks, *workBook;
    QAxObject *workSheets, *workSheet;
    QAxObject *range, *cell, *col;

    QString filepath = QFileDialog::getSaveFileName(this,tr("选择文件目录"),tr("d:\\"),tr("Files(*.xls *.xlsx)"));
    excel = new QAxObject("Excel.Application");
    if (!excel){
        qDebug() << "create excel file failed";
        QMessageBox::critical(this,"错误","文件创建失败！");
        return;
    }
    qDebug() << "create excel file successed";

    excel->dynamicCall("SetVisible (bool Visible)", true);
    excel->dynamicCall("SetUserControl(bool UserControl)", true);
    workBooks = excel->querySubObject("WorkBooks");
    workBooks->dynamicCall("Add");
    workBook = excel->querySubObject("ActiveWorkBook");
    workSheets = workBook->querySubObject("Sheets");
    workSheet = workSheets->querySubObject("Item(int)", 1);
    workSheet->setProperty("Name", "导出数据");

    int colCount = ui->tableView->model()->columnCount();
    int rowCount = ui->tableView->model()->rowCount();


    /* 写入数据到excel表格 */
    for (int i = 0; i < rowCount; i++)
        for (int j = 0; j < colCount; j++)
        {
            QModelIndex index = ui->tableView->model()->index(i, j);
            QString strData = ui->tableView->model()->data(index).toString();
            cell = workSheet->querySubObject("Cells(int, int)", i+2, j+1);
            cell->dynamicCall("SetValue(const QString&)", strData);
        }

    /* 设置列标题 */
    for (int i = 0; i < colCount; i++)
    {
        QString columnName;
        columnName.append(QChar(i + 'A'));
        columnName.append(QString::number(1));
        cell = workSheet->querySubObject("Range(const QString)", columnName);

        /* 单元格属性设置 */
        cell->setProperty("ColumnWidth", 500);
        cell->setProperty("RowHeight", 30);
        cell->querySubObject("Font")->setProperty("Bold", true);
        cell->querySubObject("Interior")->setProperty("Color", QColor(150, 150, 150));
        cell->setProperty("HorizontalAlignment", -4108);
        col = workSheet->querySubObject("Cells(int, int)", 1, i + 1);

        /* 获取tableView中的列标题数据 */
        columnName = ui->tableView->model()->headerData(i, Qt::Horizontal, Qt::DisplayRole).toString();
        col->dynamicCall("SetValue(const QString&)", columnName);
    }

    /* 对单元格画边框 */
    QString drawCellLine;
    drawCellLine.append("A1:");
    drawCellLine.append(colCount-1 + 'A');
    drawCellLine.append(QString::number(ui->tableView->model()->rowCount()));
    range = workSheet->querySubObject("Range(const QString&)", drawCellLine);
    range->querySubObject("Borders")->setProperty("LineStyle", QString::number(1));
    range->querySubObject("Borders")->setProperty("Color", QColor(0, 0, 0));

    /* 调整数据行高 */
    QString rowsName;
    rowsName.append("1:");
    rowsName.append(QString::number(ui->tableView->model()->rowCount()));
    range = workSheet->querySubObject("Range(const QString&)", rowsName);
    range->setProperty("RowHeight", 20);

    workBook->dynamicCall("SaveAs(const QString&)", QDir::toNativeSeparators(filepath));
    workBook->dynamicCall("Close()");
    excel->dynamicCall("Quit()");
    delete excel;
}
