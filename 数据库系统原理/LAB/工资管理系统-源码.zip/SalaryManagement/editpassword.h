#ifndef EDITPASSWORD_H
#define EDITPASSWORD_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QDateTime>
#include <QString>
#include <QMessageBox>

namespace Ui {
class EditPassWord;
}

class EditPassWord : public QDialog
{
    Q_OBJECT

public:
    explicit EditPassWord(QWidget *parent, QString id);
    ~EditPassWord();

private slots:
    void on_pConfirmButton_clicked();

private:
    QString w_id;
    Ui::EditPassWord *ui;
};

#endif // EDITPASSWORD_H
