/********************************************************************************
** Form generated from reading UI file 'editattendrecord.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITATTENDRECORD_H
#define UI_EDITATTENDRECORD_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_EditAttendRecord
{
public:
    QTableView *tableView;
    QLabel *pWidlabel;
    QLabel *pDatelabel;
    QLabel *pStatuslabel;
    QPushButton *pushButton;
    QLineEdit *pIDlineEdit;
    QLineEdit *pDatelineEdit;
    QLineEdit *pStatuslineEdit;
    QLabel *pHelplabel;

    void setupUi(QDialog *EditAttendRecord)
    {
        if (EditAttendRecord->objectName().isEmpty())
            EditAttendRecord->setObjectName(QStringLiteral("EditAttendRecord"));
        EditAttendRecord->resize(700, 300);
        tableView = new QTableView(EditAttendRecord);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 15, 450, 260));
        pWidlabel = new QLabel(EditAttendRecord);
        pWidlabel->setObjectName(QStringLiteral("pWidlabel"));
        pWidlabel->setGeometry(QRect(490, 20, 60, 30));
        QFont font;
        font.setPointSize(10);
        font.setBold(false);
        font.setWeight(50);
        font.setStrikeOut(false);
        pWidlabel->setFont(font);
        pDatelabel = new QLabel(EditAttendRecord);
        pDatelabel->setObjectName(QStringLiteral("pDatelabel"));
        pDatelabel->setGeometry(QRect(490, 60, 60, 30));
        pDatelabel->setFont(font);
        pDatelabel->setFrameShape(QFrame::NoFrame);
        pStatuslabel = new QLabel(EditAttendRecord);
        pStatuslabel->setObjectName(QStringLiteral("pStatuslabel"));
        pStatuslabel->setGeometry(QRect(490, 100, 60, 30));
        pStatuslabel->setFont(font);
        pStatuslabel->setFrameShape(QFrame::NoFrame);
        pushButton = new QPushButton(EditAttendRecord);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(590, 240, 90, 30));
        pIDlineEdit = new QLineEdit(EditAttendRecord);
        pIDlineEdit->setObjectName(QStringLiteral("pIDlineEdit"));
        pIDlineEdit->setGeometry(QRect(560, 20, 120, 30));
        QFont font1;
        font1.setPointSize(10);
        pIDlineEdit->setFont(font1);
        pDatelineEdit = new QLineEdit(EditAttendRecord);
        pDatelineEdit->setObjectName(QStringLiteral("pDatelineEdit"));
        pDatelineEdit->setGeometry(QRect(560, 60, 120, 30));
        pDatelineEdit->setFont(font1);
        pStatuslineEdit = new QLineEdit(EditAttendRecord);
        pStatuslineEdit->setObjectName(QStringLiteral("pStatuslineEdit"));
        pStatuslineEdit->setGeometry(QRect(560, 100, 120, 30));
        pStatuslineEdit->setFont(font1);
        pHelplabel = new QLabel(EditAttendRecord);
        pHelplabel->setObjectName(QStringLiteral("pHelplabel"));
        pHelplabel->setGeometry(QRect(490, 140, 191, 101));
        pHelplabel->setFont(font1);

        retranslateUi(EditAttendRecord);

        QMetaObject::connectSlotsByName(EditAttendRecord);
    } // setupUi

    void retranslateUi(QDialog *EditAttendRecord)
    {
        EditAttendRecord->setWindowTitle(QApplication::translate("EditAttendRecord", "Dialog", Q_NULLPTR));
        pWidlabel->setText(QApplication::translate("EditAttendRecord", "\345\221\230\345\267\245\347\274\226\345\217\267\357\274\232", Q_NULLPTR));
        pDatelabel->setText(QApplication::translate("EditAttendRecord", "\350\200\203\345\213\244\346\227\245\346\234\237\357\274\232", Q_NULLPTR));
        pStatuslabel->setText(QApplication::translate("EditAttendRecord", "\344\277\256\346\224\271\347\212\266\346\200\201\357\274\232", Q_NULLPTR));
        pushButton->setText(QApplication::translate("EditAttendRecord", "\347\241\256\350\256\244\344\277\256\346\224\271", Q_NULLPTR));
        pHelplabel->setText(QApplication::translate("EditAttendRecord", "<html><head/><body><p><span style=\" font-weight:600; font-style:italic;\">\346\263\250\346\204\217\357\274\232\350\257\267\344\275\277\347\224\250\346\225\260\345\255\227\350\241\250\347\244\272\347\212\266\346\200\201</span></p><p><span style=\" font-weight:600; font-style:italic;\">1\350\241\250\347\244\272\346\255\243\345\270\270\357\274\2142\350\241\250\347\244\272\350\277\237\345\210\260\357\274\214</span></p><p><span style=\" font-weight:600; font-style:italic;\">3\350\241\250\347\244\272\347\274\272\345\213\244\357\274\2144\350\241\250\347\244\272\350\257\267\345\201\207\357\274\214</span></p><p><span style=\" font-weight:600; font-style:italic;\">5\350\241\250\347\244\272\346\227\251\351\200\200</span></p></body></html>", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class EditAttendRecord: public Ui_EditAttendRecord {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITATTENDRECORD_H
