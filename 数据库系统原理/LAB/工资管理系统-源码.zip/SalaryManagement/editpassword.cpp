#include "editpassword.h"
#include "ui_editpassword.h"

EditPassWord::EditPassWord(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::EditPassWord)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
    ui->plineEdit_1->setEchoMode(QLineEdit::Password);
    ui->plineEdit_2->setEchoMode(QLineEdit::Password);
}

EditPassWord::~EditPassWord()
{
    delete ui;
}

void EditPassWord::on_pConfirmButton_clicked()
{
    /*用户名密码不为空*/
    if(ui->plineEdit_1->text().length() < 6
            || ui->plineEdit_2->text().length() < 6){
        QMessageBox::critical(this,"警告","密码长度不得少于6个字符！");
        return;
    }

    QString pwd_1 = ui->plineEdit_1->text();
    QString pwd_2 = ui->plineEdit_2->text();

    if(pwd_1 != pwd_2){
        QMessageBox::critical(this,"警告","两次输入不相同！");
        return;
    }

    /* 修改密码 */
    QSqlQuery query;
    query.prepare("update dbuser "
                  " set pwd = " + pwd_1 +
                  " where w_id = " + w_id + ";");
    query.exec();
    QMessageBox::information(this,"确认","密码修改成功！");
    this->hide();
    return;
}
