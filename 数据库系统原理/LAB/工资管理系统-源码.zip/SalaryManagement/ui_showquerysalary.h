/********************************************************************************
** Form generated from reading UI file 'showquerysalary.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWQUERYSALARY_H
#define UI_SHOWQUERYSALARY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_ShowQuerySalary
{
public:
    QTableView *tableView;
    QLabel *pWorkerNumlabel;
    QLineEdit *pNumlineEdit;
    QPushButton *pWorkerNum;
    QPushButton *pQuery;
    QPushButton *pPushOut;

    void setupUi(QDialog *ShowQuerySalary)
    {
        if (ShowQuerySalary->objectName().isEmpty())
            ShowQuerySalary->setObjectName(QStringLiteral("ShowQuerySalary"));
        ShowQuerySalary->resize(700, 300);
        tableView = new QTableView(ShowQuerySalary);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 15, 640, 230));
        pWorkerNumlabel = new QLabel(ShowQuerySalary);
        pWorkerNumlabel->setObjectName(QStringLiteral("pWorkerNumlabel"));
        pWorkerNumlabel->setGeometry(QRect(40, 256, 100, 30));
        QFont font;
        font.setPointSize(10);
        pWorkerNumlabel->setFont(font);
        pNumlineEdit = new QLineEdit(ShowQuerySalary);
        pNumlineEdit->setObjectName(QStringLiteral("pNumlineEdit"));
        pNumlineEdit->setGeometry(QRect(150, 256, 100, 30));
        pWorkerNum = new QPushButton(ShowQuerySalary);
        pWorkerNum->setObjectName(QStringLiteral("pWorkerNum"));
        pWorkerNum->setGeometry(QRect(350, 256, 90, 30));
        pWorkerNum->setFont(font);
        pQuery = new QPushButton(ShowQuerySalary);
        pQuery->setObjectName(QStringLiteral("pQuery"));
        pQuery->setGeometry(QRect(460, 256, 90, 30));
        pQuery->setFont(font);
        pPushOut = new QPushButton(ShowQuerySalary);
        pPushOut->setObjectName(QStringLiteral("pPushOut"));
        pPushOut->setGeometry(QRect(570, 256, 90, 30));
        pPushOut->setFont(font);

        retranslateUi(ShowQuerySalary);

        QMetaObject::connectSlotsByName(ShowQuerySalary);
    } // setupUi

    void retranslateUi(QDialog *ShowQuerySalary)
    {
        ShowQuerySalary->setWindowTitle(QApplication::translate("ShowQuerySalary", "Dialog", Q_NULLPTR));
        pWorkerNumlabel->setText(QApplication::translate("ShowQuerySalary", "\350\257\267\350\276\223\345\205\245\345\221\230\345\267\245\347\274\226\345\217\267\357\274\232", Q_NULLPTR));
        pWorkerNum->setText(QApplication::translate("ShowQuerySalary", "\346\230\276\347\244\272\345\221\230\345\267\245\344\277\241\346\201\257", Q_NULLPTR));
        pQuery->setText(QApplication::translate("ShowQuerySalary", "\346\237\245\350\257\242", Q_NULLPTR));
        pPushOut->setText(QApplication::translate("ShowQuerySalary", "\345\257\274\345\207\272", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ShowQuerySalary: public Ui_ShowQuerySalary {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWQUERYSALARY_H
