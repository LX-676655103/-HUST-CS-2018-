#ifndef SHOWWORKERINFO_H
#define SHOWWORKERINFO_H

#include <QDialog>
#include <QString>

namespace Ui {
class ShowWorkerInfo;
}

class ShowWorkerInfo : public QDialog
{
    Q_OBJECT

public:
    explicit ShowWorkerInfo(QWidget *parent, QString id);
    ~ShowWorkerInfo();

private:
    QString w_id;
    Ui::ShowWorkerInfo *ui;
};

#endif // SHOWWORKERINFO_H
