#include "showmonthsalary.h"
#include "ui_showmonthsalary.h"

#include <QSqlQuery>
#include <QModelIndex>
#include <QDebug>
#include <QString>
#include <QMessageBox>

ShowMonthSalary::ShowMonthSalary(QWidget *parent, QString id):
    QDialog(parent), w_id(id),
    ui(new Ui::ShowMonthSalary)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);

    /* 将数据模型与QTableView绑定 */
    model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    //ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    model->setQuery("select w_id as '员工编号', w_name as '姓名',"
                    "s_year as '年', s_month as '月',"
                    "base_pay as '基本工资',"
                    "merit_pay  as '扣款',"
                    "extra_pay as '加班津贴',"
                    "base_pay + merit_pay + extra_pay as '总月收入' "
                    "from month_salary "
                    "where w_id = " + id +
                    " order by s_year, s_month");
    ui->tableView->setModel(model);
}

ShowMonthSalary::~ShowMonthSalary()
{
    delete ui;
}

void ShowMonthSalary::on_pFresh_clicked()
{
    model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    model->setQuery("select w_id as '员工编号', w_name as '姓名',"
                    "s_year as '年', s_month as '月',"
                    "base_pay as '基本工资',"
                    "merit_pay  as '扣款',"
                    "extra_pay as '加班津贴',"
                    "base_pay + merit_pay + extra_pay as '总月收入' "
                    "from month_salary "
                    "where w_id = " + w_id +
                    " order by s_year, s_month");
    ui->tableView->setModel(model);
}
