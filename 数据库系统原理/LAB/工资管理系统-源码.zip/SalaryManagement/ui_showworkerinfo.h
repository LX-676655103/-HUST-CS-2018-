/********************************************************************************
** Form generated from reading UI file 'showworkerinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOWWORKERINFO_H
#define UI_SHOWWORKERINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_ShowWorkerInfo
{
public:
    QLabel *pNum;
    QLabel *pName;
    QLabel *pSex;
    QLabel *pPhone;
    QLabel *pDepartment;
    QLabel *pWorkerType;

    void setupUi(QDialog *ShowWorkerInfo)
    {
        if (ShowWorkerInfo->objectName().isEmpty())
            ShowWorkerInfo->setObjectName(QStringLiteral("ShowWorkerInfo"));
        ShowWorkerInfo->resize(398, 247);
        pNum = new QLabel(ShowWorkerInfo);
        pNum->setObjectName(QStringLiteral("pNum"));
        pNum->setGeometry(QRect(60, 30, 120, 30));
        QFont font;
        font.setPointSize(11);
        pNum->setFont(font);
        pName = new QLabel(ShowWorkerInfo);
        pName->setObjectName(QStringLiteral("pName"));
        pName->setGeometry(QRect(60, 70, 120, 30));
        pName->setFont(font);
        pSex = new QLabel(ShowWorkerInfo);
        pSex->setObjectName(QStringLiteral("pSex"));
        pSex->setGeometry(QRect(210, 70, 71, 30));
        pSex->setFont(font);
        pPhone = new QLabel(ShowWorkerInfo);
        pPhone->setObjectName(QStringLiteral("pPhone"));
        pPhone->setGeometry(QRect(60, 110, 221, 30));
        pPhone->setFont(font);
        pDepartment = new QLabel(ShowWorkerInfo);
        pDepartment->setObjectName(QStringLiteral("pDepartment"));
        pDepartment->setGeometry(QRect(60, 150, 221, 30));
        pDepartment->setFont(font);
        pWorkerType = new QLabel(ShowWorkerInfo);
        pWorkerType->setObjectName(QStringLiteral("pWorkerType"));
        pWorkerType->setGeometry(QRect(60, 190, 221, 30));
        pWorkerType->setFont(font);

        retranslateUi(ShowWorkerInfo);

        QMetaObject::connectSlotsByName(ShowWorkerInfo);
    } // setupUi

    void retranslateUi(QDialog *ShowWorkerInfo)
    {
        ShowWorkerInfo->setWindowTitle(QApplication::translate("ShowWorkerInfo", "Dialog", Q_NULLPTR));
        pNum->setText(QApplication::translate("ShowWorkerInfo", "\345\267\245\345\217\267\357\274\232", Q_NULLPTR));
        pName->setText(QApplication::translate("ShowWorkerInfo", "\345\247\223\345\220\215\357\274\232", Q_NULLPTR));
        pSex->setText(QApplication::translate("ShowWorkerInfo", "\346\200\247\345\210\253\357\274\232", Q_NULLPTR));
        pPhone->setText(QApplication::translate("ShowWorkerInfo", "\347\224\265\350\257\235\345\217\267\347\240\201\357\274\232", Q_NULLPTR));
        pDepartment->setText(QApplication::translate("ShowWorkerInfo", "\351\203\250\351\227\250\357\274\232", Q_NULLPTR));
        pWorkerType->setText(QApplication::translate("ShowWorkerInfo", "\345\267\245\347\247\215\357\274\232", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ShowWorkerInfo: public Ui_ShowWorkerInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOWWORKERINFO_H
