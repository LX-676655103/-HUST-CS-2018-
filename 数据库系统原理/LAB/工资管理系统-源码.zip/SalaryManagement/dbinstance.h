#ifndef DBINSTANCE_H
#define DBINSTANCE_H
#include <QSqlDatabase>

class DBInstance
{
public:
    static DBInstance *getInstance();
    DBInstance();
    bool openDatabase();
    bool closeDatabase();
private:
    static DBInstance *dbinstance;
    QSqlDatabase db;
};

#endif
