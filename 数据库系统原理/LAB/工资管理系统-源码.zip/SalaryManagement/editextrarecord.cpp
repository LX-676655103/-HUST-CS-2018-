#include "editextrarecord.h"
#include "ui_editextrarecord.h"

EditExtraRecord::EditExtraRecord(QWidget *parent, QString d_id, bool is_depart, QString w_id) :
    QDialog(parent), d_id(d_id), is_depart(is_depart), w_id(w_id),
    ui(new Ui::EditExtraRecord)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
    this->showExteaRecord();
}

EditExtraRecord::~EditExtraRecord()
{
    delete ui;
}

void EditExtraRecord::showExteaRecord()
{
    QSqlQueryModel *model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    QString str = "select workerInfo.w_id as '员工编号', w_name as '姓名',"
                  "e_date as '加班日期', "
                  "duration as '加班时长',"
                  "type as '倍数',"
                  "(case e_status"
                  "   when 0 then '未修改' "
                  "   when 1 then '修改'"
                  "end)  as '是否修改',"
                  "payment as '加班津贴', "
                  "begin_time as '开始时间',"
                  "end_time  as '结束时间' "
                  "from extraWork, workerInfo "
                  "where workerInfo.w_id = extraWork.w_id ";
    if(is_depart) str = str + " and workerInfo.d_id = " + d_id ;
    str = str + " order by workerInfo.w_id, e_date;";
    model->setQuery(str);
    ui->tableView->setModel(model);
}

void EditExtraRecord::on_pushButton_clicked()
{
    if(ui->pIDlineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请先输入员工编号！");
        return;
    }
    if(ui->pDatelineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请先输入加班日期！");
        return;
    }
    QString id = ui->pIDlineEdit->text();
    QString date = ui->pDatelineEdit->text();

    /* 类型和时长不得同时为空 */
    if(ui->pDuralineEdit->text().isEmpty()
            && ui->pTypelineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","类型和时长不得同时为空！");
        return;
    }

    int new_type, new_duration;

    /* 读取更新的数据 */
    if(ui->pDuralineEdit->text().isEmpty())  new_duration = -1;
    else new_duration = ui->pDuralineEdit->text().toInt();

    if(ui->pTypelineEdit->text().isEmpty())  new_type = -1;
    else new_type = ui->pTypelineEdit->text().toInt();

    /* 检验该记录是否存在 */
    QSqlQuery query;
    query.prepare("select * from extraWork where w_id = " + id +
                  "     and e_date = '" + date + "';");
    query.exec();
    if(!query.first()){
        QMessageBox::critical(this,"警告","该加班记录不存在！");
        return;
    }

    /* 检查更新状态是否与原先相同 */
    query.first();
    int old_type = query.value("type").toInt();
    int old_duration = query.value("duration").toInt();

    if(old_duration == new_duration && old_type == new_type){
        QMessageBox::critical(this,"警告","更新状态与原状态相同，修改失败！");
        return;
    }

     /* 修改加班状态 & 向加班记录修改记录表插入项 */      
    QSqlQuery transaction_start;
    QSqlQuery transaction_commit, transaction_rollback;
    QSqlQuery query_insert, query_update;

    transaction_start.exec("start transaction");

    query_update.prepare("update extraWork set duration=:d, type=:t, e_status=1 "
                         "where w_id=:w and e_date=:e ;");
    if(new_duration == -1)
        query_update.bindValue(":d",old_duration);
    else query_update.bindValue(":d",new_duration);

    if(new_type == -1)
        query_update.bindValue(":t",old_type);
    else query_update.bindValue(":t",new_type);

    query_update.bindValue(":w",id);
    query_update.bindValue(":e",date);
    bool ok1 = query_update.exec();

    query_insert.prepare("insert into extraWork_editRecord values "
                         "(:w_id, getdate(), :old_duration, :old_type, "
                         " :new_duration, :new_type, :id, :date);");
    query_insert.bindValue(":w_id",w_id);
    query_insert.bindValue(":old_duration",old_duration);
    query_insert.bindValue(":old_type",old_type);
    query_insert.bindValue(":new_duration",new_duration);
    query_insert.bindValue(":new_type",new_type);
    query_insert.bindValue(":id",id);
    query_insert.bindValue(":date",date);
    bool ok2 = query_insert.exec();

    if(ok1 && ok2)
        transaction_commit.exec("commit");
    else transaction_rollback.exec("rollback");
    this->showExteaRecord();
}
