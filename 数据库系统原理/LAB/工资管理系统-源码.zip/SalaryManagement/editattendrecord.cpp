#include "editattendrecord.h"
#include "ui_editattendrecord.h"
#include <QDebug>

EditAttendRecord::EditAttendRecord(QWidget *parent, QString d_id, bool is_depart, QString w_id) :
    QDialog(parent), d_id(d_id), is_depart(is_depart), w_id(w_id),
    ui(new Ui::EditAttendRecord)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
    this->showAtttendRecord();
}
void EditAttendRecord::showAtttendRecord()
{
    QSqlQueryModel *model = new QSqlQueryModel(ui->tableView);
    ui->tableView->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);

    QString str = "select workerInfo.w_id as '员工编号', w_name as '姓名',"
                  "a_date as '考勤日期', "
                  "(case a_status "
                  "   when 1 then '正常' "
                  "   when 2 then '迟到' "
                  "   when 3 then '缺勤' "
                  "   when 4 then '请假' "
                  "   when 5 then '早退'"
                  "end) as '考勤状态',"
                  "(case e_status"
                  "   when 0 then '未修改' "
                  "   when 1 then '修改'"
                  "end)  as '是否修改',"
                  "payment as '扣款', "
                  "begin_time as '签入时间',"
                  "end_time  as '签退时间' "
                  "from attendance, workerInfo "
                  "where workerInfo.w_id = attendance.w_id ";
    if(is_depart) str = str + " and workerInfo.d_id = " + d_id ;
    str = str + " order by workerInfo.w_id, a_date;";
    model->setQuery(str);
    ui->tableView->setModel(model);
}

EditAttendRecord::~EditAttendRecord()
{
    delete ui;
}

void EditAttendRecord::on_pushButton_clicked()
{
    if(ui->pIDlineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请先输入员工编号！");
        return;
    }
    if(ui->pDatelineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请先输入考勤记录日期！");
        return;
    }
    if(ui->pStatuslineEdit->text().isEmpty()){
        QMessageBox::critical(this,"警告","请先输入更新状态！");
        return;
    }
    QString id = ui->pIDlineEdit->text();
    QString date = ui->pDatelineEdit->text();
    QString new_status = ui->pStatuslineEdit->text();

    /* 检验该记录是否存在 */

    QSqlQuery query;
    query.prepare("select * from attendance where w_id = " + id +
                  "     and a_date = '" + date + "';");
    query.exec();
    if(!query.first()){
        QMessageBox::critical(this,"警告","该考勤记录不存在！");
        return;
    }

    /* 检查更新状态是否与原先相同 */
    query.first();
    QString old_status = query.value("a_status").toString();
    if(old_status == new_status){
        QMessageBox::critical(this,"警告","更新状态与原状态相同，修改失败！");
        return;
    }

    /* 检查更新状态是否合法 */
    if(new_status<='0' || new_status>'5'){
        QMessageBox::critical(this,"警告","更新状态非法，修改失败！");
        return;
    }

    /* 修改考勤状态 & 向考勤记录修改记录表插入项*/
    QSqlQuery transaction_start;
    QSqlQuery transaction_commit, transaction_rollback;
    QSqlQuery query_insert, query_update;

    transaction_start.exec("start transaction");
    bool ok1 = query_update.exec("update attendance set a_status=" + new_status + 
                                 ", e_status = 1 "
                                 "where w_id = " + id + 
                                 " and a_date = '" + date + "';");
    bool ok2 = query_insert.exec("insert into attendance_editRecord values "
                                 "(" + w_id +", getdate(), " + old_status +
                                 ", " + new_status + ", " + id + ", '" + date +"');");
    if(ok1 && ok2)
         transaction_commit.exec("commit");
    else transaction_rollback.exec("rollback");
    showAtttendRecord();

}
