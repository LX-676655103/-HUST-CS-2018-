#ifndef SHOWEXTRARECORD_H
#define SHOWEXTRARECORD_H

#include <QDialog>
#include <QStandardItemModel>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QSqlError>
#include <QHeaderView>
#include <QDateTime>
#include <QString>
namespace Ui {
class ShowExtraRecord;
}

class ShowExtraRecord : public QDialog
{
    Q_OBJECT

public:
    explicit ShowExtraRecord(QWidget *parent, QString id);
    ~ShowExtraRecord();

private:
    QString w_id;
    QSqlQueryModel *model;
    Ui::ShowExtraRecord *ui;
};

#endif // SHOWEXTRARECORD_H
