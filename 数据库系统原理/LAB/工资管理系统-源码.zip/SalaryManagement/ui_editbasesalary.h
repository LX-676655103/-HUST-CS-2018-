/********************************************************************************
** Form generated from reading UI file 'editbasesalary.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITBASESALARY_H
#define UI_EDITBASESALARY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_EditBaseSalary
{
public:
    QLabel *pSalarylabel;
    QPushButton *pushButton;
    QLabel *pHelplabel;
    QLineEdit *pIDlineEdit;
    QLabel *pIDlabel;
    QLineEdit *pSalarylineEdit;
    QTableView *tableView;

    void setupUi(QDialog *EditBaseSalary)
    {
        if (EditBaseSalary->objectName().isEmpty())
            EditBaseSalary->setObjectName(QStringLiteral("EditBaseSalary"));
        EditBaseSalary->resize(694, 300);
        pSalarylabel = new QLabel(EditBaseSalary);
        pSalarylabel->setObjectName(QStringLiteral("pSalarylabel"));
        pSalarylabel->setGeometry(QRect(480, 65, 60, 30));
        QFont font;
        font.setPointSize(10);
        font.setBold(false);
        font.setWeight(50);
        font.setStrikeOut(false);
        pSalarylabel->setFont(font);
        pSalarylabel->setFrameShape(QFrame::NoFrame);
        pushButton = new QPushButton(EditBaseSalary);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(580, 235, 90, 30));
        pHelplabel = new QLabel(EditBaseSalary);
        pHelplabel->setObjectName(QStringLiteral("pHelplabel"));
        pHelplabel->setGeometry(QRect(480, 120, 191, 51));
        QFont font1;
        font1.setPointSize(10);
        pHelplabel->setFont(font1);
        pIDlineEdit = new QLineEdit(EditBaseSalary);
        pIDlineEdit->setObjectName(QStringLiteral("pIDlineEdit"));
        pIDlineEdit->setGeometry(QRect(550, 15, 120, 30));
        pIDlineEdit->setFont(font1);
        pIDlabel = new QLabel(EditBaseSalary);
        pIDlabel->setObjectName(QStringLiteral("pIDlabel"));
        pIDlabel->setGeometry(QRect(480, 15, 60, 30));
        pIDlabel->setFont(font);
        pSalarylineEdit = new QLineEdit(EditBaseSalary);
        pSalarylineEdit->setObjectName(QStringLiteral("pSalarylineEdit"));
        pSalarylineEdit->setGeometry(QRect(550, 65, 120, 30));
        pSalarylineEdit->setFont(font1);
        tableView = new QTableView(EditBaseSalary);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(20, 10, 450, 260));

        retranslateUi(EditBaseSalary);

        QMetaObject::connectSlotsByName(EditBaseSalary);
    } // setupUi

    void retranslateUi(QDialog *EditBaseSalary)
    {
        EditBaseSalary->setWindowTitle(QApplication::translate("EditBaseSalary", "Dialog", Q_NULLPTR));
        pSalarylabel->setText(QApplication::translate("EditBaseSalary", "\345\237\272\346\234\254\345\267\245\350\265\204\357\274\232", Q_NULLPTR));
        pushButton->setText(QApplication::translate("EditBaseSalary", "\347\241\256\350\256\244\344\277\256\346\224\271", Q_NULLPTR));
        pHelplabel->setText(QApplication::translate("EditBaseSalary", "<html><head/><body><p><span style=\" font-weight:600; font-style:italic;\">\346\263\250\346\204\217\357\274\232\345\237\272\346\234\254\345\267\245\350\265\204\344\277\256\346\224\271\345\220\216</span></p><p><span style=\" font-weight:600; font-style:italic;\">\344\270\213\346\234\210\347\224\237\346\225\210\357\274\214\346\234\254\346\234\210\344\270\215\347\224\237\346\225\210</span></p></body></html>", Q_NULLPTR));
        pIDlabel->setText(QApplication::translate("EditBaseSalary", "\345\267\245\347\247\215\347\274\226\345\217\267\357\274\232", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class EditBaseSalary: public Ui_EditBaseSalary {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITBASESALARY_H
