#include "showworkerinfo.h"
#include "ui_showworkerinfo.h"
#include "dbinstance.h"

#include <QDebug>
#include <QString>
#include <QSqlError>
#include <QSqlQuery>
#include <QApplication>
#include <QMessageBox>


ShowWorkerInfo::ShowWorkerInfo(QWidget *parent, QString id) :
    QDialog(parent), w_id(id),
    ui(new Ui::ShowWorkerInfo)
{
    ui->setupUi(this);
    this->setWindowTitle("工资管理系统");
    QIcon icon(":/image/icon.png");
    this->setWindowIcon(icon);
    /* 显示个人信息 */
    QSqlQuery query;
    bool ret = query.exec("select * from workerInfo, department, workerType"
                          " where workerInfo.w_id = " + w_id +
                          " and workerInfo.d_id = department.d_id"
                          " and workerInfo.t_id = workerType.t_id;");
    if(ret)
    {
        query.first();
        qDebug() << "select from workerInfo success";
        ui->pNum->setText("工号： " + query.value("w_id").toString());
        ui->pName->setText("姓名： " + query.value("w_name").toString());
        ui->pSex->setText("性别： " + query.value("w_sex").toString());
        ui->pPhone->setText("电话号码： " + query.value("w_telephone").toString());
        ui->pDepartment->setText("部门： " + query.value("d_name").toString());
        ui->pWorkerType->setText("工种： " + query.value("t_name").toString());
    }
    else
    {
        qDebug() << query.lastError().text();
        QMessageBox::critical(this,"错误","员工信息查询失败");
    }

}

ShowWorkerInfo::~ShowWorkerInfo()
{
    delete ui;
}
