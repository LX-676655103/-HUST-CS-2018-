#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
/*--------------------------------------------------*/
#define N 100000
#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
/*--------------------------------------------------*/
typedef int status;
typedef struct Literal{
    int liter;
    Literal* next;
}Literal;
typedef struct Clause{
    Literal* first;
    Clause* next;
}Clause;
typedef struct{
    int liter;
    double sum;
    int num_of_positive;
    int num_of_negative;
}Sum_of_Liter;
Sum_of_Liter a[N];
int liter[N];
int Mark;
int count_of_success;
/*-------------------CNF����ģ��--------------------*/
status ReadFile(Clause* root,int &num_of_liter,int &num_of_clause,char filename[]);
Clause* createClause(int n,int lit[]);
status destroyClause(Clause* p);
status addClause(Clause* root,Clause* pNew);
status isUnitClause(Clause* p);
status printClause(Clause* root);
Clause* copyList(Clause* root);
status destroyList(Clause* root);
status addliter(Clause* p,int lit);
/*-------------------����DPLLģ��--------------------*/
int find_lit(int num_of_liter);
status law_of_UnitClause(Clause* root,Clause* p_of_unitCla,int &num_of_clause);
status preSolve(Clause* root,int num_of_liter,int &num_of_clause);
status Literalsum(Clause *root,int num_of_liter);
Sum_of_Liter Literalmax(int num_of_liter);
status Recovery_lit(Clause* p);
status DPLL(Clause* root,int lit,int num_of_liter,int num_of_clause);
/*------------------����������ģ��-------------------*/
int trans_of_comliter(int i,int j,int n,int flag);
int trans_of_extraliter(int a,int b,int c,int d,int e,int n);
status firstlaw(Clause* root,int &num_of_clause,int n,int flag);
status secondlaw_of_DEP(Clause* root,int &num_of_clause,int layer,int i,int j,int n,int flag1,int flag2);
status secondlaw(Clause* root,int &num_of_clause,int n);
status thirdlaw(Clause* root,int &num_of_clause,int n);
status ReadPuzzle_File(int *puzzle,int n);
status ReadPuzzle_Buffer(int *puzzle,int n);
status transPuzzle_to_CNF(Clause* root,int &num_of_clause,int n,int *a);
status SaveCNFFile(Clause* root,int *puzzle,int n,int num_of_liter,int num_of_clause);
status puzzleslover(Clause* root,int n,int num_of_clause);
status puzzles(int n,int *a);
status generate_of_puzzle(int n,int *c);
status printpuzzle(int *puzzle,int n);
/*-------------------CNF����ģ��---------------------*/
status ReadFile(Clause* root,int &num_of_liter,int &num_of_clause,char filename[])
{
    int i,n,num;
    FILE* fp;
    char str[1024],c;
    printf("      ������CNF�ļ����ļ�·��/�ļ�����");
    scanf("%s",filename);
    if(!(fp=fopen(filename,"r"))) return ERROR;
    printf("      CNF�ļ���ע���������£�\n");
    while(fscanf(fp,"%c",&c)!=EOF)
    {
        if(c=='c')
        {
            printf("      %c",c);
            while(fscanf(fp,"%c",&c)!=EOF&&c!='\n')
                printf("%c",c);
            printf("\n");
        }
        else
        {
            fscanf(fp,"%s",str);
            fscanf(fp,"%d %d",&num_of_liter,&num_of_clause);
            printf("\n      CNF�ļ��е�������Ϊ��%-8d ��ʽ��Ϊ��%-8d\n",num_of_liter,num_of_clause);
            break;
        }
    }
    for(i=0;i<num_of_clause;i++)
    {
        n=0;
        while(fscanf(fp,"%d",&num)!=EOF&&num!=0)
            liter[n++]=num;
        addClause(root,createClause(n,liter));
    }
    for(i=0;i<=num_of_liter;i++) liter[i]=0;
    fclose(fp);
    return OK;
}
Clause* createClause(int n,int lit[])
{
    int i;
    Clause* head;
    Literal* pNew;
    head=(Clause*)malloc(sizeof(Clause));
    head->first=(Literal*)malloc(sizeof(Literal));
    head->first->next=NULL;
    head->next=NULL;
    for(i=0;i<n;i++)
    {
        pNew=(Literal*)malloc(sizeof(Literal));
        pNew->liter=lit[i];
        pNew->next=head->first->next;
        head->first->next=pNew;
    }
    return head;
}
status destroyClause(Clause* p)
{
    Literal *pl1,*pl2;
    pl1=p->first;
    while(pl1)
    {
        pl2=pl1->next;
        free(pl1);
        pl1=pl2;
    }
    free(p);
    return OK;
}
status addClause(Clause* root,Clause* pNew)
{
    pNew->next=root->next;
    root->next=pNew;
    return OK;
}
status isUnitClause(Clause* p)
{
    if(!p->first->next) return FALSE;
    if(!p->first->next->next) return TRUE;
    return FALSE;
}
status printClause(Clause* root)
{
    Clause* p=root->next;
    Literal* q;
    while(p)
    {
        q=p->first->next;
        while(q)
        {
            printf("%d ",q->liter);
            q=q->next;
        }
        printf("0\n");
        p=p->next;
    }
    return OK;
}
Clause* copyList(Clause* root)
{
    Clause *pC=root->next;
    Clause *rNew=(Clause*)malloc(sizeof(Clause)),*pNew;
    Literal *pL,*pLNew;
    rNew->first=NULL;
    rNew->next=NULL;
    while(pC)
    {
        pNew=(Clause*)malloc(sizeof(Clause));
        pNew->first=(Literal*)malloc(sizeof(Literal));
        pNew->first->next=NULL;
        pNew->next=rNew->next;
        rNew->next=pNew;
        pL=pC->first->next;
        while(pL)
        {
            pLNew=(Literal*)malloc(sizeof(Literal));
            pLNew->liter=pL->liter;
            pLNew->next=pNew->first->next;
            pNew->first->next=pLNew;
            pL=pL->next;
        }
        pC=pC->next;
    }
    return rNew;
}
status destroyList(Clause* root)
{
    Clause *p_pre=root,*p_cur=root->next;
    while(p_cur)
    {
        p_pre->next=p_cur->next;
        destroyClause(p_cur);
        p_cur=p_pre->next;
    }
    free(p_pre);
    return OK;
}
status addliter(Clause* p,int lit)
{
    Literal *pNew;
    pNew=(Literal*)malloc(sizeof(Literal));
    pNew->liter=lit;
    pNew->next=p->first;
    p->first=pNew;
    return OK;
}
status SaveFile(int time,char filename[],int flag,int num_of_liter)
{
    FILE *fp;
    int i=0;
    while(filename[i]!='\0') i++;
    filename[i-3]='r',filename[i-2]='e',filename[i-1]='s';
    if(!(fp=fopen(filename,"w"))) return ERROR;
    fprintf(fp,"s %d\nv ",flag);
    for(int i=1;i<=num_of_liter;i++)
        if(liter[i]==0) fprintf(fp,"%d ",i);
        else fprintf(fp,"%d ",liter[i]);
    fprintf(fp,"\nt %d\n",time);
    fclose(fp);
    return OK;
}
/*--------------------����DPLLģ��---------------------*/
int find_lit(int num_of_liter)
{
    int i;
    for(i=1;i<=num_of_liter;i++)
        if(!liter[i]) return i;
    return 0;
}
status law_of_UnitClause(Clause* root,Clause* p_of_unitCla,int &num_of_clause)
{
    int liter;
    Clause *p_of_curCla,*p_of_preCla;
    Literal *p_of_curLiter,*p_of_preLiter;
    p_of_preCla=root;
    p_of_curCla=root->next;
    liter=p_of_unitCla->first->next->liter;
    while(p_of_curCla)
    {
        p_of_preLiter=p_of_curCla->first;
        p_of_curLiter=p_of_preLiter->next;
        while(p_of_curLiter)
        {
            if(p_of_curLiter->liter==liter)
            {
                p_of_preCla->next=p_of_curCla->next;
                destroyClause(p_of_curCla);
                p_of_curCla=p_of_preCla;
                num_of_clause--;
                break;
            }
            else if(p_of_curLiter->liter+liter==0)
            {
                if(!p_of_curLiter->next&&p_of_preLiter==p_of_curCla->first) return ERROR;
                p_of_preLiter->next=p_of_curLiter->next;
                free(p_of_curLiter);
                p_of_curLiter=p_of_preLiter->next;
            }
            else
            {
                p_of_preLiter=p_of_curLiter;
                p_of_curLiter=p_of_curLiter->next;
            }
        }
        p_of_preCla=p_of_curCla;
        p_of_curCla=p_of_curCla->next;
    }
    return OK;
}
status preSolve(Clause* root,int num_of_liter,int &num_of_clause)
{
    int literal,i;
    Clause* p=root->next;
    for(i=0;i<=num_of_liter;i++) liter[i]=0;
    while(p)
        if(!p->first->next) return ERROR;
        else p=p->next;
    p=root->next;
    while(p)
    {
        if(isUnitClause(p))
        {
            liter[abs(p->first->next->liter)]=p->first->next->liter;
            if(law_of_UnitClause(root,p,num_of_clause)) p=root->next;
            else return FALSE;
        }
        else p=p->next;
    }
    return OK;
}
status Literalsum(Clause *root,int num_of_liter)
{
    int i;
    Clause *p=root->next;
    Literal *q;
    for(i=0;i<num_of_liter;i++)
        a[i].liter=i+1,a[i].sum=0.0,a[i].num_of_positive=0,a[i].num_of_negative=0;
    while(p)
    {
        i=0;
        q=p->first->next;
        while(q){i++;q=q->next;}
        q=p->first->next;
        while(q)
        {
            a[abs(q->liter)-1].sum+=pow(0.5,i);
            if(q->liter>0) a[abs(q->liter)-1].num_of_positive++;
            else a[abs(q->liter)-1].num_of_negative++;
            q=q->next;
        }
        p=p->next;
    }
    return OK;
}
Sum_of_Liter Literalmax(int num_of_liter)
{
    int i;
    Sum_of_Liter temp=a[0];
    for(i=1;i<num_of_liter;i++)
        if(temp.sum<a[i].sum)
            temp=a[i];
    return temp;
}
status Recovery_lit(Clause* p)
{
    Literal *pNew;
    pNew=p->first;
    while(pNew)
    {
        liter[abs(pNew->liter)]=0;
        pNew=pNew->next;
    }
    destroyClause(p);
    return OK;
}
status DPLL(Clause* root,int lit,int num_of_liter,int num_of_clause)
{
    int flag;
    Sum_of_Liter temp;
    Clause *p_of_UnitLiter,*p,*rNew;
    p_of_UnitLiter=(Clause*)malloc(sizeof(Clause));
    p_of_UnitLiter->first=NULL;
    rNew=copyList(root);
    liter[0]=lit;
    addClause(rNew,createClause(1,liter));
    num_of_clause++;
    p=rNew->next;
    while(p)
    if(isUnitClause(p))
    {
        if(law_of_UnitClause(rNew,p,num_of_clause))
        {
            lit=p->first->next->liter;
            addliter(p_of_UnitLiter,lit);
            liter[abs(lit)]=lit;
            p=rNew->next;
        }
        else{destroyList(rNew); Recovery_lit(p_of_UnitLiter); return FALSE;}
    }
    else p=p->next;
    if(Mark)
    {
         Literalsum(rNew,num_of_liter);
         temp=Literalmax(num_of_liter);
         lit=temp.liter;
         if(temp.num_of_positive>=temp.num_of_negative) flag=1;
         else flag=-1;
    }
    else {lit=find_lit(num_of_liter);flag=-1;}
    if(!rNew->next||DPLL(rNew,lit*flag,num_of_liter,num_of_clause)||DPLL(rNew,-lit*flag,num_of_liter,num_of_clause))
    {
        destroyList(rNew);
        return TRUE;
    }
    else{ destroyList(rNew); Recovery_lit(p_of_UnitLiter);  return FALSE; }
}
status DPLL_pp(Clause* root,int lit,int num_of_liter,int num_of_clause)
{
    int flag;
    Sum_of_Liter temp;
    Clause *p_of_UnitLiter,*p,*rNew;
    p_of_UnitLiter=(Clause*)malloc(sizeof(Clause));
    p_of_UnitLiter->first=NULL;
    rNew=copyList(root);
    liter[0]=lit;
    addClause(rNew,createClause(1,liter));
    num_of_clause++;
    p=rNew->next;
    while(p)
    if(isUnitClause(p))
    {
        if(law_of_UnitClause(rNew,p,num_of_clause))
        {
            lit=p->first->next->liter;
            addliter(p_of_UnitLiter,lit);
            liter[abs(lit)]=lit;
            p=rNew->next;
        }
        else{destroyList(rNew); Recovery_lit(p_of_UnitLiter); return FALSE;}
    }
    else p=p->next;
    if(Mark)
    {
         Literalsum(rNew,num_of_liter);
         temp=Literalmax(num_of_liter);
         lit=temp.liter;
         if(temp.num_of_positive>=temp.num_of_negative) flag=1;
         else flag=-1;
    }
    else {lit=find_lit(num_of_liter);flag=-1;}
    if(!rNew->next){ count_of_success++; Recovery_lit(p_of_UnitLiter); return TRUE; }
    DPLL(rNew,lit*flag,num_of_liter,num_of_clause);
    DPLL(rNew,-lit*flag,num_of_liter,num_of_clause);
    destroyList(rNew);
    Recovery_lit(p_of_UnitLiter);
    return TRUE;
}
/*-------------------����������ģ��--------------------*/
int trans_of_comliter(int i,int j,int n,int flag) //flag==0��ʾ�������ȣ�flag==1��ʾ��������
{
    if(flag==0) return (i-1)*n+j;
    else return (j-1)*n+i;
}
int trans_of_extraliter(int a,int b,int c,int d,int e,int n)
{
    return n*n+(a-1)*n*(n-1)*n*3/2+((c-1)*(c-2)/2+b-1)*3*n+3*d+e-2;
}
status firstlaw(Clause* root,int &num_of_clause,int n,int flag)
{
    int i,j,k;
    for(i=1;i<=n;i++)
        for(j=1;j<=n-2;j++)
        {
            for(k=0;k<=2;k++)
                liter[k]=trans_of_comliter(i,j+k,n,flag);
            addClause(root,createClause(3,liter));
            for(k=0;k<=2;k++)
                liter[k]=-trans_of_comliter(i,j+k,n,flag);
            addClause(root,createClause(3,liter));
            num_of_clause+=2;
        }
    return OK;
}
status secondlaw_of_DEP(Clause* root,int &num_of_clause,int layer,int i,int j,int n,int flag1,int flag2)
{
    int k;
    if(layer-1==n/2+1)
    {
        addClause(root,createClause(layer-1,liter));
        num_of_clause++;
        return OK;
    }
    for(k=j+1;k<=n/2+layer-1;k++)
    {
        liter[layer-1]=trans_of_comliter(i,k,n,flag1)*flag2;
        secondlaw_of_DEP(root,num_of_clause,layer+1,i,k,n,flag1,flag2);
    }
    return OK;
}
status secondlaw(Clause* root,int &num_of_clause,int n)
{
    int i;
    for(i=1;i<=n;i++)
    {
        secondlaw_of_DEP(root,num_of_clause,1,i,0,n,0,1);
        secondlaw_of_DEP(root,num_of_clause,1,i,0,n,0,-1);
        secondlaw_of_DEP(root,num_of_clause,1,i,0,n,1,1);
        secondlaw_of_DEP(root,num_of_clause,1,i,0,n,1,-1);
    }
    return OK;
}
status thirdlaw(Clause* root,int &num_of_clause,int n)
{
    int a,b,c,d,e,flag;
    for(a=1;a<=2;a++)
        for(b=1;b<n;b++)
            for(c=b+1;c<=n;c++)
            {
                for(d=1;d<=n;d++)
                    liter[d-1]=-trans_of_extraliter(a,b,c,d,2,n);
                addClause(root,createClause(n,liter));
                num_of_clause++;
                for(d=1;d<=n;d++)
                {
                    liter[d-1]=-trans_of_extraliter(a,b,c,d,2,n);
                    for(e=0;e<=2;e++)
                    {
                        if(e==2)
                        {
                            liter[0]=trans_of_extraliter(a,b,c,d,e,n);
                            liter[1]=-trans_of_extraliter(a,b,c,d,0,n);
                            addClause(root,createClause(2,liter));
                            num_of_clause++;
                            liter[1]=-trans_of_extraliter(a,b,c,d,1,n);
                            addClause(root,createClause(2,liter));
                            num_of_clause++;
                            liter[0]=-trans_of_extraliter(a,b,c,d,e,n);
                            liter[1]=trans_of_extraliter(a,b,c,d,0,n);
                            liter[2]=trans_of_extraliter(a,b,c,d,1,n);
                            addClause(root,createClause(3,liter));
                            num_of_clause++;
                        }
                        else
                        {
                            if(e==0) flag=-1;
                            if(e==1) flag=1;
                            liter[0]=-trans_of_extraliter(a,b,c,d,e,n);
                            liter[1]=trans_of_comliter(b,d,n,a-1)*flag;
                            addClause(root,createClause(2,liter));
                            num_of_clause++;
                            liter[1]=trans_of_comliter(c,d,n,a-1)*flag;
                            addClause(root,createClause(2,liter));
                            num_of_clause++;
                            liter[0]=trans_of_extraliter(a,b,c,d,e,n);
                            liter[1]=trans_of_comliter(b,d,n,a-1)*(-flag);
                            liter[2]=trans_of_comliter(c,d,n,a-1)*(-flag);
                            addClause(root,createClause(3,liter));
                            num_of_clause++;
                        }
                    }
                }
            }
    return OK;
}
status ReadPuzzle_File(int *puzzle,int n)
{
    int i,j;
    FILE *fp;
    char str[n+1],filename[101];
    printf("      ������PUZZLE�ļ����ļ�·��/�ļ�����");
    scanf("%s",filename);
    if(!(fp=fopen(filename,"r"))) return ERROR;
    for(i=0;i<n;i++)
    {
        fscanf(fp,"%s",str);
        for(j=0;j<n;j++)
        {
            if(str[j]=='.') *(puzzle+(i*n+j))=-1;
            if(str[j]=='1') *(puzzle+(i*n+j))=1;
            if(str[j]=='0') *(puzzle+(i*n+j))=0;
        }
    }
    return OK;
}
status ReadPuzzle_Buffer(int *puzzle,int n)
{
    int i,j;
    char str[n+1];
    printf("      ������PUZZLE��\n");
    for(i=0;i<n;i++)
    {
        scanf("%s",str);
        for(j=0;j<n;j++)
        {
            if(str[j]=='.') *(puzzle+(i*n+j))=-1;
            if(str[j]=='1') *(puzzle+(i*n+j))=1;
            if(str[j]=='0') *(puzzle+(i*n+j))=0;
        }
    }
    return OK;
}
status transPuzzle_to_CNF(Clause* root,int &num_of_clause,int n,int *a)
{
    int i,j,temp,flag,num_of_liter;
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    {
        temp=*(a+((i-1)*n+j-1));
        if(temp==0) flag=-1;
        if(temp==1) flag=1;
        if(temp==-1) continue;
        liter[0]=flag*trans_of_comliter(i,j,n,0);
        addClause(root,createClause(1,liter));
        num_of_clause++;
    }
    firstlaw(root,num_of_clause,n,0);
    firstlaw(root,num_of_clause,n,1);
    secondlaw(root,num_of_clause,n);
    thirdlaw(root,num_of_clause,n);
    return OK;
}
status SaveCNFFile(Clause* root,int *puzzle,int n,int num_of_liter,int num_of_clause)
{
    FILE *fp;
    int i,j,num=0;
    char filename[101];
    Clause* p=root->next;
    Literal* q;
    printf("      ��������Ҫ������ļ�����");
    scanf("%s",filename);
    if(!(fp=fopen(filename,"w"))) return ERROR;
    for(i=0;i<n;i++)
    for(j=0;j<n;j++)
        if(*(puzzle+(i*n+j))==-1) num++;
    fprintf(fp,"c BinaryPuzzle, order: %d, holes: %d\nc \n",n,num);
    for(i=0;i<n;i++)
    {
        fprintf(fp,"c ");
        for(j=0;j<n;j++)
        {
            if(*(puzzle+(i*n+j))==-1) fprintf(fp,".");
            else if(*(puzzle+(i*n+j))==1) fprintf(fp,"1");
            else if(*(puzzle+(i*n+j))==0) fprintf(fp,"0");
        }
        fprintf(fp,"\n");
    }
    fprintf(fp,"c \np cnf %d %d\n",num_of_liter,num_of_clause);
    while(p)
    {
        q=p->first->next;
        while(q)
        {
            fprintf(fp,"%d ",q->liter);
            q=q->next;
        }
        fprintf(fp,"0\n");
        p=p->next;
    }
    fclose(fp);
    return OK;
}
status puzzleslover(Clause* root,int n,int num_of_clause)
{
    int num_of_liter,lit;
    Sum_of_Liter temp;
    num_of_liter=trans_of_extraliter(2,n-1,n,n,2,n);
    if(!preSolve(root,num_of_liter,num_of_clause)) return ERROR;
    Literalsum(root,num_of_liter);
    temp=Literalmax(num_of_liter);
    lit=temp.liter;
    if(!root->next||DPLL(root,lit,num_of_liter,num_of_clause)||DPLL(root,-lit,num_of_liter,num_of_clause))
    {
        return OK;
    }
    else return ERROR;
}
status puzzles(int n,int *a)
{
    Clause* root;
    int num_of_clause=0,num_of_liter,lit;
    num_of_liter=trans_of_extraliter(2,n-1,n,n,2,n);
    root=(Clause*)malloc(sizeof(Clause));
    root->next=NULL;
    transPuzzle_to_CNF(root,num_of_clause,n,a);
    if(puzzleslover(root,n,num_of_clause)) return OK;
    else return ERROR;
}
status puzzles_pp(int n,int *a)
{
    Clause* root;
    int num_of_clause=0,num_of_liter,lit;
    Sum_of_Liter temp;
    num_of_liter=trans_of_extraliter(2,n-1,n,n,2,n);
    root=(Clause*)malloc(sizeof(Clause));
    root->next=NULL;
    if(!preSolve(root,num_of_liter,num_of_clause)) return ERROR;
    Literalsum(root,num_of_liter);
    temp=Literalmax(num_of_liter);
    lit=temp.liter;
    count_of_success=0;
    if(!root->next) {count_of_success++; return TRUE;}
    DPLL_pp(root,lit,num_of_liter,num_of_clause);
    DPLL_pp(root,-lit,num_of_liter,num_of_clause);
    printf("%d\n",count_of_success);
    if(count_of_success==1) return TRUE;
    else return FALSE;
}
status generate_of_puzzle(int n,int *c)
{
    int i,j,a,b,puzz;
    int puzzle[n][n],*p=puzzle[0],temp[n][n];
    srand(time(NULL));
    while(1)
    {
        if(n==4)
        {
            for(i=0;i<n;i++)
            for(j=0;j<n;j++)
                puzzle[i][j]=-1;
            *(p+rand()%16*sizeof(int))=1;
            if(puzzles(n,puzzle[0])) break;
            else continue;
        }
        for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        if(rand()%101>8) puzzle[i][j]=-1;
        else if(rand()%101>4&&rand()%101<=8)  puzzle[i][j]=0;
        else puzzle[i][j]=1;
        if(puzzles(n,puzzle[0])) break;
    }
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            if(liter[(i-1)*n+j]>=0) puzzle[i-1][j-1]=1,temp[i-1][j-1]=1;
            else puzzle[i-1][j-1]=0,temp[i-1][j-1]=0;
    for(i=0;i<n;i++)
    for(j=0;j<n;j++)
    {
        if(rand()%101>22)
        {
            puzz=temp[i][j];
            temp[i][j]=-1;
            if(!puzzles_pp(n,temp[0]))
                temp[i][j]=puzz;
        }
    }
    for(i=0;i<n;i++)
    for(j=0;j<n;j++)
        *(c+(i*n+j))=temp[i][j];
    return OK;
}
status printpuzzle(int *puzzle,int n)
{
    int i,j;
    for(i=0;i<n;i++)
    {
        printf("      ");
        for(j=0;j<n;j++)
            if(*(puzzle+(i*n+j))==-1) printf("_ ");
            else printf("%d ",*(puzzle+(i*n+j)));
        printf("\n");
    }
}
/*-----------------����-����-��ʾģ��-------------------*/
int main()
{
    int op=1,lit,opt,ent,n,i;
    char filename[101];
    int num_of_liter,num_of_clause,*puzzle;
    Sum_of_Liter temp;
    Clause* root;
    while(op){
    int choice=1;
	system("cls");	printf("\n\n");
	printf("      Menu for SAT Problem Solver On DPLL Algorithm \n");
	printf("--------------------------------------------------------------\n");
    printf("    	   0. �˳�ϵͳ\n");
	printf("    	   1. ���SAT������ʹ��CNF�ļ���\n");
	printf("    	   2. ��������������Ϸ����\n");
	printf("--------------------------------------------------------------\n");
	printf("      ��ѡ����Ĳ���[0~2]:");
	num_of_liter=0; num_of_clause=0;
	root=(Clause*)malloc(sizeof(Clause));
    root->next=NULL;
	scanf("%d",&op);
	switch(op){
	    case 1:
	        while(choice){
	        system("cls");	printf("\n\n");
            printf("      Menu for SAT Problem Solver On DPLL Algorithm \n");
	        printf("--------------------------------------------------------------\n");
          	printf("    	  1. ReadFile          3. NotImproveDPLL\n");
          	printf("    	  2. TraverseCNF       4. ImproveDPLL\n");
	        printf("    	  0. Return to main menu\n");
         	printf("--------------------------------------------------------------\n");
	        printf("      ��ѡ����Ĳ���[0~4]:");
	        scanf("%d",&choice);
            switch(choice){
                case 1:
                    if(root->next)
                    {
                        destroyList(root);
                        root=(Clause*)malloc(sizeof(Clause));
                        root->next=NULL;
                    }
                    if(ReadFile(root,num_of_liter,num_of_clause,filename))
                        printf("      CNF�ļ���ȡ�ɹ���\n");
                    else printf("      �ļ���ʧ�ܣ�\n");
                    getchar();getchar();
                    break;
                case 2:
                    if(!root->next){ printf("      ��ǰδ����CNF�ļ������ȶ��룡\n");getchar();getchar(); break;}
                    printf("\n      ������Ϊ��%-8d ��ʽ��Ϊ��%-8d\n",num_of_liter,num_of_clause);
                    printClause(root);
                    getchar();getchar();
                    break;
                case 3:
                    opt=clock();
                    Mark=0;
                    if(!root->next){ printf("      ��ǰδ����CNF�ļ������ȶ��룡\n");getchar();getchar(); break;}
                    preSolve(root,num_of_liter,num_of_clause);
                    lit=find_lit(num_of_liter);
                    if(DPLL(root,lit,num_of_liter,num_of_clause)||DPLL(root,-lit,num_of_liter,num_of_clause))
                    {
                        ent=clock();
                        destroyList(root);
                        root=(Clause*)malloc(sizeof(Clause));
                        root->next=NULL;
                        for(int i=1;i<=num_of_liter;i++)
                             printf("%d ",liter[i]);
                        printf("\ntime is %d ms\n",ent-opt);
                        if(SaveFile(ent-opt,filename,1,num_of_liter))
                            printf("      �ļ�����ɹ�!\n");
                        else printf("      �ļ�����ʧ��!\n");
                    }
                    else {ent=clock();printf("      DPLL�㷨���ʧ�ܣ��ļ�������!\n");printf("      time is %d ms\n",ent-opt);}
                    getchar();getchar();
                    break;
                case 4:
                    opt=clock();
                    Mark=1;
                    if(!root->next){ printf("      ��ǰδ����CNF�ļ������ȶ��룡\n");getchar();getchar(); break;}
                    preSolve(root,num_of_liter,num_of_clause);
                    Literalsum(root,num_of_liter);
                    temp=Literalmax(num_of_liter);
                    lit=temp.liter;
                    if(!root->next||DPLL(root,lit,num_of_liter,num_of_clause)||DPLL(root,-lit,num_of_liter,num_of_clause))
                    {
                        ent=clock();
                        destroyList(root);
                        root=(Clause*)malloc(sizeof(Clause));
                        root->next=NULL;
                        for(int i=1;i<=num_of_liter;i++)
                             printf("%d ",liter[i]);
                        printf("\ntime is %d ms\n",ent-opt);
                        if(SaveFile(ent-opt,filename,1,num_of_liter))
                            printf("      �ļ�����ɹ�!\n");
                        else printf("      �ļ�����ʧ��!\n");
                    }
                    else  {ent=clock();printf("      DPLL�㷨���ʧ�ܣ��ļ�������!\n");printf("      time is %d ms\n",ent-opt);}
                    getchar();getchar();
                    break;
                case 0:
                    destroyList(root);
                    break;
                default:
                    printf("      ����Ƿ�!\n");
                    getchar();getchar();
                    break;
                }
	        }
            break;
        case 2:
            while(choice){
	        system("cls");	printf("\n\n");
            printf("      Menu for Binary Puzzle Solver On DPLL Algorithm \n");
	        printf("--------------------------------------------------------------\n");
          	printf("    	 1. GeneratePuzzle        3. SaveCNFFile\n");
          	printf("    	 2. ReadPuzzle            4. SolvePuzzle\n");
	        printf("    	 0. Return to main menu\n");
         	printf("--------------------------------------------------------------\n");
	        printf("      ��ѡ����Ĳ���[0~4]:");
	        scanf("%d",&choice);
            switch(choice){
                case 1:
                    if(root->next)
                    {
                        printf("      ��ǰ�Ѿ�����/�����������������Ҫɾ��������1����ɾ��������0��");
                        scanf("%d",&i);
                        if(i){destroyList(root);root=(Clause*)malloc(sizeof(Clause));root->next=NULL;}
                        else {getchar();getchar(); break;}
                    }
                    printf("      ����������������Ľ�����������ż������");
                    scanf("%d",&n); num_of_clause=0;
                    if(n%2){ printf("      �����Ƿ�������ʧ�ܣ�\n");getchar();getchar();break; }
                    puzzle=(int*)malloc(sizeof(int)*n*n);
                    num_of_liter=trans_of_extraliter(2,n-1,n,n,2,n);
                    generate_of_puzzle(n,puzzle);
                    transPuzzle_to_CNF(root,num_of_clause,n,puzzle);
                    printf("      ���ɳɹ���\n");
                    printf("      ���ɵ����̲������£�\n");
                    printpuzzle(puzzle,n);
                    getchar();getchar();
                    break;
                case 2:
                    if(root->next)
                    {
                        printf("      ��ǰ�Ѿ�����/�����������������Ҫɾ��������1����ɾ��������0��");
                        scanf("%d",&i);
                        if(i){destroyList(root);root=(Clause*)malloc(sizeof(Clause));root->next=NULL;}
                        else {getchar();getchar(); break;}
                    }
                    printf("      ����������������Ľ�����������ż������");
                    scanf("%d",&n); num_of_clause=0;
                    if(n%2){ printf("      �����Ƿ�������ʧ�ܣ�\n");getchar();getchar();break; }
                    puzzle=(int*)malloc(sizeof(int)*n*n);
                    num_of_liter=trans_of_extraliter(2,n-1,n,n,2,n);
                    printf("      ��ѡ����뷽ʽ��\n");
                    printf("           1. �ļ�����\n");
                    printf("           2. ��������\n");
                    printf("      PS����....0.1.0..��Ϊʾ�������ʽ�������룺");
                    scanf("%d",&i);
                    if(i==1)
                    {
                        if(ReadPuzzle_File(puzzle,n))
                            printf("      �ļ�����ɹ���\n"),transPuzzle_to_CNF(root,num_of_clause,n,puzzle);
                        else printf("      �ļ���ʧ�ܣ�\n");
                    }
                    else if(i==2)
                    {
                        if(ReadPuzzle_Buffer(puzzle,n))
                            printf("      ����ɹ���\n"),transPuzzle_to_CNF(root,num_of_clause,n,puzzle);
                        else printf("      ����ʧ�ܣ�\n");
                    }
                    else printf("      ����Ƿ�������ʧ�ܣ�\n");
                    getchar();getchar();
                    break;
                case 3:
                    if(!root->next){ printf("      ��ǰδ����PUZZLE�����ȶ��룡\n");getchar();getchar(); break;}
                    if(SaveCNFFile(root,puzzle,n,num_of_liter,num_of_clause))
                        printf("      �ļ�����ɹ���\n");
                    else printf("      �ļ�����ʧ�ܣ�\n");
                    getchar();getchar();
                    break;
                case 4:
                    if(!root->next){ printf("      ��ǰδ����PUZZLE�����ȶ��룡\n");getchar();getchar(); break;}
                    opt=clock();
                    if(puzzleslover(root,n,num_of_clause))
                    {
                        for(int i=1;i<=n;i++)
                        for(int j=1;j<=n;j++)
                        if(liter[(i-1)*n+j]>=0) *(puzzle+((i-1)*n+j-1))=1;
                        else *(puzzle+((i-1)*n+j-1))=0;
                        printf("      ���ɹ���\n");
                        printf("      �������̲������£�\n");
                        printpuzzle(puzzle,n);
                        free(puzzle);
                    }
                    else printf("      ���ʧ�ܣ�\n");
                    destroyList(root);
                    root=(Clause*)malloc(sizeof(Clause));
                    root->next=NULL;
                    getchar();getchar();
                    break;
                case 0:
                    destroyList(root);
                    break;
                default:
                    printf("      ����Ƿ�!\n");
                    getchar();getchar();
                    break;
                }
	        }
            break;
        case 0:
            break;
	    }
    }
    printf("\n��ӭ�´���ʹ�ñ�ϵͳ��\n");
    getchar();
    return 0;
}























