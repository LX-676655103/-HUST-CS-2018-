#include "head.h"
/*-------------------CNF����ģ��---------------------*/
status ReadFile(Clause* root,int &num_of_liter,int &num_of_clause,char filename[])
{
    int i,n,num;
    FILE* fp;
    char str[1024],c;
    printf("      ������CNF�ļ����ļ�·��/�ļ�����");
    scanf("%s",filename);
    if(!(fp=fopen(filename,"r"))) return ERROR;
    printf("      CNF�ļ���ע���������£�\n");
    while(fscanf(fp,"%c",&c)!=EOF)
    {
        if(c=='c')
        {
            printf("      %c",c);
            while(fscanf(fp,"%c",&c)!=EOF&&c!='\n')
                printf("%c",c);
            printf("\n");
        }
        else
        {
            fscanf(fp,"%s",str);
            fscanf(fp,"%d %d",&num_of_liter,&num_of_clause);
            printf("\n      CNF�ļ��е�������Ϊ��%-8d ��ʽ��Ϊ��%-8d\n",num_of_liter,num_of_clause);
            break;
        }
    }
    for(i=0;i<num_of_clause;i++)
    {
        n=0;
        while(fscanf(fp,"%d",&num)!=EOF&&num!=0)
            liter[n++]=num;
        addClause(root,createClause(n,liter));
    }
    for(i=0;i<=num_of_liter;i++) liter[i]=0;
    fclose(fp);
    return OK;
}
Clause* createClause(int n,int lit[])
{
    int i;
    Clause* head;
    Literal* pNew;
    head=(Clause*)malloc(sizeof(Clause));
    head->first=(Literal*)malloc(sizeof(Literal));
    head->first->next=NULL;
    head->next=NULL;
    for(i=0;i<n;i++)
    {
        pNew=(Literal*)malloc(sizeof(Literal));
        pNew->liter=lit[i];
        pNew->next=head->first->next;
        head->first->next=pNew;
    }
    return head;
}
status destroyClause(Clause* p)
{
    Literal *pl1,*pl2;
    pl1=p->first;
    while(pl1)
    {
        pl2=pl1->next;
        free(pl1);
        pl1=pl2;
    }
    free(p);
    return OK;
}
status addClause(Clause* root,Clause* pNew)
{
    pNew->next=root->next;
    root->next=pNew;
    return OK;
}
status isUnitClause(Clause* p)
{
    if(!p->first->next) return FALSE;
    if(!p->first->next->next) return TRUE;
    return FALSE;
}
status printClause(Clause* root)
{
    Clause* p=root->next;
    Literal* q;
    while(p)
    {
        q=p->first->next;
        while(q)
        {
            printf("%d ",q->liter);
            q=q->next;
        }
        printf("0\n");
        p=p->next;
    }
    return OK;
}
Clause* copyList(Clause* root)
{
    Clause *pC=root->next;
    Clause *rNew=(Clause*)malloc(sizeof(Clause)),*pNew;
    Literal *pL,*pLNew;
    rNew->first=NULL;
    rNew->next=NULL;
    while(pC)
    {
        pNew=(Clause*)malloc(sizeof(Clause));
        pNew->first=(Literal*)malloc(sizeof(Literal));
        pNew->first->next=NULL;
        pNew->next=rNew->next;
        rNew->next=pNew;
        pL=pC->first->next;
        while(pL)
        {
            pLNew=(Literal*)malloc(sizeof(Literal));
            pLNew->liter=pL->liter;
            pLNew->next=pNew->first->next;
            pNew->first->next=pLNew;
            pL=pL->next;
        }
        pC=pC->next;
    }
    return rNew;
}
status destroyList(Clause* root)
{
    Clause *p_pre=root,*p_cur=root->next;
    while(p_cur)
    {
        p_pre->next=p_cur->next;
        destroyClause(p_cur);
        p_cur=p_pre->next;
    }
    free(p_pre);
    return OK;
}
status addliter(Clause* p,int lit)
{
    Literal *pNew;
    pNew=(Literal*)malloc(sizeof(Literal));
    pNew->liter=lit;
    pNew->next=p->first;
    p->first=pNew;
    return OK;
}
