#include "head.h"
/*--------------------����DPLLģ��---------------------*/
int find_lit(int num_of_liter)
{
    int i;
    for(i=1;i<=num_of_liter;i++)
        if(!liter[i]) return i;
    return 0;
}
status law_of_UnitClause(Clause* root,Clause* p_of_unitCla,int &num_of_clause)
{
    int liter;
    Clause *p_of_curCla,*p_of_preCla;
    Literal *p_of_curLiter,*p_of_preLiter;
    p_of_preCla=root;
    p_of_curCla=root->next;
    liter=p_of_unitCla->first->next->liter;
    while(p_of_curCla)
    {
        p_of_preLiter=p_of_curCla->first;
        p_of_curLiter=p_of_preLiter->next;
        while(p_of_curLiter)
        {
            if(p_of_curLiter->liter==liter)
            {
                p_of_preCla->next=p_of_curCla->next;
                destroyClause(p_of_curCla);
                p_of_curCla=p_of_preCla;
                num_of_clause--;
                break;
            }
            else if(p_of_curLiter->liter+liter==0)
            {
                if(!p_of_curLiter->next&&p_of_preLiter==p_of_curCla->first) return ERROR;
                p_of_preLiter->next=p_of_curLiter->next;
                free(p_of_curLiter);
                p_of_curLiter=p_of_preLiter->next;
            }
            else
            {
                p_of_preLiter=p_of_curLiter;
                p_of_curLiter=p_of_curLiter->next;
            }
        }
        p_of_preCla=p_of_curCla;
        p_of_curCla=p_of_curCla->next;
    }
    return OK;
}
status preSolve(Clause* root,int num_of_liter,int &num_of_clause)
{
    int literal,i;
    Clause* p=root->next;
    for(i=0;i<=num_of_liter;i++) liter[i]=0;
    while(p)
        if(!p->first->next) return ERROR;
        else p=p->next;
    p=root->next;
    while(p)
    {
        if(isUnitClause(p))
        {
            liter[abs(p->first->next->liter)]=p->first->next->liter;
            if(law_of_UnitClause(root,p,num_of_clause)) p=root->next;
            else return FALSE;
        }
        else p=p->next;
    }
    return OK;
}
status Literalsum(Clause *root,int num_of_liter)
{
    int i;
    Clause *p=root->next;
    Literal *q;
    for(i=0;i<num_of_liter;i++)
        a[i].liter=i+1,a[i].sum=0.0,a[i].num_of_positive=0,a[i].num_of_negative=0;
    while(p)
    {
        i=0;
        q=p->first->next;
        while(q){i++;q=q->next;}
        q=p->first->next;
        while(q)
        {
            a[abs(q->liter)-1].sum+=pow(0.5,i);
            if(q->liter>0) a[abs(q->liter)-1].num_of_positive++;
            else a[abs(q->liter)-1].num_of_negative++;
            q=q->next;
        }
        p=p->next;
    }
    return OK;
}
Sum_of_Liter Literalmax(int num_of_liter)
{
    int i;
    Sum_of_Liter temp=a[0];
    for(i=1;i<num_of_liter;i++)
        if(temp.sum<a[i].sum)
            temp=a[i];
    return temp;
}
status Recovery_lit(Clause* p)
{
    Literal *pNew;
    pNew=p->first;
    while(pNew)
    {
        liter[abs(pNew->liter)]=0;
        pNew=pNew->next;
    }
    destroyClause(p);
    return OK;
}
status DPLL(Clause* root,int lit,int num_of_liter,int num_of_clause)
{
    int flag;
    Sum_of_Liter temp;
    Clause *p_of_UnitLiter,*p,*rNew;
    p_of_UnitLiter=(Clause*)malloc(sizeof(Clause));
    p_of_UnitLiter->first=NULL;
    rNew=copyList(root);
    liter[0]=lit;
    addClause(rNew,createClause(1,liter));
    num_of_clause++;
    p=rNew->next;
    while(p)
    if(isUnitClause(p))
    {
        if(law_of_UnitClause(rNew,p,num_of_clause))
        {
            lit=p->first->next->liter;
            addliter(p_of_UnitLiter,lit);
            liter[abs(lit)]=lit;
            p=rNew->next;
        }
        else{destroyList(rNew); Recovery_lit(p_of_UnitLiter); return FALSE;}
    }
    else p=p->next;
    if(Mark)
    {
         Literalsum(rNew,num_of_liter);
         temp=Literalmax(num_of_liter);
         lit=temp.liter;
         if(temp.num_of_positive>=temp.num_of_negative) flag=1;
         else flag=-1;
    }
    else {lit=find_lit(num_of_liter);flag=-1;}
    if(!rNew->next||DPLL(rNew,lit*flag,num_of_liter,num_of_clause)||DPLL(rNew,-lit*flag,num_of_liter,num_of_clause))
    {
        destroyList(rNew);
        return TRUE;
    }
    else{ destroyList(rNew); Recovery_lit(p_of_UnitLiter);  return FALSE; }
}

status SaveFile(int time,char filename[],int flag,int num_of_liter)
{
    FILE *fp;
    int i=0;
    while(filename[i]!='\0') i++;
    filename[i-3]='r',filename[i-2]='e',filename[i-1]='s';
    if(!(fp=fopen(filename,"w"))) return ERROR;
    fprintf(fp,"s %d",flag);
    if(flag)
    {
        fprintf(fp,"\nv ");
        for(int i=1;i<=num_of_liter;i++)
            if(liter[i]==0) fprintf(fp,"%d ",i);
            else fprintf(fp,"%d ",liter[i]);
    }
    fprintf(fp,"\nt %d\n",time);
    fclose(fp);
    return OK;
}
