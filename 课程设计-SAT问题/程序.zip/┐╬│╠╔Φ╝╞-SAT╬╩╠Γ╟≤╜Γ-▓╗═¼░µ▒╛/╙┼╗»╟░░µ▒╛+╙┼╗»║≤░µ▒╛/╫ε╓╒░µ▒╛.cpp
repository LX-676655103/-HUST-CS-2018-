#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
/*-----------------------------------------------*/
#define N 100000
#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
/*-----------------------------------------------*/
typedef int status;
typedef struct Literal{
    int mark;
    int liter;
    int lit;
    Literal* next;
}Literal;
typedef struct Clause{
    int mark;
    int lit;
    Literal* first;
    Clause* next;
}Clause;
typedef struct{
    Clause* root;
    char name[21];
}ClauseList;
typedef struct{
    int liter;
    double sum;
    int num_of_positive;
    int num_of_negative;
}Sum_of_Liter;
int liter[N];
Sum_of_Liter lit[N];
/*-----------------CNF����ģ��-------------------*/
status ReadFile(Clause* root,int &num_of_liter,int &num_of_clause);
Clause* createClause(int n,int a[]);
status destroyClause(Clause* p);
status addClause(Clause* root,Clause* pNew);
status isUnitClause(Clause* p);
status printClause(Clause* root,int num_of_clause);
Clause* copyList(Clause* root);
status destroyList(Clause* root);
/*-----------------����DPLLģ��-------------------*/
status law_of_UnitClause(Clause* root,int liter,int lit);
status preSolve(Clause* root,int num_of_liter);
status Literalsum(Clause *root,int num_of_liter);
Sum_of_Liter Literalmax(int num_of_liter);

/*-----------------CNF����ģ��-------------------*/
status ReadFile(Clause* root,int &num_of_liter,int &num_of_clause)
{
    int i,n,num,liter[N];
    FILE* fp;
    char filename[101],str[1024],c;
    printf("      ������CNF�ļ����ļ�·��/�ļ�����");
    scanf("%s",filename);
    if(!(fp=fopen(filename,"r"))) return ERROR;
    printf("      CNF�ļ���ע���������£�\n");
    while(fscanf(fp,"%c",&c)!=EOF)
    {
        if(c=='c')
        {
            printf("      %c",c);
            while(fscanf(fp,"%c",&c)!=EOF&&c!='\n')
                printf("%c",c);
            printf("\n");
        }
        else
        {
            fscanf(fp,"%s",str);
            fscanf(fp,"%d %d",&num_of_liter,&num_of_clause);
            printf("\n      CNF�ļ��е�������Ϊ��%-8d ��ʽ��Ϊ��%-8d\n",num_of_liter,num_of_clause);
            break;
        }
    }
    for(i=0;i<num_of_clause;i++)
    {
        n=0;
        while(fscanf(fp,"%d",&num)!=EOF&&num!=0)
            liter[n++]=num;
        addClause(root,createClause(n,liter));
    }
    fclose(fp);
    return OK;
}
Clause* createClause(int n,int a[])
{
    int i;
    Clause* head;
    Literal* pNew;
    head=(Clause*)malloc(sizeof(Clause));
    head->mark=1;
    head->first=(Literal*)malloc(sizeof(Literal));
    head->first->next=NULL;
    head->next=NULL;
    for(i=0;i<n;i++)
    {
        pNew=(Literal*)malloc(sizeof(Literal));
        pNew->liter=a[i];
        pNew->mark=1;
        pNew->next=head->first->next;
        head->first->next=pNew;
    }
    return head;
}
status destroyClause(Clause* p)
{
    Literal *pl1,*pl2;
    pl1=p->first;
    while(pl1)
    {
        pl2=pl1->next;
        free(pl1);
        pl1=pl2;
    }
    free(p);
    return OK;
}
status addClause(Clause* root,Clause* pNew)
{
    pNew->next=root->next;
    root->next=pNew;
    return OK;
}
status isUnitClause(Clause* p)
{
    int coun=0;
    Literal *q=p->first->next;
    if(p->mark==0) return FALSE;
    while(q)
    {
        if(q->mark==1) coun++;
        q=q->next;
    }
    if(coun==1) return TRUE;
    else return FALSE;
}
int findlit_of_UnitClause(Clause* p)
{
    Literal *q=p->first->next;
    while(q)
    {
        if(q->mark==1) return q->liter;
        q=q->next;
    }
    return 0;
}
status printClause(Clause* root,int num_of_clause)
{
    Clause* p=root->next;
    Literal* q;
    while(p)
    {
        q=p->first->next;
        while(q)
        {
            printf("%d ",q->liter);
            q=q->next;
        }
        printf("0\n");
        p=p->next;
    }
    return OK;
}
Clause* copyList(Clause* root)
{
    Clause *pC=root->next;
    Clause *rNew=(Clause*)malloc(sizeof(Clause)),*pNew;
    Literal *pL,*pLNew;
    rNew->first=NULL;
    rNew->next=NULL;
    while(pC)
    {
        pNew=(Clause*)malloc(sizeof(Clause));
        pNew->first=(Literal*)malloc(sizeof(Literal));
        pNew->first->next=NULL;
        pNew->next=rNew->next;
        rNew->next=pNew;
        pL=pC->first->next;
        while(pL)
        {
            pLNew=(Literal*)malloc(sizeof(Literal));
            pLNew->liter=pL->liter;
            pLNew->next=pNew->first->next;
            pNew->first->next=pLNew;
            pL=pL->next;
        }
        pC=pC->next;
    }
    return rNew;
}
status destroyList(Clause* root)
{
    Clause *p_pre=root,*p_cur=root->next;
    while(p_cur)
    {
        p_pre->next=p_cur->next;
        destroyClause(p_cur);
        p_cur=p_pre->next;
    }
    free(p_pre);
    return OK;
}
status addliter(Clause* p,int lit)
{
    Literal *pNew;
    pNew=(Literal*)malloc(sizeof(Literal));
    pNew->liter=lit;
    pNew->next=p->first;
    p->first=pNew;
    return OK;
}
status isEmpty(Clause* root)
{
    Clause *p=root->next;
    while(p)
    {
        if(p->mark==1) return FALSE;
        p=p->next;
    }
    return TRUE;
}
/*-----------------����DPLLģ��-------------------*/
status law_of_UnitClause(Clause* root,int liter,int lit)
{
    Clause *p_of_Cla;
    Literal *p_of_Liter;
    p_of_Cla=root->next;
    while(p_of_Cla)
    {
        if(!p_of_Cla->mark)
        {
            p_of_Cla=p_of_Cla->next;
            continue;
        }
        p_of_Liter=p_of_Cla->first->next;
        while(p_of_Liter)
        {
            if(!p_of_Liter->mark) p_of_Liter->mark=0;
            else if(p_of_Liter->liter==liter)
            {
                p_of_Cla->lit=lit;
                p_of_Cla->mark=0;
                break;
            }
            else if(p_of_Liter->liter+liter==0)
                if(isUnitClause(p_of_Cla))  return ERROR;
                else p_of_Liter->mark=0,p_of_Liter->lit=lit;
            p_of_Liter=p_of_Liter->next;
        }
        p_of_Cla=p_of_Cla->next;
    }
    return OK;
}
status preSolve(Clause* root,int num_of_liter)
{
    int literal,i;
    Clause* p=root->next;
    for(i=0;i<=num_of_liter;i++) liter[i]=0;
    while(p)
        if(!p->first->next) return ERROR;
        else p=p->next;
    p=root->next;
    while(p)
    {
        if(isUnitClause(p))
        {
            liter[abs(p->first->next->liter)]=p->first->next->liter;
            if(law_of_UnitClause(root,findlit_of_UnitClause(p),0)) p=root->next;
            else return FALSE;
        }
        else p=p->next;
    }
    return OK;
}
status Literalsum(Clause *root,int num_of_liter)
{
    int i;
    Clause *p=root->next;
    Literal *q;
    for(i=0;i<num_of_liter;i++){
        lit[i].liter=i+1;
        lit[i].sum=0.0;
        lit[i].num_of_positive=0;
        lit[i].num_of_negative=0;
    }
    while(p)
    {
        if(p->mark==0){ p=p->next; continue; }
        for(i=0,q=p->first->next;q;q=q->next)
            if(q->mark==1) i++;
        q=p->first->next;
        while(q)
        {
            if(q->mark==1) lit[abs(q->liter)-1].sum+=1;
            q=q->next;
        }
        p=p->next;
    }
    return OK;
}
Sum_of_Liter Literalmax(int num_of_liter)
{
    int i;
    Sum_of_Liter temp=lit[0];
    for(i=1;i<num_of_liter;i++)
        if(temp.sum<lit[i].sum)
            temp=lit[i];
    return temp;
}
status recover(Clause* root,int lit)
{
    Clause *p=root->next;
    Literal *q;
    while(p)
    {
        if(p->mark==0&&p->lit==lit) p->mark=1;
        if(p->mark)
            for(q=p->first->next;q;q=q->next)
                if(q->mark==0&&q->lit==lit) q->mark=1;
        p=p->next;
    }
    return OK;
}
status DPLL(Clause* root,int lit,int num_of_liter)
{
    int num;
    Literal *pNew;
    Clause *p_of_UnitLiter=NULL,*p=root->next;
    Sum_of_Liter temp;
    p_of_UnitLiter=(Clause*)malloc(sizeof(Clause));
    p_of_UnitLiter->first=NULL;
    if(isEmpty(root)) return TRUE;
    if(law_of_UnitClause(root,lit,lit)) addliter(p_of_UnitLiter,lit);
    while(p)
    if(isUnitClause(p))
    {
        if(law_of_UnitClause(root,(num=findlit_of_UnitClause(p)),lit))
            addliter(p_of_UnitLiter,num),p=root->next;
        else{destroyClause(p_of_UnitLiter); recover(root,lit); return FALSE;}
    }
    else p=p->next;

    Literalsum(root,num_of_liter);
    temp=Literalmax(num_of_liter);
    num=lit;
    lit=temp.liter;
    if(DPLL(root,lit,num_of_liter)||DPLL(root,-lit,num_of_liter))
    {
        pNew=p_of_UnitLiter->first;
        while(pNew)
        {
            liter[abs(pNew->liter)]=pNew->liter;
            pNew=pNew->next;
        }
        destroyClause(p_of_UnitLiter);
        return TRUE;
    }
    else
    {
        destroyClause(p_of_UnitLiter);
        recover(root,num);
        return FALSE;
    }
}





int main()
{
    int op=1,lit,opt,ent;
    char filename[101];
    int num_of_liter,num_of_clause;
    Sum_of_Liter temp;
    Clause* root;
    while(op){
    int choice=1;
	system("cls");	printf("\n\n");
	printf("      Menu for SAT Problem Solver On DPLL Algorithm \n");
	printf("--------------------------------------------------------------\n");
    printf("    	   0. �˳�ϵͳ\n");
	printf("    	   1. ���SAT������ʹ��CNF�ļ���\n");
	printf("    	   2. ��������������Ϸ����\n");
	printf("--------------------------------------------------------------\n");
	printf("      ��ѡ����Ĳ���[0~2]:");
	num_of_liter=0; num_of_clause=0;
	scanf("%d",&op);
	switch(op){
	    case 1:
	        root=(Clause*)malloc(sizeof(Clause));
            root->next=NULL;
	        while(choice){
	        system("cls");	printf("\n\n");
            printf("      Menu for SAT Problem Solver On DPLL Algorithm \n");
	        printf("--------------------------------------------------------------\n");
          	printf("    	  1. ReadFile          3. NotImproveDPLL\n");
          	printf("    	  2. TraverseCNF       4. ImproveDPLL\n");
	        printf("    	  0. Return to main menu\n");
         	printf("--------------------------------------------------------------\n");
	        printf("      ��ѡ����Ĳ���[0~4]:");
	        scanf("%d",&choice);
            switch(choice){
                case 1:
                    if(ReadFile(root,num_of_liter,num_of_clause))
                        printf("      CNF�ļ���ȡ�ɹ���\n");
                    else printf("      �ļ���ʧ�ܣ�\n");
                    getchar();getchar();
                    break;
                case 2:
                    printf("\n      ������Ϊ��%-8d ��ʽ��Ϊ��%-8d\n",num_of_liter,num_of_clause);
                    printClause(root,num_of_clause);
                    getchar();getchar();
                    break;
                case 3:

                    getchar();getchar();
                    break;
                case 4:
                    opt=clock();
                    Literalsum(root,num_of_liter);
                    temp=Literalmax(num_of_liter);
                    lit=temp.liter;
                    if(DPLL(root,lit,num_of_liter)||DPLL(root,-lit,num_of_liter))
                    {
                        ent=clock();
                        for(int i=1;i<=num_of_liter;i++)
                             printf("%d ",liter[i]);
                        printf("\ntime is %d ms\n",ent-opt);
                    }
                    else printf("FALSE!\n");
                    getchar();getchar();
                    break;
                case 0:
                    destroyList(root);
                    break;
                default:
                    printf("      ����Ƿ�!\n");
                    getchar();getchar();
                    break;
                }

	        }
            break;
        case 2:

        case 0:
            break;
	    }
    }
    printf("\n��ӭ�´���ʹ�ñ�ϵͳ��\n");
    getchar();
    return 0;
}

























