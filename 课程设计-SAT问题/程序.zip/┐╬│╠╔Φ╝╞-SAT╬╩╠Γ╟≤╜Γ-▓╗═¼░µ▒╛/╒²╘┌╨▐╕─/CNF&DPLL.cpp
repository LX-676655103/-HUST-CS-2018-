#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define N 100000
#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
/*-----------------------------------------------*/
typedef int status;
typedef struct Literal{
    int flag;
    int liter;
    Literal* next;
}Literal;
typedef struct Clause{
    Literal* first;
    Clause* next;
}Clause;
typedef struct{
    Clause* root;
    char name[21];
}ClauseList;
typedef struct{
    int liter;
    double sum;
    int flag0;
    int flag1;
}Sum_of_Liter;
int liter[N];
/*-----------------CNF����ģ��-------------------*/
Clause* ReadCNF(int &num_of_liter,int &num_of_clause);
Clause* createClause(int n);
status destroyClause(Clause* p);
status addClause(Clause*&root,Clause* pNew);
status isUnitClause(Clause* p);
status printClause(Clause* root,int num_of_clause);
/*-----------------����DPLLģ��-------------------*/
status law_of_UnitClause(Clause* root,Clause* p_of_unitCla,int &num_of_clause);
status preSolve(Clause* root,int num_of_liter,int &num_of_clause);
status Literalsum(Clause *root,Sum_of_Liter a[],int num_of_liter);
Sum_of_Liter Literalmax(Sum_of_Liter a[],int num_of_liter);
Clause* copyList(Clause* root);
status destroyList(Clause* root);
/*-----------------CNF����ģ��-------------------*/
Clause* ReadCNF(int &num_of_liter,int &num_of_clause)
{
    FILE* fp;
    int n,i,num;
    char filename[100];
    Clause* root;
    printf("      �������ļ�����");
    scanf("%s",filename);
    if (!(fp=fopen(filename,"r"))) {printf("      ���ļ�ʧ��!\n"); return ERROR;}
    while(fscanf(fp,"%s",filename)&&strcmp(filename,"cnf")!=0);
    fscanf(fp,"%d %d",&num_of_liter,&num_of_clause);
    root=(Clause*)malloc(sizeof(Clause));
    root->next=NULL;
    for(i=0;i<num_of_clause;i++)
    {
        n=0;
        while(fscanf(fp,"%d",&num)!=EOF&&num!=0)
            liter[n++]=num;
        addClause(root->next,createClause(n));
    }
    printf("      ���ļ��ɹ�!\n");
    fclose(fp); //�ر��ļ�
    return root;
}

Clause* createClause(int n)
{
    int i;
    Clause* head;
    Literal* pNew;
    head=(Clause*)malloc(sizeof(Clause));
    head->first=(Literal*)malloc(sizeof(Literal));
    head->first->next=NULL;
    head->next=NULL;
    for(i=0;i<n;i++)
    {
        pNew=(Literal*)malloc(sizeof(Literal));
        pNew->liter=liter[i];
        pNew->next=head->first->next;
        head->first->next=pNew;
    }
    return head;
}
status destroyClause(Clause* p)
{
    Literal *pl1,*pl2;
    pl1=p->first;
    while(pl1)
    {
        pl2=pl1->next;
        free(pl1);
        pl1=pl2;
    }
    free(p);
    return OK;
}
status addClause(Clause*&root,Clause* pNew)
{
    pNew->next=root;
    root=pNew;
    return OK;
}
status isUnitClause(Clause* p)
{
    if(!p->first->next) return FALSE;
    if(!p->first->next->next) return TRUE;
    return FALSE;
}
status printClause(Clause* root,int num_of_clause)
{
    int i;
    Clause* p=root;
    Literal* q;
    for(i=0;i<num_of_clause;i++)
    {
        q=p->first->next;
        while(q)
        {
            printf("%d ",q->liter);
            q=q->next;
        }
        printf("0\n");
        p=p->next;
    }
    return OK;
}
/*-----------------����DPLLģ��-------------------*/
status law_of_UnitClause(Clause* root,Clause* p_of_unitCla,int &num_of_clause)
{
    int liter;
    Clause *p_of_curCla,*p_of_preCla;
    Literal *p_of_curLiter,*p_of_preLiter;
    p_of_preCla=root;
    p_of_curCla=root->next;
    liter=p_of_unitCla->first->next->liter;
    while(p_of_curCla)
    {
        p_of_preLiter=p_of_curCla->first;
        p_of_curLiter=p_of_preLiter->next;
        while(p_of_curLiter)
        {
            if(p_of_curLiter->liter==liter)
            {
                p_of_preCla->next=p_of_curCla->next;
                destroyClause(p_of_curCla);
                p_of_curCla=p_of_preCla;
                num_of_clause--;
                break;
            }
            else if(p_of_curLiter->liter+liter==0)
            {
                if(!p_of_curLiter->next&&p_of_preLiter==p_of_curCla->first) return ERROR;
                p_of_preLiter->next=p_of_curLiter->next;
                free(p_of_curLiter);
                p_of_curLiter=p_of_preLiter->next;
            }
            else
            {
                p_of_preLiter=p_of_curLiter;
                p_of_curLiter=p_of_curLiter->next;
            }
        }
        p_of_preCla=p_of_curCla;
        p_of_curCla=p_of_curCla->next;
    }
    return OK;
}
status preSolve(Clause* root,int num_of_liter,int &num_of_clause)
{
    int literal,i;
    Clause* p=root->next;
    for(i=0;i<=num_of_liter;i++) liter[i]=0;
    while(p)
        if(!p->first->next) return ERROR;
        else p=p->next;
    p=root->next;
    while(p)
    {
        if(isUnitClause(p))
        {
            liter[abs(p->first->next->liter)]=p->first->next->liter;
            if(law_of_UnitClause(root,p,num_of_clause)) p=root->next;
            else return FALSE;
        }
        else p=p->next;
    }
    return OK;
}
status Literalsum(Clause *root,Sum_of_Liter a[],int num_of_liter)
{
    int i;
    Clause *p=root->next;
    Literal *q;
    for(i=0;i<num_of_liter;i++)
        a[i].liter=i+1,a[i].sum=0.0,a[i].flag0=0,a[i].flag1=0;
    while(p)
    {
        i=0;
        q=p->first->next;
        while(q){i++;q=q->next;}
        q=p->first->next;
        while(q)
        {
            a[abs(q->liter)-1].sum+=pow(0.5,i);
            if(q->liter>0) a[abs(q->liter)-1].flag1++;
            else a[abs(q->liter)-1].flag0++;
            q=q->next;
        }
        p=p->next;
    }
    return OK;
}
Sum_of_Liter Literalmax(Sum_of_Liter a[],int num_of_liter)
{
    int i;
    Sum_of_Liter temp=a[0];
    for(i=1;i<num_of_liter;i++)
        if(temp.sum<a[i].sum)
            temp=a[i];
    return temp;
}
status Literalsort(Sum_of_Liter a[],int num_of_liter)
{
    int i,j,flag=0;
    Sum_of_Liter temp;
    for(i=0;i<num_of_liter-1;i++)
    {
        flag=0;
        for(j=0;j<num_of_liter-i-1;j++)
            if(a[j].sum<=a[j+1].sum)
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                flag=1;
            }
        if(!flag) return OK;
    }
    return OK;
}
Clause* copyList(Clause* root)
{
    Clause *pC=root->next;
    Clause *rNew=(Clause*)malloc(sizeof(Clause)),*pNew;
    Literal *pL,*pLNew;
    rNew->first=NULL;
    rNew->next=NULL;
    while(pC)
    {
        pNew=(Clause*)malloc(sizeof(Clause));
        pNew->first=(Literal*)malloc(sizeof(Literal));
        pNew->first->next=NULL;
        pNew->next=rNew->next;
        rNew->next=pNew;
        pL=pC->first->next;
        while(pL)
        {
            pLNew=(Literal*)malloc(sizeof(Literal));
            pLNew->liter=pL->liter;
            pLNew->next=pNew->first->next;
            pNew->first->next=pLNew;
            pL=pL->next;
        }
        pC=pC->next;
    }
    return rNew;
}
status destroyList(Clause* root)
{
    Clause *p_pre=root,*p_cur=root->next;
    while(p_cur)
    {
        p_pre->next=p_cur->next;
        destroyClause(p_cur);
        p_cur=p_pre->next;
    }
    free(p_pre);
    return OK;
}
status DPLL(Clause* root,int flag,int num_of_clause,int num_of_liter,Sum_of_Liter a[],int lit)
{
    Clause *p_of_UnitLiter,*p,*rNew;
    Sum_of_Liter temp;
    Literal *pNew;
    p_of_UnitLiter=(Clause*)malloc(sizeof(Clause));
    p_of_UnitLiter->first=NULL;

    rNew=copyList(root);

    p=(Clause*)malloc(sizeof(Clause));
    p->first=(Literal*)malloc(sizeof(Literal));
    p->first->next=NULL;
    p->next=rNew->next;
    rNew->next=p;
    pNew=(Literal*)malloc(sizeof(Literal));

    if(flag==1) pNew->liter=lit;
    else pNew->liter=0-lit;

    pNew->next=p->first->next;
    p->first->next=pNew;
    num_of_clause++;
    p=rNew->next;
    while(p)
    {
        if(isUnitClause(p))
        {
            if(law_of_UnitClause(rNew,p,num_of_clause))
            {
                pNew=(Literal*)malloc(sizeof(Literal));
                pNew->liter=p->first->next->liter;
                pNew->next=p_of_UnitLiter->first;
                p_of_UnitLiter->first=pNew;
                p=rNew->next;
            }
            else{destroyList(rNew); destroyClause(p_of_UnitLiter); return FALSE;}
        }
        else p=p->next;
    }
    Literalsum(rNew,a,num_of_liter);
    temp=Literalmax(a,num_of_liter);
    lit=temp.liter;
    if(temp.flag0<temp.flag1) flag=-1;
    else flag=1;
    if(!rNew->next||DPLL(rNew,flag,num_of_clause,num_of_liter,a,lit)||DPLL(rNew,-flag,num_of_clause,num_of_liter,a,lit))
    {
        destroyList(rNew);
        pNew=p_of_UnitLiter->first;
        while(pNew)
        {
            liter[abs(pNew->liter)]=pNew->liter;
            pNew=pNew->next;
        }
        destroyClause(p_of_UnitLiter);
        return TRUE;
    }
    else{ destroyList(rNew);destroyClause(p_of_UnitLiter); return FALSE; }
}
/*-----------------------------------------------*/
int main()
{
    int i,op,ed,lit,flag;
    Clause* root;
    Sum_of_Liter temp;
    char filename[100];
    FILE *fp;
    int num_of_liter,num_of_clause;
    root=ReadCNF(num_of_liter,num_of_clause);
    Sum_of_Liter literal[num_of_liter];
    op=clock();
    preSolve(root,num_of_liter,num_of_clause);

    /*Literalsum(root,literal,num_of_liter);
    Literalsort(literal,num_of_liter);

    for(i=0;i<num_of_liter;i++)
       printf("%d %f\n",literal[i].liter,literal[i].sum);*/
    Literalsum(root,literal,num_of_liter);
    temp=Literalmax(literal,num_of_liter);
    lit=temp.liter;
    if(temp.flag0<temp.flag1) flag=-1;
    else flag=1;
    if(DPLL(root,flag,num_of_clause,num_of_liter,literal,lit)||Literalsum(root,literal,num_of_liter)&&DPLL(root,-flag,num_of_clause,num_of_liter,literal,lit))
    {
        ed=clock();
        printf("      �������ļ�����");
        scanf("%s",filename);
        fp=fopen(filename,"w");
        fprintf(fp,"s 1\nv ");

        for(i=1;i<=num_of_liter;i++)
            fprintf(fp,"%d ",liter[i]);
        fprintf(fp,"\n");

        fprintf(fp,"t %d",ed-op);
        fclose(fp);//�ر��ļ�
        printf("      ����ɹ���\n");

    }
    else printf("FALSE!\n");
    printf("\n\ntime is %d ms!\n",ed-op);

    getchar();getchar();

    return 0;
}









