#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define N 100000
#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
/*-----------------------------------------------*/
typedef int status;
typedef struct Literal{
    int liter;
    Literal* next;
}Literal;
typedef struct Clause{
    Literal* first;
    Clause* next;
}Clause;
typedef struct{
    Clause* root;
    char name[21];
}ClauseList;
typedef struct{
    int liter;
    double sum;
}Sum_of_Liter;
int liter[N];
/*-----------------CNF����ģ��-------------------*/
Clause* createClause(int n);
status destroyClause(Clause* p);
status addClause(Clause*&root,Clause* pNew);
status isUnitClause(Clause* p);
status printClause(Clause* root,int num_of_clause);
/*-----------------����DPLLģ��-------------------*/
status law_of_UnitClause(Clause* root,Clause* p_of_unitCla,int &num_of_clause);
status preSolve(Clause* root,int num_of_liter,int &num_of_clause);
status Literalsum(Clause *root,Sum_of_Liter a[],int num_of_liter);
int Literalmax(Sum_of_Liter a[],int num_of_liter);
Clause* copyList(Clause* root);
status destroyList(Clause* root);
/*----------------����������ģ��------------------*/



/*-----------------CNF����ģ��-------------------*/
Clause* createClause(int n)
{
    int i;
    Clause* head;
    Literal* pNew;
    head=(Clause*)malloc(sizeof(Clause));
    head->first=(Literal*)malloc(sizeof(Literal));
    head->first->next=NULL;
    head->next=NULL;
    for(i=0;i<n;i++)
    {
        pNew=(Literal*)malloc(sizeof(Literal));
        pNew->liter=liter[i];
        pNew->next=head->first->next;
        head->first->next=pNew;
    }
    return head;
}
status destroyClause(Clause* p)
{
    Literal *pl1,*pl2;
    pl1=p->first;
    while(pl1)
    {
        pl2=pl1->next;
        free(pl1);
        pl1=pl2;
    }
    free(p);
    return OK;
}
status addClause(Clause*&root,Clause* pNew)
{
    pNew->next=root;
    root=pNew;
    return OK;
}
status isUnitClause(Clause* p)
{
    if(!p->first->next) return FALSE;
    if(!p->first->next->next) return TRUE;
    return FALSE;
}
status printClause(Clause* root,int num_of_clause)
{
    int i;
    Clause* p=root;
    Literal* q;
    for(i=0;i<num_of_clause;i++)
    {
        q=p->first->next;
        while(q)
        {
            printf("%d ",q->liter);
            q=q->next;
        }
        printf("0\n");
        p=p->next;
    }
    return OK;
}
/*-----------------����DPLLģ��-------------------*/
status law_of_UnitClause(Clause* root,Clause* p_of_unitCla,int &num_of_clause)
{
    int liter;
    Clause *p_of_curCla,*p_of_preCla;
    Literal *p_of_curLiter,*p_of_preLiter;
    p_of_preCla=root;
    p_of_curCla=root->next;
    liter=p_of_unitCla->first->next->liter;
    while(p_of_curCla)
    {
        p_of_preLiter=p_of_curCla->first;
        p_of_curLiter=p_of_preLiter->next;
        while(p_of_curLiter)
        {
            if(p_of_curLiter->liter==liter)
            {
                p_of_preCla->next=p_of_curCla->next;
                destroyClause(p_of_curCla);
                p_of_curCla=p_of_preCla;
                num_of_clause--;
                break;
            }
            else if(p_of_curLiter->liter+liter==0)
            {
                if(!p_of_curLiter->next&&p_of_preLiter==p_of_curCla->first) return ERROR;
                p_of_preLiter->next=p_of_curLiter->next;
                free(p_of_curLiter);
                p_of_curLiter=p_of_preLiter->next;
            }
            else
            {
                p_of_preLiter=p_of_curLiter;
                p_of_curLiter=p_of_curLiter->next;
            }
        }
        p_of_preCla=p_of_curCla;
        p_of_curCla=p_of_curCla->next;
    }
    return OK;
}
status preSolve(Clause* root,int num_of_liter,int &num_of_clause)
{
    int literal,i;
    Clause* p=root->next;
    for(i=0;i<=num_of_liter;i++) liter[i]=0;
    while(p)
        if(!p->first->next) return ERROR;
        else p=p->next;
    p=root->next;
    while(p)
    {
        if(isUnitClause(p))
        {
            liter[abs(p->first->next->liter)]=p->first->next->liter;
            if(law_of_UnitClause(root,p,num_of_clause)) p=root->next;
            else return FALSE;
        }
        else p=p->next;
    }
    return OK;
}
status Literalsum(Clause *root,Sum_of_Liter a[],int num_of_liter)
{
    int i;
    Clause *p=root->next;
    Literal *q;
    for(i=0;i<num_of_liter;i++)
        a[i].liter=i+1,a[i].sum=0.0;
    while(p)
    {
        i=0;
        q=p->first->next;
        while(q){i++;q=q->next;}
        q=p->first->next;
        while(q)
        {
            a[abs(q->liter)-1].sum+=pow(0.5,i);
            q=q->next;
        }
        p=p->next;
    }
    return OK;
}
int Literalmax(Sum_of_Liter a[],int num_of_liter)
{
    int i;
    Sum_of_Liter temp=a[0];
    for(i=1;i<num_of_liter;i++)
        if(temp.sum<a[i].sum)
            temp=a[i];
    if(temp.sum==0) return 0;
    return temp.liter;
}
status Literalsort(Sum_of_Liter a[],int num_of_liter)
{
    int i,j,flag=0;
    Sum_of_Liter temp;
    for(i=0;i<num_of_liter-1;i++)
    {
        flag=0;
        for(j=0;j<num_of_liter-i-1;j++)
            if(a[j].sum<=a[j+1].sum)
            {
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                flag=1;
            }
        if(!flag) return OK;
    }
    return OK;
}
Clause* copyList(Clause* root)
{
    Clause *pC=root->next;
    Clause *rNew=(Clause*)malloc(sizeof(Clause)),*pNew;
    Literal *pL,*pLNew;
    rNew->first=NULL;
    rNew->next=NULL;
    while(pC)
    {
        pNew=(Clause*)malloc(sizeof(Clause));
        pNew->first=(Literal*)malloc(sizeof(Literal));
        pNew->first->next=NULL;
        pNew->next=rNew->next;
        rNew->next=pNew;
        pL=pC->first->next;
        while(pL)
        {
            pLNew=(Literal*)malloc(sizeof(Literal));
            pLNew->liter=pL->liter;
            pLNew->next=pNew->first->next;
            pNew->first->next=pLNew;
            pL=pL->next;
        }
        pC=pC->next;
    }
    return rNew;
}
status destroyList(Clause* root)
{
    Clause *p_pre=root,*p_cur=root->next;
    while(p_cur)
    {
        p_pre->next=p_cur->next;
        destroyClause(p_cur);
        p_cur=p_pre->next;
    }
    free(p_pre);
    return OK;
}
status DPLL(Clause* root,int flag,int num_of_clause,int num_of_liter,Sum_of_Liter a[])
{
    int lit;
    Clause *p_of_UnitLiter,*p,*rNew;
    Literal *pNew;
    p_of_UnitLiter=(Clause*)malloc(sizeof(Clause));
    p_of_UnitLiter->first=NULL;

    rNew=copyList(root);
    Literalsum(rNew,a,num_of_liter);
    lit=Literalmax(a,num_of_liter);

    p=(Clause*)malloc(sizeof(Clause));
    p->first=(Literal*)malloc(sizeof(Literal));
    p->first->next=NULL;
    p->next=rNew->next;
    rNew->next=p;
    pNew=(Literal*)malloc(sizeof(Literal));

    if(flag) pNew->liter=lit;
    else pNew->liter=0-lit;

    pNew->next=p->first->next;
    p->first->next=pNew;
    num_of_clause++;
    p=rNew->next;
    while(p)
    {
        if(isUnitClause(p))
        {
            if(law_of_UnitClause(rNew,p,num_of_clause))
            {
                pNew=(Literal*)malloc(sizeof(Literal));
                pNew->liter=p->first->next->liter;
                pNew->next=p_of_UnitLiter->first;
                p_of_UnitLiter->first=pNew;
                p=rNew->next;
            }
            else{destroyList(rNew); destroyClause(p_of_UnitLiter); return FALSE;}
        }
        else p=p->next;
    }
    if(!rNew->next||DPLL(rNew,1,num_of_clause,num_of_liter,a)||DPLL(rNew,0,num_of_clause,num_of_liter,a))
    {
        destroyList(rNew);
        pNew=p_of_UnitLiter->first;
        while(pNew)
        {
            liter[abs(pNew->liter)]=pNew->liter;
            pNew=pNew->next;
        }
        destroyClause(p_of_UnitLiter);
        return TRUE;
    }
    else{ destroyList(rNew);destroyClause(p_of_UnitLiter); return FALSE; }
}
/*----------------����������ģ��------------------*/

int trans_of_comliter(int i,int j,int n,int flag) //flag==0��ʾ�������ȣ�flag==1��ʾ��������
{
    if(flag==0) return (i-1)*n+j;
    else return (j-1)*n+i;
}
int trans_of_extraliter(int a,int b,int c,int d,int e,int n)
{
    return n*n+(a-1)*n*(n-1)*n*3/2+((c-1)*(c-2)/2+b-1)*3*n+3*d+e-2;
}
status firstlaw(Clause* root,int &num_of_clause,int n,int flag)
{
    int i,j,k;
    for(i=1;i<=n;i++)
        for(j=1;j<=n-2;j++)
        {
            for(k=0;k<=2;k++)
                liter[k]=trans_of_comliter(i,j+k,n,flag);
            addClause(root->next,createClause(3));
            for(k=0;k<=2;k++)
                liter[k]=-trans_of_comliter(i,j+k,n,flag);
            addClause(root->next,createClause(3));
            num_of_clause+=2;
        }
    return OK;
}
status secondlaw_of_DEP(Clause* root,int &num_of_clause,int layer,int i,int j,int n,int flag1,int flag2)
{
    int k;
    if(layer-1==n/2+1)
    {
        addClause(root->next,createClause(layer-1));
        num_of_clause++;
        return OK;
    }
    for(k=j+1;k<=n/2+layer-1;k++)
    {
        liter[layer-1]=trans_of_comliter(i,k,n,flag1)*flag2;
        secondlaw_of_DEP(root,num_of_clause,layer+1,i,k,n,flag1,flag2);
    }
    return OK;
}
status secondlaw(Clause* root,int &num_of_clause,int n)
{
    int i;
    for(i=1;i<=n;i++)
    {
        secondlaw_of_DEP(root,num_of_clause,1,i,0,n,0,1);
        secondlaw_of_DEP(root,num_of_clause,1,i,0,n,0,-1);
        secondlaw_of_DEP(root,num_of_clause,1,i,0,n,1,1);
        secondlaw_of_DEP(root,num_of_clause,1,i,0,n,1,-1);
    }
    return OK;
}

status thirdlaw(Clause* root,int &num_of_clause,int n)
{
    int a,b,c,d,e,flag;
    for(a=1;a<=2;a++)
        for(b=1;b<n;b++)
            for(c=b+1;c<=n;c++)
            {
                for(d=1;d<=n;d++)
                    liter[d-1]=-trans_of_extraliter(a,b,c,d,2,n);
                addClause(root->next,createClause(n));
                num_of_clause++;
                for(d=1;d<=n;d++)
                {
                    liter[d-1]=-trans_of_extraliter(a,b,c,d,2,n);
                    for(e=0;e<=2;e++)
                    {
                        if(e==2)
                        {
                            liter[0]=trans_of_extraliter(a,b,c,d,e,n);
                            liter[1]=-trans_of_extraliter(a,b,c,d,0,n);
                            addClause(root->next,createClause(2));
                            num_of_clause++;
                            liter[1]=-trans_of_extraliter(a,b,c,d,1,n);
                            addClause(root->next,createClause(2));
                            num_of_clause++;
                            liter[0]=-trans_of_extraliter(a,b,c,d,e,n);
                            liter[1]=trans_of_extraliter(a,b,c,d,0,n);
                            liter[2]=trans_of_extraliter(a,b,c,d,1,n);
                            addClause(root->next,createClause(3));
                            num_of_clause++;
                        }
                        else
                        {
                            if(e==0) flag=-1;
                            if(e==1) flag=1;
                            liter[0]=-trans_of_extraliter(a,b,c,d,e,n);
                            liter[1]=trans_of_comliter(b,d,n,a-1)*flag;
                            addClause(root->next,createClause(2));
                            num_of_clause++;
                            liter[1]=trans_of_comliter(c,d,n,a-1)*flag;
                            addClause(root->next,createClause(2));
                            num_of_clause++;
                            liter[0]=trans_of_extraliter(a,b,c,d,e,n);
                            liter[1]=trans_of_comliter(b,d,n,a-1)*(-flag);
                            liter[2]=trans_of_comliter(c,d,n,a-1)*(-flag);
                            addClause(root->next,createClause(3));
                            num_of_clause++;
                        }
                    }
                }
            }
    return OK;
}
status ReadPuzzle(Clause* root,int &num_of_clause,int n)
{
    int i,j,temp,flag;
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    {
        scanf("%d",&temp);
        if(temp==0) flag=-1;
        if(temp==1) flag=1;
        if(temp==-1) continue;
        liter[0]=flag*trans_of_comliter(i,j,n,0);
        addClause(root->next,createClause(1));
        num_of_clause++;
    }
    return OK;
}
status transPuzzle(Clause* root,int &num_of_clause,int n,int *a)
{
    int i,j,temp,flag;
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    {
        temp=*(a+((i-1)*n+j-1));
        if(temp==0) flag=-1;
        if(temp==1) flag=1;
        if(temp==-1) continue;
        liter[0]=flag*trans_of_comliter(i,j,n,0);
        addClause(root->next,createClause(1));
        num_of_clause++;
    }
    return OK;
}
status puzzleslover(int n,int *a)
{
    Clause* root;
    int num_of_clause=0,num_of_liter;
    num_of_liter=trans_of_extraliter(2,n-1,n,n,2,n);
    Sum_of_Liter literal[num_of_liter];
    root=(Clause*)malloc(sizeof(Clause));
    root->next=NULL;
    transPuzzle(root,num_of_clause,n,a);
    firstlaw(root,num_of_clause,n,0);
    firstlaw(root,num_of_clause,n,1);
    secondlaw(root,num_of_clause,n);
    thirdlaw(root,num_of_clause,n);
    preSolve(root,num_of_liter,num_of_clause);
    if(!root->next||DPLL(root,1,num_of_clause,num_of_liter,literal)||DPLL(root,0,num_of_clause,num_of_liter,literal))
    {
        destroyList(root);
        return OK;
    }
    else{ destroyList(root); return ERROR;}
}
int* generate_of_puzzle(int n)
{
    int i,j,a,b,puzz;
    int puzzle[n][n],*p=puzzle[0],temp[n][n];
    srand(time(NULL));
    while(1)
    {
        if(n==4)
        {
            for(i=0;i<n;i++)
            for(j=0;j<n;j++)
                puzzle[i][j]=-1;
            *(p+rand()%16*sizeof(int))=1;
            if(puzzleslover(n,puzzle[0])) break;
            else continue;
        }
        for(i=0;i<n;i++)
        for(j=0;j<n;j++)
        if(rand()%101>8) puzzle[i][j]=-1;
        else if(rand()%101>4&&rand()%101<=8)  puzzle[i][j]=0;
        else puzzle[i][j]=1;
        if(puzzleslover(n,puzzle[0])) break;
    }
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            if(liter[(i-1)*n+j]>=0) puzzle[i-1][j-1]=1,temp[i-1][j-1]=1;
            else puzzle[i-1][j-1]=0,temp[i-1][j-1]=0;
    for(i=0;i<n;i++)
    for(j=0;j<n;j++)
    {
        if(rand()%101>45)
        {
            puzz=temp[i][j];
            temp[i][j]=-1;
            if(puzzleslover(n,temp[0]))
            {
                for(a=1;a<=n;a++)
                for(b=1;b<=n;b++)
                    if(liter[(a-1)*n+b]>=0){if(puzzle[a-1][b-1]!=1) temp[i][j]=puzz;}
                    else if(liter[(a-1)*n+b]<0){if(puzzle[a-1][b-1]!=0) temp[i][j]=puzz;}
            }
            else temp[i][j]=puzz;
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
            printf("%d ",temp[i][j]);
        printf("\n");
    }
    printf("\n");
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
            printf("%d ",puzzle[i][j]);
        printf("\n");
    }
    return NULL;
}
/*-----------------------------------------------*/
int main()
{
    Clause* root;
    int num_of_clause=0,num_of_liter,n,i,j;
    scanf("%d",&n);
    //generate_of_puzzle(n);
    num_of_liter=trans_of_extraliter(2,n-1,n,n,2,n);
    Sum_of_Liter literal[num_of_liter];
    root=(Clause*)malloc(sizeof(Clause));
    root->next=NULL;
    ReadPuzzle(root,num_of_clause,n);
    firstlaw(root,num_of_clause,n,0);
    firstlaw(root,num_of_clause,n,1);
    secondlaw(root,num_of_clause,n);
    thirdlaw(root,num_of_clause,n);

    preSolve(root,num_of_liter,num_of_clause);
    printClause(root->next,num_of_clause);
    if(DPLL(root,1,num_of_clause,num_of_liter,literal)||DPLL(root,0,num_of_clause,num_of_liter,literal))
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
           {
               if(liter[(i-1)*n+j]>=0) printf("1 ");
               else printf("0 ");
           }
           printf("\n");
        }
    }
    else printf("FALSE!");
    getchar();getchar();
    return 0;
}





























