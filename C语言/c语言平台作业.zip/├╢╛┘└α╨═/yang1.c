#include <stdio.h>
char	*m1[12] = { "January,31", "February,28", "March,31", "April,30", "May,31", "June,30", "July,31", "August,31", "September,30", "October,31", "November,30", "December,31" };
char	*m2[12] = { "January,31", "February,29", "March,31", "April,30", "May,31", "June,30", "July,31", "August,31", "September,30", "October,31", "November,30", "December,31" };

void prt(char **m)
{
	enum month { Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec };
	int i;
	for ( i = Jan; i <= Dec; i++ )
		if( i==Dec)
			printf( "%s;\n", *(m+i));
		else
			printf( "%s;", *(m+i));
}


void main()
{
	int a[10];
	int length,i;
	scanf("%d",&length);
	for (i=0;i<length;i++)
	{
		scanf("%d",&a[i]);
	}
	for (i=0;i<length;i++)
	{
		if ((0==a[i]%4&&0!=a[i]%100)||(0==a[i]%400))
			prt(m2);
		else
			prt(m1);
	}
}

