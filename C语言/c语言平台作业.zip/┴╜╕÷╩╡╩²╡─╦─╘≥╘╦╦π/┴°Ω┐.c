#include<stdio.h>
#include<math.h>
int main()
{
	int t,p;
	double a;
	float a1;
	for (p=1;p<10000;p++){
	for (t=1;t<10000;t++)
    {
        a=10000/t;
        a1=10000/t;
        if(abs(a,a1)>0.001) printf("%d %d\n",p,t);
    }
	}
	return 0;
}
