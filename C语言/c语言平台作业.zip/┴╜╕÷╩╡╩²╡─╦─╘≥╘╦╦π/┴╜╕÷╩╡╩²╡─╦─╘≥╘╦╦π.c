#include <stdio.h>

int main()
{
    int t;
    float a,b;
    char c;
    while(scanf("%d",&t)!=EOF)
    {
        scanf("%f%f %c",&a,&b,&c);
        if(t==0||t==2)
        {
            if (c=='+') printf("After if-else processing,the result is : %.2f\n",a+b);
            else if (c=='-') printf("After if-else processing,the result is : %.2f\n",a-b);
            else if (c=='*') printf("After if-else processing,the result is : %.2f\n",a*b);
            else if (c=='/') printf("After if-else processing,the result is : %.2f\n",a/b);

        }
        if(t==1||t==2)
        {
            switch(c)
            {
                case '+':  printf("After switch processing,the result is : %.2f\n",a+b);break;
                case '-':  printf("After switch processing,the result is : %.2f\n",a-b);break;
                case '*':  printf("After switch processing,the result is : %.2f\n",a*b);break;
                case '/':  printf("After switch processing,the result is : %.2f\n",a/b);break;
            }
        }
        printf("\n");
    }
    return 0;
}
