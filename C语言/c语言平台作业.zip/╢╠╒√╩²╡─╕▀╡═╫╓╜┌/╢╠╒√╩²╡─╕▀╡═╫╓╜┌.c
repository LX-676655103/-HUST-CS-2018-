#include <stdio.h>

int main()
{
    int n;
    unsigned short num;
    unsigned short high,low;
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%hu",&num);
        high=(num>>8)<<8>>8;
        low=(num<<8)>>8;
        printf("%c,%c\n",high,low);
        n--;
    }
}
