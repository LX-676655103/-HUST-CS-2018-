#include <stdio.h>
int main()
{
    int n;
    int i,j;
    int a=1;
    while(scanf("%d",&n)!=EOF)
    {
        if(n==0)break;
    for(i=0;i<n;i++)
    {
        for(j=0;j<2*(n-i-1);j++)
            printf(" ");
        printf("%d",a);
        for(j=1;j<=i;j++)
        {
            a=a*(i-j+1)/j;
            printf("%4d",a);
        }
        printf("\n");
    }
    printf("\n");
    }
    return 0;
}
