#include <stdio.h>
unsigned long a,b;
int is_k()
{
    int i;
    for(i=1;i<b;i++)
        if(!(a/=10)) return -1;
    return a%10;
}

int main()
{
    while(scanf("%lu%lu",&a,&b)!=EOF)
         printf("%d\n",is_k());
    return 0;
}
