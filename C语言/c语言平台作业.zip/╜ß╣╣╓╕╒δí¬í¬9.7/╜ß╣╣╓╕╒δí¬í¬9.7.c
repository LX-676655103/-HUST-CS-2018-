#include<stdio.h>
struct Student{
    int num;
    char name[19];
    double score;
};
int main()
{
    int n;
    int i,j;
    struct Student s[3],*ps=&s[0];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        for(j=0;j<3;j++)
        scanf("%d%s%lf",&s[j].num,s[j].name,&s[j].score);
        for(j=0;j<3;j++)
        printf("%d\t%-20s%f\n",s[j].num,s[j].name,s[j].score);
        for(j=0;j<3;j++)
        printf("%d\t%-20s%f\n",(ps+j)->num,(ps+j)->name,(ps+j)->score);
    }
    return 0;
}
