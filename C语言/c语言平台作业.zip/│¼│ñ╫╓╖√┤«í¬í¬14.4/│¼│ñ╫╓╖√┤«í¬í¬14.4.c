#include<stdio.h>
#include<stdlib.h>
struct longstring{
    char data;
    struct longstring *pNext;
};
int main()
{
    int iNum=1,i;
    struct longstring *pHead=NULL;
    struct longstring *pEnd,*pNew;
    pEnd=pNew=(struct longstring*)malloc(sizeof(struct longstring));
    pHead=pEnd;
    scanf("%c",&pNew->data);
    for(;;)
    {
        iNum++;
        pNew=(struct longstring*)malloc(sizeof(struct longstring));
        pEnd->pNext=pNew;
        pNew->pNext=NULL;
        scanf("%c",&pNew->data);
        pEnd=pNew;
        if(pNew->data=='#') break;
    }
    free(pNew);
    char *pS=(char*)malloc(sizeof(char)*iNum);
    pNew=pHead;
    for(i=1;i<iNum;i++)
    {
        printf("%c",pNew->data);
        *(pS+i-1)=pNew->data;
        pNew=pNew->pNext;
    }
    printf("\n\n");
    *(pS+iNum-1)='\0';
    pNew=pHead;
    printf("%s\n",pS);
    return 0;
}
