#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    float a,b,c,p,area;
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%f%f%f",&a,&b,&c);
        p=(a+b+c)/2;
        area=sqrt(p*(p-a)*(p-b)*(p-c));
        printf("area=%f\n",area);
        n--;
    }
    return 0;
}
