#include <stdio.h>
int main()
{
    double x;
    printf("Please enter salary:");
    scanf("%lf",&x);
    if((int)x/1000==0) printf("tax=0.00\n");
    else if((int)x/1000==1) printf("tax=%.2lf\n",x*0.05);
    else if((int)x/1000==2) printf("tax=%.2lf\n",x*0.10);
    else if((int)x/1000==3) printf("tax=%.2lf\n",x*0.15);
    else if((int)x/1000==4) printf("tax=%.2lf\n",x*0.20);
    else printf("tax=%.2lf\n",x*0.25);
    return 0;
}
