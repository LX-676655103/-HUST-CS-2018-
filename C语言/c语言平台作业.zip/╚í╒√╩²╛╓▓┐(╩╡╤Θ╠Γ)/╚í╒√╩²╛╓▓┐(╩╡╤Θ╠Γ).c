#include<stdio.h>
int main( )
{
    int p;
    unsigned short x,m,n,mask=0;
    scanf("%d",&p);
    while(p>0)
    {
        mask=0;
        scanf("%hu%hu%hu",&x,&m,&n);
        mask=(~mask)>>(16-n);
        mask=mask<<m;
        mask=(mask&x)<<(16-m-n);
        printf("%hu\n",mask);
        p--;
    }
    return 0;
}
