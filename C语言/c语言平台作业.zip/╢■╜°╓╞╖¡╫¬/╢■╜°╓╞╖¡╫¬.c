#include <stdio.h>
int x,p,n;
int a[32];
int main ()
{
    int i,j;
    scanf("%d%d%d",&x,&p,&n);
    i=31;
    while (i!=-1)
    {
        a[i]=x%2;
        i--;
        x=x/2;
    }
    for (i=0;i<32;i++)
    {
        if ((i+1)%8==0&&(i+1)/8!=4) printf("%d ",a[i]);
        else if ((i+1)%8==0&&(i+1)/8==4) printf("%d\n",a[i]);
        else printf("%d",a[i]);
    }
    for (j=32-p-n;j<=31-p;j++)
    {
        if (a[j]==0) a[j]=1;
        else if (a[j]==1) a[j]=0;
    }
    for (i=0;i<32;i++)
    {
        if ((i+1)%8==0&&(i+1)/8!=4) printf("%d ",a[i]);
        else if ((i+1)%8==0&&(i+1)/8==4) printf("%d\n",a[i]);
        else printf("%d",a[i]);
    }

    return 0;
}
