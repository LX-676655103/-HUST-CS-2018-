#include<stdio.h>
int main()
{
	int a[32],x,p,n,account=0,i;
	scanf("%d%d%d",&x,&p,&n);
	if(x>=0)
		a[0]=0;
	else
		a[0]=1;
	for(i=31;i>=0;i--)
	{
		a[i]=x%2;
		x=x/2;
	}
	for(i=0;i<32;i++)
	{
		printf("%d",a[i]);
		account+=1;
		if(account%8==0&&account<30)
			printf(" ");
	}
	printf("\n");
	for(i=31-p;i>=31-n;i--)
		if(a[i]==0)
			a[i]=1;
		else
			a[i]=0;
	account=0;
	for(i=0;i<32;i++)
	{
		printf("%d",a[i]);
		account+=1;
		if(account%8==0&&account<30)
			printf(" ");
	}
	printf("\n");
	return 0;
}
