#include<stdio.h>
int main()
{
    int i,j;
    int n,iTep,iPos;
    int num[100];
    scanf("%d",&n);
    for(i=0;i<n;i++)
        scanf("%d",&num[i]);
    for(i=0;i<n-1;i++)
    {
        iTep=num[i];
        iPos=i;
        for(j=i+1;j<n;j++)
            if(iTep>num[j])
                iTep=num[j],iPos=j;
        num[iPos]=num[i];
        num[i]=iTep;
    }
    for(i=0;i<n-1;i++)
        printf("%d ",num[i]);
    printf("%d\n",num[i]);
    return 0;
}
