#include <stdio.h>
int main()
{
    double i=1;
    double PI=0;
    while(1)
    {
        if (((int)i+1)%4==0) PI=PI-1/i;
        else PI=PI+1/i;
        if (1/i<1e-5) break;
        i=i+2;
    }
    printf("%.9f\n",PI*4);
    return 0;
}
