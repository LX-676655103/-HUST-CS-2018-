#include<stdio.h>
#define EPS 1e-5
int main()
{
	double sum=0;
	int i;
	for(i=1;;i++)
	{
	    if((1.0/(2*i-1)-EPS)<0)
			break;
		if(i%2==1)
		sum+=1.0/(2*i-1);
		else
		sum-=1.0/(2*i-1);

	}
	printf("%.9f\n",4*sum);
	return 0;
}
