#include <stdio.h>
#include <math.h>
int main()
{
    int i,t;
    int n,sum;
    char num[100];
    scanf("%d ",&n);
    while(n>0)
    {
        i=0;
        t=0;
        sum=0;
        getchar();
        getchar();
        while((num[i++]=getchar())!='\n');
        for(i=i-2;i>=0;i--)
        {
            if(num[i]>='0'&&num[i]<='9')
                sum+=(num[i]-48)*ceil(pow(16,t++));
            else if(num[i]>='a'&&num[i]<='f')
                sum+=(num[i]-87)*ceil(pow(16,t++));
            else if(num[i]>='A'&&num[i]<='F')
                sum+=(num[i]-55)*ceil(pow(16,t++));
        }
        printf("%d\n",sum);
        n--;
    }
    return 0;
}
