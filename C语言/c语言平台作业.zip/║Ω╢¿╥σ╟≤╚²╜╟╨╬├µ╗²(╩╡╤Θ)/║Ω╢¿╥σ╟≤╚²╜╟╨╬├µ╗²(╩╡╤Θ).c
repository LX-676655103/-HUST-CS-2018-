#include<stdio.h>
#include<math.h>
#define s ((a+b+c)/2)
#define area (((a+b+c)/2)*(((a+b+c)/2)-a)*(((a+b+c)/2)-b)*(((a+b+c)/2)-c))
int main()
{
    int a,b,c;
    while(scanf("%d%d%d",&a,&b,&c)!=EOF)
        printf("%d %f\n",s,sqrt(area));
    return 0;
}
