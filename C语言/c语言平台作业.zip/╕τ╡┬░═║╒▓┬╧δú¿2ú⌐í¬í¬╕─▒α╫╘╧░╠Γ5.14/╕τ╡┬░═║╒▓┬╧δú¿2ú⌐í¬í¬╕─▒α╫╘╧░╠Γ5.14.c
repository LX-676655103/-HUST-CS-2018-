#include <stdio.h>
#include<math.h>
int judge(int i)
{
    int j;
    if(i==1) return 0;
    for(j=2;j<i;j++)
        if (i%j==0)
            return 0;
    return 1;
}

int main()
{
    int i,j;
    int beg,end;
    while(scanf("%d%d",&beg,&end)!=EOF)
    {
        for (i=beg;i<=end;i++)
        {
            if(i%2==1) continue;
            for(j=2;j<i;j++)
            if (judge(j)==1&&judge(i-j)==1)
            {
                printf("%d=%d+%d\n",i,j,i-j);
                break;
            }
        }
        printf("\n");
    }
    return 0;
}
