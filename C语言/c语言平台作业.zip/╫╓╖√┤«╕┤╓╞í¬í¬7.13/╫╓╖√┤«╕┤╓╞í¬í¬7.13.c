#include<stdio.h>
int mycpy(char*s,char*t,int n)
{
    int i;
    for(i=0;i<n;i++)
        t[i]=s[i];
    return 0;
}
int main()
{
    int i;
    int N,n;
    char t[1000],s[1000];
    scanf("%d",&N);
    while(N>0)
    {
        i=0;
        getchar();
        while((s[i++]=getchar())!='\n');
        scanf("%d",&n);
        mycpy(s,t,n);
        for(i=0;i<n-1;i++)
            printf("%c",t[i]);
        printf("%c\n",t[i]);
        N--;
    }
    return 0;
}
