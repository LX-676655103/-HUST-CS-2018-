#include <stdio.h>
int main()
{
    int n,t,num;
    int i;
    int a[10];
    double sum;
    scanf("%d",&n);
    while(n>0)
    {
        sum=0;
        num=0;
        scanf("%d",&t);
        for (i=0;i<10;i++)
        {
            scanf("%d",&a[i]);
        }
        if (t==0)
        {
            for (i=0;i<10;i++)
            {
                if (a[i]<=0) continue;
                sum+=a[i];
                num++;
            }
            if (sum!=0)printf("In \"continue\" way,numbers=%d,average=%f\n",num,sum/num);
        }
        else if (t==1)
        {
            for (i=0;i<10;i++)
            {
                if (a[i]>0)
                {
                    sum+=a[i];
                    num++;
                }
            }
            if (sum!=0)printf("In \"no continue\" way,numbers=%d,average=%f\n",num,sum/num);
        }
        n--;
    }
    return 0;
}
