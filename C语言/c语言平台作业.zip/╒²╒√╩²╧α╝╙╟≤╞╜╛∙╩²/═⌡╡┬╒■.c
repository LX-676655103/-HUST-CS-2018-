#include<stdio.h>
int main()
{
	int n,I,j,a,t,k;
	double sum=0;
	scanf ("%d", &n);
	for (I = 0; I < n; I++)
	{
	    k=0;
	    sum=0;
		scanf("%d", &t);
		if(!t)
		{
			for (j = 0; j < 10; j++)
			{
				scanf("%d", &a);
				if (a <= 0)
					continue;
				else
				{
					sum += a;
					k++;
				}
			}
			if (k!=0)printf("In \"continue\" way,numbers=%d,average=%f\n", k,sum / k);
		}
		else
		{
			for (j = 0; j < 10; j++)
			{
				scanf("%d", &a);
				if (a > 0)
				{
					sum += a;
					k++;
				}
			}
            if (k!=0)printf("In \"no continue\" way,numbers=%d,average=%f\n", k, sum / k);
		}
	}
	return 0;
}
