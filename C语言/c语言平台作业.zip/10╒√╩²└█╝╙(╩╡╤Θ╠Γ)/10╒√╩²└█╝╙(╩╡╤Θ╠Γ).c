#include <stdio.h>
int main()
{
    int n,sum;
    int i;
    int num;
    scanf("%d",&n);
    while(n>0)
    {
        sum=0;
        for(i=0;i<10;i++)
        {
            scanf("%d",&num);
            sum+=num;
        }
        printf("sum=%d\n",sum);
        n--;
    }
    return 0;
}
