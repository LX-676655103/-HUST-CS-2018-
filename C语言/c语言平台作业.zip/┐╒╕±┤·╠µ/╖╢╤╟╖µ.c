#include<stdio.h>
#define SPACE 0
#define START 1
int main()
{
    char c;
    int i,n;
    int state=SPACE;
    scanf("%d",&n);
    getchar();
    for(i=1; i<=n; i++)
    {
        state=SPACE;
        while((c=getchar())!='\n')
            switch(state)
            {
            case SPACE:
                if(c==' ')
                {
                    putchar(c);
                    state=START;
                }
                else putchar(c);
                break;
            case START:
                if(c!=' ')
                {
                    putchar(c);
                    state=SPACE;
                }
                break;
            }
        printf("\n");
    }
    return 0;
}
