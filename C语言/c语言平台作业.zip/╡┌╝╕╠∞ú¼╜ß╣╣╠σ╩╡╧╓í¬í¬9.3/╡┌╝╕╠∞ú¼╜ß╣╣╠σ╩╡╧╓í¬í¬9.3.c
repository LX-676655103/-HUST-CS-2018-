#include<stdio.h>
struct date{
    int year;
    int month;
    int day;
};
const mon1[12]={31,28,31,30,31,30,31,31,30,31,30,31};
const mon2[12]={31,29,31,30,31,30,31,31,30,31,30,31};
int main()
{
    int n;
    int i,j,sum;
    scanf("%d",&n);
    struct date num[n];
    for(i=0;i<n;i++)
    scanf("%d%d%d",&num[i].year,&num[i].month,&num[i].day);
    for(i=0;i<n;i++)
    {
        if(num[i].year%4==0&&num[i].year%100!=0||num[i].year%400==0)
        for(j=0,sum=0;j<num[i].month-1;j++)
            sum+=mon2[j];
        else
        for(j=0,sum=0;j<num[i].month-1;j++)
            sum+=mon1[j];
        printf("%d\n",sum+num[i].day);
    }
    return 0;
}
