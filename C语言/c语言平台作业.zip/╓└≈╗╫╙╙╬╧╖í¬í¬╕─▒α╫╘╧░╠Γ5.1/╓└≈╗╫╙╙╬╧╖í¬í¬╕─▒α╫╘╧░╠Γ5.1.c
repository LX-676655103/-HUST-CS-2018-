#include<stdio.h>
#include<math.h>
int mod(int num)
{
    int k=0;
    while(num>0)
    {
        k+=num%10;
        num/=10;
    }
    k%=6;
    return ++k;
}
int main()
{
    int i;
    int a,b;
    int n,sum,dot;
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%d%d",&a,&b);
        sum=mod(a)+mod(b);
        if(sum==11||sum==7)
            printf("success!\n");
        else if(sum==12||sum==2||sum==3)
            printf("fail!\n");
        else
        {
            dot=sum;sum=0;
            while(sum!=dot&&sum!=7)
                sum=mod(++a)+mod(++b);
            if(sum==dot)
                printf("success!\n");
            else if(sum==7)
                printf("fail!\n");
        }
        n--;
    }
    return 0;
}
