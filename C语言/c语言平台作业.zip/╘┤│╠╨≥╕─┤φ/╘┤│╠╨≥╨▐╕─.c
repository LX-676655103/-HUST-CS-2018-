#include <stdio.h>
void main(void)
{
int i=1,sum=1,s;
  printf("Please enter s:");
  scanf("%d",&s);
  while(sum<s)
  {
      sum=sum*i;
      i++;
  }
  printf("%d����%d",i-1,s);
}
