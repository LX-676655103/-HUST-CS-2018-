#include <stdio.h>
int main()
{
    int n,sum;
    int day[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    int y,m,d;
    int i;
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%d%d%d",&y,&m,&d);
        sum=0;
        for (i=1;i<m;i++)
        {
            sum=sum+day[i];
        }
        sum=sum+d;
        if((y%4==0&&y%100!=0&&m>2)||y%400==0&&m>2) sum++;
        printf("%d\n",sum);
        n--;
    }
    return 0;
}
