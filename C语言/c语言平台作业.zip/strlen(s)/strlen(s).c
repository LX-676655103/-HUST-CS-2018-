#include <stdio.h>
char c;
int t;
int cal()
{
    if((c=getchar())=='\n') return 0;
    else
    {
        t++;
        cal();
    }
    return 0;
}

int main()
{
    int n;
    scanf("%d",&n);
    getchar();
    while(n>0)
    {
        t=0;
        cal();
        printf("%d\n",t);
        n--;
    }
    return 0;
}
