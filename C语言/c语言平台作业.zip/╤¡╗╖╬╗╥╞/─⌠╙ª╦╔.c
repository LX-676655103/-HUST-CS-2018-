#include<stdio.h>
int main()
{
	int x=0,n=0;
	int y,c;
	y=sizeof(int)*8;
	scanf("%d%d",&x,&n);
	n=n%y;
	c=(x>>n)|(x<<(y-n));
	printf("%d\n",c);
	return 0;
 }
