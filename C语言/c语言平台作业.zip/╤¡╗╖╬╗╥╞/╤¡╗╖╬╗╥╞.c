#include <stdio.h>
#include <math.h>
int x,n;
int main ()
{
    int i,j,m,p;
    int result=0;
    int a[sizeof(int)*8];
    int b[sizeof(int)*8];
    scanf("%d%d",&x,&n);
    i=sizeof(int)*8-1;
    while (i!=-1)
    {
        a[i]=x%2;
        i--;
        x=x/2;
    }
    n=n%32;
    p=0;
    m=sizeof(int)*8-n;
    for (j=0;j<sizeof(int)*8;j++)
    {
        if (m<sizeof(int)*8)
        {
            b[j]=a[m];
            m++;
        }
        else
        {
            b[j]=a[p];
            p++;
        }
    }
    if (b[0]==0)
    {
        for (i=1;i<sizeof(int)*8;i++)
        {
            result=result+b[i]*pow(2,sizeof(int)*8-1-i);
        }
        printf("%d\n",result);
    }
    else if (b[0]==1)
    {
        for (j=1;j<sizeof(int)*8;j++)
        {
            if (b[j]==0) b[j]=1;
            else if (b[j]==1) b[j]=0;
        }
        for (i=1;i<sizeof(int)*8;i++)
        {
            result=result+b[i]*pow(2,sizeof(int)*8-1-i);
        }
        printf("-%d\n",result+1);
    }
    return 0;
}












