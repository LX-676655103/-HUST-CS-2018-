#include <stdio.h>
int judge(int i)
{
    int j;
    for(j=2;j<i;j++)
    {
        if (i%j==0)
        {
            return 0;
        }
    }
    return 1;
}

int main()
{
    int n;
    int a;
    int i;
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%d",&a);
        for (i=2;i<a;i++)
        {
            if (judge(i)==1&&judge(a-i)==1)
            {
                printf("%d=%d+%d\n",a,i,a-i);
                break;
            }
        }
        n--;
    }
    return 0;
}

