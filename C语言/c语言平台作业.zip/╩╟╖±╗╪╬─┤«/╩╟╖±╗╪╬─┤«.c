#include<stdio.h>
char c[100];
int is_huiwenstr(int m,int n)
{
    if(m>=n) return 1;
    if(c[m]==c[n]&&is_huiwenstr(m+1,n-1))
             return 1;
    else return 0;

}
int main()
{
    int n,i=0;
    scanf("%d",&n);
    getchar();
    while(n>0)
    {
        for(i=0;i<100;i++)
            c[i]=0;
        i=0;
        while((c[i++]=getchar())!='\n');
        if(is_huiwenstr(0,i-2))
            printf("Yes!\n");
        else
            printf("No!\n");
        n--;
    }
    return 0;
}
