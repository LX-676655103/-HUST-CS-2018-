#include <stdio.h>

int main()
{
    int n;
    char num[2];
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%s",num);
        if(num[0]>='0'&&num[0]<='9') printf("%s\n",num);
        else if(num[0]>='a'&&num[0]<='f')
            printf("%d\n",num[0]-87);
        else if(num[0]>='A'&&num[0]<='F')
            printf("%d\n",num[0]-55);
        else
            printf("%d\n",num[0]);
        n--;
    }
}
