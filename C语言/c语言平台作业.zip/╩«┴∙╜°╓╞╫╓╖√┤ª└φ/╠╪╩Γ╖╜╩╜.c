#include <stdio.h>
int main()
{
    int n;
    char a[4]={'\\','x',' '};
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%s",&a[2]);
        printf("%d\n",'\xa');
        n--;
    }
}
