#include <stdio.h>
#include <math.h>
double newton(double x)
{
    double n;
    n=x-(3*x*x*x-4*x*x-5*x+13)/(9*x*x-8*x-5);
    return n;
}
int main()
{
    double x1=2;
    while(abs(x1-newton(x1))>1e-6)
        x1=newton(x1);
    printf("%lf\n",x1);
    return 0;
}
