#include <stdio.h>
int main()
{
    int a,b,c;
    while(scanf("%d%d%d",&a,&b,&c)!=EOF)
    {
        if(a==b||a==c) printf("A:%d\n",a);
        else if(a!=b&&b==c) printf("B:%d\n",b);
        else
        a>b?(a>c?(b>c?printf("B:%d\n",b):printf("C:%d\n",c)):printf("A:%d\n",a)):(b>c?(a>c?printf("A:%d\n",a):printf("C:%d\n",c)):printf("B:%d\n",b));
    }
     return 0;
}
