#include<stdio.h>
int num;
int time;

int DFS(int k,int t)
{
    int i;
    for(i=k-1;i>0;i--)
    {
        if(i>=k-i&&k-i>=t)
        {
            time++;
            DFS(i,k-i);
        }
    }
    return 0;
}

int main()
{
    while(scanf("%d",&num)!=EOF)
    {
        time=1;
        DFS(num,0);
        printf("%d\n",time);
    }
    return 0;
}
