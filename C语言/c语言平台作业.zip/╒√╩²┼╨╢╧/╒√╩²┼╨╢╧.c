#include<stdio.h>
int main()
{
    float a;
    int n,m;
    while(scanf("%f",&a)!=EOF)
    {
        m=a;
        n=a;
        if (n==0) return 0;
        m=m%10;
        if (n%3==0&&m==5)
            printf("1\n");
        else printf("0\n");
        a=0.0;
    }
    return 0;
}

