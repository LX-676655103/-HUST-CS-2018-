#include<stdio.h>
int main()
{
	int hyr;
	while(scanf("%d",&hyr)==1)
	{
		int n,y,s;
		n=hyr%3;
		y=hyr%10;
		s=(n==0)&&(y==5);
		printf("%d\n",s);
	}
	return 0;
}
