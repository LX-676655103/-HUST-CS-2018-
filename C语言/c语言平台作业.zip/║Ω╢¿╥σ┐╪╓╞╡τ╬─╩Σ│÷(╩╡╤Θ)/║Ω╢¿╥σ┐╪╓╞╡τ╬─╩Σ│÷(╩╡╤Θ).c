#include<stdio.h>
#include<math.h>
#define CHANGE(c) (c%2)

int main()
{
    int n;
    char c;
    scanf("%d",&n);
    getchar();
    while(n>0)
    {
        c=getchar();
        if(CHANGE(c)==0)
        {
            putchar(c);
            while((c=getchar())!='\n')
            putchar(c);
        }
        else
        {
            if(c>='a'&&c<='z')
                putchar(c-32);
            else if(c>='A'&&c<='Z')
                putchar(c+32);
            else putchar(c);
            while((c=getchar())!='\n')
            {
                if(c>='a'&&c<='z')
                   putchar(c-32);
                else if(c>='A'&&c<='Z')
                   putchar(c+32);
                else putchar(c);
            }
        }
        printf("\n");
        n--;
    }
    return 0;
}
