#include<stdio.h>
#include<string.h>
struct Web{
    char lim[20];
    char com[40];
    char web[200];
};
int main()
{
    int n;
    int i,j;
    scanf("%d",&n);
    struct Web a[n],iTep;
    for(i=0;i<n;i++)
        scanf("%s%s%s",a[i].lim,a[i].com,a[i].web);
    for(i=0;i<n;i++)
        printf("%-20s%-40s%s\n",a[i].lim,a[i].com,a[i].web);
    printf("\n");
    for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
        if(strcmp(a[j].lim,a[j+1].lim)>0)
            iTep=a[j],a[j]=a[j+1],a[j+1]=iTep;
    for(i=0;i<n;i++)
        printf("%-20s%-40s%s\n",a[i].lim,a[i].com,a[i].web);
    return 0;
}
