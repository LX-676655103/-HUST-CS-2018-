#include<stdio.h>
int main()
{
    int i;
    char c;
    int num[200]={0};
    while((c=getchar())!=EOF)
    {
        if(c>='0'&&c<='9'||c>='a'&&c<='z'||c>='A'&&c<='Z')
            num[c]++;
        else num[0]++;
    }
    for(i=1;i<10;i++)
        printf("%c:%d ",i+47,num[i+47]);
    printf("%c:%d\n",i+47,num[i+47]);
    for(i=1;i<26;i++)
        printf("%c:%d ",i+96,num[i+96]+num[i+64]);
    printf("%c:%d\n",i+96,num[i+96]+num[i+64]);
    printf("other:%d\n",num[0]);
    return 0;
}
