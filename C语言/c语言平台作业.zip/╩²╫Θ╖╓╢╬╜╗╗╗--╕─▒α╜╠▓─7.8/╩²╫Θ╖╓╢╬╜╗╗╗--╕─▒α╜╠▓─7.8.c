#include<stdio.h>
int main()
{
    int i,j;
    int n,k,iTep;
    int u[60];
    while(scanf("%d%d",&n,&k)!=EOF)
    {
        for(i=0;i<n;i++)
            scanf("%d",&u[i]);
        for(i=0;i<k;i++)
        {
            iTep=u[0];
            for(j=0;j<n-1;j++)
                u[j]=u[j+1];
            u[n-1]=iTep;
        }
        for(i=0;i<n-1;i++)
            printf("%d ",u[i]);
        printf("%d\n",u[i]);
    }
    return 0;
}
