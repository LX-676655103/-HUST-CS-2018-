#include <stdio.h>
#define Swap(x,y) {x=x+y; y=x-y; x=x-y;}
int main()
{
    int n;
    int x,y;
    scanf("%d",&n);
    while(n>0)
    {
        scanf("%d%d",&x,&y);
        Swap(x,y);
        printf("%d %d\n",x,y);
        n--;
    }
    return 0;
}
