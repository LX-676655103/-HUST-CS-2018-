#include <stdio.h>
#define Swap(x,y) x=x+y; y=x-y; x=x-y;
int main()
{
    int i=0;
    int x,y;
    while(scanf("%d%d",&x,&y)!=EOF)
    {
        i++;
        printf("Case %d:\n",i);
        printf("Before Swap:a=%d b=%d\n",x,y);
        Swap(x,y);
        printf("After Swap:a=%d b=%d\n\n",x,y);
    }
    return 0;
}
