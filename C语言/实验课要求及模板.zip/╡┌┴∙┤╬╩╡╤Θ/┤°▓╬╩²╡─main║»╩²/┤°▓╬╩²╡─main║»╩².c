#include<stdio.h>
int sort(int *num[],int n,int flag);
int main(int argc,char *argv[])
{
    int n,i;
    scanf("%d",&n);
    int num[n];
    for(i=0;i<n;i++)
        scanf("%d",*(num+i));
    if(argv[0]=='-'&&argv[1]=='d')
        sort(num[n],n,1);
    else sort(num[n],n,0);
    for(i=0;i<n-1;i++)
        printf("%d ",*(num+i));
    printf("%d ",*(num+i));
    return 0;
}
int sort(int *num[],int n,int flag)
{
    int i,j,iTep;
    if(flag)
    {
        for(i=0;i<n-1;i++)
        for(j=0;j<n-i-1;j++)
        if(*(num+j)>*(num+j+1))
        iTep=*(num+j),*(num+j)=*(num+j+1),*(num+j)=iTep;
    }
    else*(num+j)
    {
        for(i=n-1;i>0;i++)
        for(j=n-1;j>n-i-1;j--)
        if(*(num+j)>num[j+1])
        iTep=*(num+j),*(num+j)=*(num+j+1),*(num+j)=iTep;
    }
}
