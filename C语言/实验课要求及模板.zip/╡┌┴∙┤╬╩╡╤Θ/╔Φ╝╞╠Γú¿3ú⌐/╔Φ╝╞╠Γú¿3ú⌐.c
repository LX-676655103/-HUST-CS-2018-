#include<stdio.h>
#define M 5
#define N 5
char sub[M][100],*psub[M];
char name[N][100],*pname[N];
double Asub[M]={0},*pA2=Asub;
int Aver_score_of_Stu(int (*psc)[M]);
int Aver_score_of_Sub(int (*psc)[M]);
int Num_of_low(int (*psc)[M]);
int Num_of_fail(int (*psc)[M]);
int Num_of_perfect(int (*psc)[M]);
int main()
{
    int i,j,t;
    int score[N][M],(*psc)[M]=score;
    for(i=0;i<M;i++)
    {
        *(psub+i)=*(sub+i);
        scanf("%s",*(psub+i));
    }
    for(i=0;i<N;i++)
    {
        *(pname+i)=*(name+i);
        scanf("%s",*(pname+i));
        for(j=0;j<M;j++)
            scanf("%d",*(psc+i)+j);
    }
    Aver_score_of_Stu(psc);
    Aver_score_of_Sub(psc);
    Num_of_low(score);
    Num_of_fail(score);
    Num_of_perfect(score);
    return 0;
}
int Aver_score_of_Stu(int (*psc)[M])
{
    int i,j;
    double Astu[N]={0},*pA1=Astu;
    for(i=0;i<N;i++)
    {
        for(j=0;j<M;j++)
        *(Astu+i)+=*(*(psc+i)+j);
        printf("Average score of %s is %.2f\n",*(pname+i),*(Astu+i)/M);
    }
    return 0;
}
int Aver_score_of_Sub(int (*psc)[M])
{
    int i,j;
    for(i=0;i<M;i++)
    {
        for(j=0;j<N;j++)
            *(Asub+i)+=*(*(psc+j)+i);
        printf("Average score of %s is %.2f\n",*(psub+i),*(Asub+i)/N);
    }
    return 0;
}
int Num_of_low(int (*psc)[M])
{
    int i,j,t;
    for(i=0;i<M;i++)
    {
        for(j=0,t=0;j<N;j++)
            if(*(*(psc+j)+i)-*(Asub+i)/N<0) t++;
        printf("Number of students lower than avg of %s is %d\n",*(psub+i),t);
    }
    return 0;
}
int Num_of_fail(int (*psc)[M])
{
    int i,j,t;
    for(i=0;i<M;i++)
    {
        for(j=0,t=0;j<N;j++)
            if(*(*(psc+j)+i)<60) t++;
        printf("Number of students %s fail is %d\n",*(psub+i),t);
    }
    return 0;
}
int Num_of_perfect(int (*psc)[M])
{
    int i,j,t;
    for(i=0;i<M;i++)
    {
        for(j=0,t=0;j<N;j++)
            if(*(*(psc+j)+i)>=90) t++;
        printf("Number of students %s perfect is %d\n",*(psub+i),t);
    }
    return 0;
}

