#include<stdio.h>
#define N 80
int main()
{
    int n;
    int i,j,flag;
    for(;;)
    {
        printf("Please input the numbers of the lines:");
        if(scanf("%d",&n)==EOF) break;
        char *p[n],c[n][N];
        for(i=0;i<n;i++)
        {
            p[i]=c[i];
            j=flag=0;
            while((*(*(p+i)+j)=getchar())!='\n')
            {
                if(*(*(p+i)+j)==' '&&!flag) flag=1;
                if(flag&&*(*(p+i)+j)==' ') j--;
                if(*(*(p+i)+j)!=' ') flag=0;
                j++;
            }
            *(*(p+i)+j)='\0';
        }
        for(i=0;i<n;i++)
            printf("%s\n",*(p
                            +i));
    }
    return 0;
}
