#include<stdio.h>
#define N 20 //������λ��
#define M 10 //С����λ��
int main()
{
    int i,iTep;
    char a[M+N],b[M+N],sum[M+N+1];
    char *pa=a,*pb=b,*pSum=sum;
    for(i=0;i<M+N;i++)
    {
        *(pa+i)=getchar();
        if(*(pa+i)=='.') i--;
    }
    getchar();
    for(i=0;i<M+N;i++)
    {
        *(pb+i)=getchar();
        if(*(pb+i)=='.') i--;
    }
    for(i=M+N-1,iTep=0;i>=0;i--)
    {
        iTep+=*(pa+i)+*(pb+i)-2*'0';
        *(pSum+i+1)=(iTep%10)+'0';
        iTep/=10;
    }
    if(iTep) *(pSum)=iTep+'0';
    else *(pSum)='0';
    if(*(pSum)!='0') putchar(*(pSum));
    for(i=1;i<=M+N;i++)
    {
        putchar(*(pSum+i));
        if(i==N) putchar('.');
    }
    return 0;
}
