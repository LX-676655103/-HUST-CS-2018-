#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Information{
    char num[20];
    char name[30];
    float English,Math,Physics,C;
    float aver;
};
struct Class{
    struct Information data;
    struct Class *next;
};
void create_list(struct Class **phead,int n);
void output_list(struct Class *phead);
void search_list(struct Class *phead, char *num,char *sub,float score);
void average_sum(struct Class *phead);
void sort(struct Class *phead,int n);
int main()
{
    int n,m;
    float score;
    char num[20],sub[20];
    struct Class *phead=NULL;
    printf("��������Ҫ������ѧ��������");
    scanf("%d",&n);
    printf("��������Ҫ������ѧ����Ϣ��\n");
    create_list(&phead,n);
    output_list(phead);
    printf("��������Ҫ�޸ĵ���Ϣ������");
    scanf("%d",&m);
    printf("��ֱ�������Ҫ�޸�ѧ����ѧ�ţ���Ŀ�ͳɼ���\n");
    while(m-->0)
    {
        scanf("%s%s%f",num,sub,&score);
        search_list(phead,num,sub,score);
    }
    printf("Alter:\n");
    output_list(phead);
    average_sum(phead);
    printf("Sort:\n");
    sort(phead,n);

}
void create_list(struct Class **phead,int n)
{
    struct Class *pNew=NULL,*pEnd=NULL;
    pNew=(struct Class *)malloc(sizeof(struct Class));
    scanf("%s",pNew->data.num);
    scanf("%s",pNew->data.name);
    scanf("%f%f%f%f",&pNew->data.English,&pNew->data.Math,&pNew->data.Physics,&pNew->data.C);
    pEnd=pNew;
    *phead=pEnd;
    while(--n>0)
    {
        pNew=(struct Class *)malloc(sizeof(struct Class));
        scanf("%s",pNew->data.num);
        scanf("%s",pNew->data.name);
        scanf("%f%f%f%f",&pNew->data.English,&pNew->data.Math,&pNew->data.Physics,&pNew->data.C);
        pEnd->next=pNew;
        pEnd=pNew;
    }
    pEnd->next=NULL;
}
void output_list(struct Class *phead)
{
    struct Class *pNew=phead;
    printf("%-15s%-20s%-10s%-10s%-10s%-10s\n","ID","Name","English","Math","Physics","C");
    while(pNew)
    {
        printf("%-15s",pNew->data.num);
        printf("%-20s",pNew->data.name);
        printf("%-10.2f%-10.2f%-10.2f%-10.2f\n",pNew->data.English,pNew->data.Math,pNew->data.Physics,pNew->data.C);
        pNew=pNew->next;
    }
    printf("\n");
}
void search_list(struct Class *phead, char *num,char *sub,float score)
{
    struct Class *pNew=phead;
    while(pNew)
    {
        if(strcmp(pNew->data.num,num)==0)
        {
            if(strcmp(sub,"English")==0) pNew->data.English=score;
            else if(strcmp(sub,"Math")==0) pNew->data.Math=score;
            else if(strcmp(sub,"Physics")==0) pNew->data.Physics=score;
            else if(strcmp(sub,"C")==0) pNew->data.C=score;
            break;
        }
        pNew=pNew->next;
    }
}
void average_sum(struct Class *phead)
{
    float aver;
    int i;
    float *pNum;
    struct Class *pNew=phead;
    printf("SumAndAvg:\n");
    printf("%-15s%-20s%-10s%-10s\n","ID","Name","SUM","AVG");
    while(pNew)
    {
        for(i=0,aver=0,pNum=&pNew->data.English;i<4;i++)
            aver+=*(pNum+i);
        pNew->data.aver=aver/4;
        printf("%-15s%-20s%-10.2f%-10.2f\n",pNew->data.num,pNew->data.name,aver,pNew->data.aver);
        pNew=pNew->next;
    }
    printf("\n");
}
void sort(struct Class *phead,int n)
{
    int i,j;
    struct Class *pNew=phead;
    struct Information t;
    for(i=0;i<n-1;i++)
    for(j=0,pNew=phead;j<n-i-1;j++)
    {
        if(pNew->data.aver > pNew->next->data.aver)
        {
            t=pNew->data;
            pNew->data=pNew->next->data;
            pNew->next->data=t;
        }
        pNew=pNew->next;
    }
    pNew=phead;
    printf("%-15s%-20s%-10s\n","ID","Name","AVG");
    while(pNew)
    {
        printf("%-15s%-20s%-10.2f\n",pNew->data.num,pNew->data.name,pNew->data.aver);
        pNew=pNew->next;
    }
}









