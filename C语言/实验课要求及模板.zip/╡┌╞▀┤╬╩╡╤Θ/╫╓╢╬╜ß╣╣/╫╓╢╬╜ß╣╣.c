#include<stdio.h>
struct ISR_BITS
{
    unsigned char bit0: 1,bit1: 1,bit2: 1,bit3: 1;
    unsigned char bit4: 1,bit5: 1,bit6: 1,bit7: 1;
};
union ISR_REG
{
    unsigned char   all;
    struct ISR_BITS bit;
}num;
void isr0();
void isr1();
void isr2();
void isr3();
void isr4();
void isr5();
void isr6();
void isr7();
int main()
{
    int i,n;
    void (*p_isr[8])(void)={isr0,isr1,isr2,isr3,isr4,isr5,isr6,isr7};
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%hhu",&num.all);
        printf("%hhu:\n",num.all);
        if(num.bit.bit0) p_isr[0]();
        if(num.bit.bit1) p_isr[1]();
        if(num.bit.bit2) p_isr[2]();
        if(num.bit.bit3) p_isr[3]();
        if(num.bit.bit4) p_isr[4]();
        if(num.bit.bit5) p_isr[5]();
        if(num.bit.bit6) p_isr[6]();
        if(num.bit.bit7) p_isr[7]();
        printf("\n");
    }
    return 0;
}
void isr0()
{
    printf("the function 0 is called!\n");
}
void isr1()
{
    printf("the function 1 is called!\n");
}
void isr2()
{
    printf("the function 2 is called!\n");
}
void isr3()
{
    printf("the function 3 is called!\n");
}
void isr4()
{
    printf("the function 4 is called!\n");
}
void isr5()
{
    printf("the function 5 is called!\n");
}
void isr6()
{
    printf("the function 6 is called!\n");
}
void isr7()
{
    printf("the function 7 is called!\n");
}
