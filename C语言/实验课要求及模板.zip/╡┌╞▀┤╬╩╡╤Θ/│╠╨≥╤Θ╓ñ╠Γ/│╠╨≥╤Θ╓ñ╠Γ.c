#include<stdio.h>
char u[]="UVWXYZ";
char v[]="xyz";
struct T{
    int   x;
    char  c;
    char *t;
}a[]={{11,'A',u},{100,'B',v}},*p=a;
int main()
{
    printf("(++p)->x=%d\n",(++p)->x);p--;
    printf("p++,p->c=%c\n",(p++,p->c));p--;
    printf("*p++->t,*p->t=%c\n",(*p++->t,*p->t));p--;
    printf("*(++p)->t=%c\n",*(++p)->t);p--;
    printf("*++p->t=%c\n",*++p->t);--p->t;
    printf("++*p->t=%c\n",++*p->t);--*p->t;
    return 0;
}

