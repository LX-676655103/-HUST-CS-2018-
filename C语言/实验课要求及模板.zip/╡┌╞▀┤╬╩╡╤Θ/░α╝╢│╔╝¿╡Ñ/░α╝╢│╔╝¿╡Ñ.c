#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct Class{
    char num[20];
    char name[20];
    int English,Math,Physics,C;
    struct Class *next;
};
void create_list(struct Class **phead);
void output_list(struct Class *phead);
void search_list(struct Class *phead, char *name);
void average_of_score(struct Class *phead);
int main()
{
    char name[20];
    struct Class *phead=NULL;
    create_list(&phead);
    output_list(phead);
    scanf("%s",name);
    search_list(phead,name);
    average_of_score(phead);

}
void create_list(struct Class **phead)
{
    struct Class *pNew=NULL,*pEnd=NULL;
    pNew=(struct Class *)malloc(sizeof(struct Class));
    scanf("%s",pNew->num);
    scanf("%s",pNew->name);
    scanf("%d%d%d%d",&pNew->English,&pNew->Math,&pNew->Physics,&pNew->C);
    pEnd=pNew;
    *phead=pEnd;
    while(1)
    {
        pNew=(struct Class *)malloc(sizeof(struct Class));
        if(scanf("%s",pNew->num)==EOF) break;
        scanf("%s",pNew->name);
        scanf("%d%d%d%d",&pNew->English,&pNew->Math,&pNew->Physics,&pNew->C);
        pEnd->next=pNew;
        pEnd=pNew;
    }
    pEnd->next=NULL;
    free(pNew);
}
void output_list(struct Class *phead)
{
    struct Class *pNew=phead;
    while(pNew->next)
    {
        printf("%s %s %d ",pNew->num,pNew->name,pNew->English);
        printf("%d %d %d\n",pNew->Math,pNew->Physics,pNew->C);
        pNew=pNew->next;
    }
    printf("%s %s %d ",pNew->num,pNew->name,pNew->English);
    printf("%d %d %d\n",pNew->Math,pNew->Physics,pNew->C);
}
void search_list(struct Class *phead, char* name)
{
    struct Class *pNew=phead;
    while(pNew)
    {
        if(strcmp(pNew->name,name)==0)
        {
            scanf("%s",pNew->num);
            scanf("%s",pNew->name);
            scanf("%d%d%d%d",&pNew->English,&pNew->Math,&pNew->Physics,&pNew->C);
            break;
        }
        pNew=pNew->next;
    }
}
void average_of_score(struct Class *phead)
{
    float aver;
    int i,*pNum;
    struct Class *pNew=phead;
    for(;pNew;pNew=pNew->next)
    {
        for(i=0,aver=0,pNum=&pNew->English;i<4;i++)
            aver+=*(pNum+i);
        printf("%s %s %.2f %.2f\n",pNew->num,pNew->name,aver,aver/4);
    }
}











