#include <stdio.h>
#define N 10000
char num[N];
int main()
{
    int i=0;
    while(1)
    {
        i=0;
        scanf("%s",num);
        if(num[i]=='0') break;
        while(num[i]!='\0') i++;
        i--;
        for(;i>=0;i--)
            printf("%c",num[i]);
        printf("\n");
    }
    return 0;
}
