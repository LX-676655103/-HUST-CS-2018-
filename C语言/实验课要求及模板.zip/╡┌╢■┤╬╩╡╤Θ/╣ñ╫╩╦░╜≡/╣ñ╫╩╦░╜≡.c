#include <stdio.h>
int main()
{
    double x;
    printf("Please enter salary:");
    scanf("%lf",&x);
    switch((int)(x/1000)){
    case 0: printf("tax=0.00\n"); break;
    case 1: printf("tax=%.2f\n",x*0.05); break;
    case 2: printf("tax=%.2f\n",x*0.1); break;
    case 3: printf("tax=%.2f\n",x*0.15); break;
    case 4: printf("tax=%.2f\n",x*0.2); break;
    default: printf("tax=%.2f\n",x*0.25); break;
    }
    return 0;
}
