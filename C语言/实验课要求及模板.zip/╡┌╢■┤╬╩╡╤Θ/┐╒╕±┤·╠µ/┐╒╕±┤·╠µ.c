#include <stdio.h>
char c;
int main()
{
    int j=0;
    int n;
    scanf("%d",&n);
    getchar();
    while(n>0)
    {
        while((c=getchar())!='\n')
        {
            if(c==32&&j==0)
            {
                j=1;
                putchar(' ');
            }
            else if(c!=32)
            {
                j=0;
                printf("%c",c);
            }
        }
        j=0;
        printf("\n");
        n--;
    }
    return 0;
}
