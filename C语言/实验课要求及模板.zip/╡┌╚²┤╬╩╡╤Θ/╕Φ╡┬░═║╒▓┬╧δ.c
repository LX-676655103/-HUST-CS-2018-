#include "stdio.h"
#include <math.h>
int is_prime(int num)
{
    int i;
    if(num==2) return 1;
    for(i=2;i<=sqrt(num);i++)
        if(num%i==0) return 0;
    return 1;
}
int main()
{
    int num,i,j;
    int b,e;
    while(scanf("%d%d",&b,&e)!=EOF)
    {
        if(b==0) return 0;
        if(b%2==1) b++;
        if(e%2==1) e--;
        for(j=b;j<=e;j=j+2)
        {
            for(i=2;i<j;i++)
            if(is_prime(i)&&is_prime(j-i))
            {
                printf("%d=%d+%d\n",j,i,j-i);
                break;
            }
        }
        printf("\n");
    }
    return 0;
}
