#include "stdio.h"
int num1,num2;
int n=0;
int DFS()
{
    if(num1%n==0&&num2%n==0) return 0;
    else
    {
        n--;
        DFS();
    }
    return 0;
}
int main()
{
    int t;
    while(scanf("%d%d",&num1,&num2)!=EOF){
    if(num1==0) break;
    if(num1>=num2)
    {
        t=num1;
        num1=num2;
        num2=t;
    }
    n=num1;
    DFS();
    printf("%d\n",n);
    }
    return 0;
}
