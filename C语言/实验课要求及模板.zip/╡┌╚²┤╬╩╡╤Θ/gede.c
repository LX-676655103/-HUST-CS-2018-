#include "stdio.h"
#include <math.h>
int is_prime(int num)
{
    int i;
    if(num==2) return 1;
    for(i=2;i<=sqrt(num);i++)
        if(num%i==0) return 0;
    return 1;
}

int main()
{
    int num,i;
    while(scanf("%d",&num)!=EOF)
    {
        for(i=2;i<num;i++)
            if(is_prime(i)&&is_prime(num-i))
            {
                printf("%d=%d+%d\n",num,i,num-i);
                break;
            }
    }
    return 0;
}
