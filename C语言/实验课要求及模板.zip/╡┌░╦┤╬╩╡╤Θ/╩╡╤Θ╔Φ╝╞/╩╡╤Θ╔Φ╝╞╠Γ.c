#include<stdio.h>
#include<stdlib.h>
int main()
{
    int flag=0;
    char c;
    freopen("d:\\test.txt","w+",stdout);
    while((c=getchar())!=EOF)
    {
        if(c!=' '&&flag)
            putchar(c);
        else if(c>='a'&&c<='z'&&!flag)
            putchar(c-32),flag=1;
        else if(c>='A'&&c<='Z'&&!flag)
            putchar(c),flag=1;
        else if(c==' '||c=='.')
            putchar(c),flag=0;
    }
    return 0;
}
