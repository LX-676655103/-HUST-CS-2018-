#include <stdio.h>
#include <string.h>
char* strnins(char s[],char t[],int n);
int main()
{
    int n;
    char s[1000],t[1000],*p;
    scanf("%d%s%s",&n,s,t);
    p=strnins(s,t,n);
    printf("%s\n",p);
    return 0;
}
char* strnins(char s[],char t[],int n)
{
    int i=0,j;
    char c[2000],*p=c;
    for(j=0;j<n;j++)
        c[j]=s[j];
    while(t[i]!='\0')
        c[i+n]=t[i++];
    while(s[j++]!='\0')
        c[j+i-1]=s[j-1];
    c[j+i-1]=s[j-1];
    return p;
}
