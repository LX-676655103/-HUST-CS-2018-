#include<stdio.h>
#define M 10
#define N 3
int main(void)
{
    int a[M], b[M];
    int i, j, k;
    for(i = 0; i < M; i++)
        a[i] = i + 1;
    for(i = M, j = 0; i > 0; i--)
    {
        for(k = 1; k <= N; k++)
        {
            while(a[j]==0) j++;
            if(++j == M) j = 0;
        }
        b[M-i] = j? j: 10 ;
        a[--j]=0;
    }
    for(i = 0;i < M ; i++)
        printf("%6d", b[i]);
    return 0;
}
