#include <stdio.h>
int main()
{
    int i,j;
    int num[3][4];
    for(i=0;i<3;i++)
        for(j=0;j<4;j++)
        scanf("%d",&num[i][j]);
    for(i=0;i<3;i++)
    {
        for(j=0;j<4;j++)
            printf("%5d",num[i][j]);
        printf("\n");
    }
    printf("\n");
    for(i=0;i<4;i++)
    {
        for(j=0;j<3;j++)
           printf("%5d",num[j][i]);
        printf("\n");
    }
    return 0;
}
