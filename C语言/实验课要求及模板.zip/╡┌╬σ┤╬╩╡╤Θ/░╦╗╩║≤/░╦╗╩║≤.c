#include <stdio.h>
#include<math.h>
int n,t;
int queen[100];
int putqueen();
int is_null();
int printpath();
int main()
{
    scanf("%d",&n);
    putqueen(0);
    return 0;
}
int putqueen(int i)
{
    int j;
    if(i>=n)
    {
        t++;
        printpath();
        return 0;
    }
    for(j=0;j<n;j++)
    {
        queen[i]=j;
        if(is_null(i))
            putqueen(i+1);
    }
    return 0;
}
int is_null(int i)
{
    int j;
    for(j=0;j<i;j++)
       if(queen[j]==queen[i]||abs(queen[i]-queen[j])==abs(i-j))
        return 0;
    return 1;
}
int printpath()
{
    int i,j;
    printf("%d\n",t);
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(queen[i]==j) printf("# ");
            else printf("0 ");
        }
        printf("\n");
    }
    printf("\n");
    return 0;
}









