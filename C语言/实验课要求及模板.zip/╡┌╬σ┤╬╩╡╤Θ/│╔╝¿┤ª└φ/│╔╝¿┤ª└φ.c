#include <stdio.h>
int n;
struct score{
    char name[30];
    int num;
};
struct score a[1000];
int search(int t)
{
    int start=0;
    int mid;
    int end=n-1;
    while(start<=end)
    {
        mid=(end+start)/2;
        if(t>a[mid].num)
            end=mid-1;
        else if(t<a[mid].num)
            start=mid+1;
        else
        {
            printf("%-20s %d\n",a[mid].name,a[mid].num);
            return 0;
        }
    }
    printf("Not found!\n");
    return 0;
}
int main()
{
    int i,j;
    int N,iPos,m;
    scanf("%d ",&n);
    struct score iName;
    for(i=0;i<n;i++)
        scanf("%s%d",a[i].name,&a[i].num);
    for(i=0;i<n;i++)
    {
        iName=a[i];
        iPos=i;
        for(j=i+1;j<n;j++)
            if(iName.num<a[j].num)
            {
                iName=a[j];
                iPos=j;
            }
        a[iPos]=a[i];
        a[i]=iName;
    }
    for(i=0;i<n;i++)
        printf("%-20s %d\n",a[i].name,a[i].num);
    printf("\n");
    scanf("%d",&N);
    for(i=0;i<N;i++)
    {
        scanf("%d",&m);
        search(m);
    }
    return 0;
}




