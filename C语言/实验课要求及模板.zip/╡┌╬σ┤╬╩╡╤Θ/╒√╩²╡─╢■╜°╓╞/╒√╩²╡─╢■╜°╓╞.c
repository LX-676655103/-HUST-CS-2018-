#include <stdio.h>
#include <string.h>
#include <limits.h>
int PrintBit(int x)
{
    int i;
    int n=sizeof(int)*CHAR_BIT;
    int mask=1<<(n-1);
    for(i=0;i<n;i++)
    {
        putchar((x&mask)?'1':'0');
        x<<=1;
    }
    printf("\n");
    return 0;
}
int main()
{
    int m;
    int n,i,sum,flag;
    char num[1000];
    scanf("%d",&n);
    while(n>0)
    {
        sum=0;
        scanf("%s",num);
        m=strlen(num);
        if(num[0]=='-') flag=1;
        else flag=0;
        for(i=flag;i<m;i++)
        {
            sum=sum*10;
            sum=sum+num[i]-'0';
        }
        if(flag) sum=0-sum;
        PrintBit(sum);
        n--;
    }
    return 0;
}
