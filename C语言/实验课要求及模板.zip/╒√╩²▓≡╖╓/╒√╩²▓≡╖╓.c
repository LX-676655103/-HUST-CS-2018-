#include<stdio.h>
int num;
int time;
int a[100],p;
int printnum()
{
    int i;
    printf("%d ",time);
    for(i=p;i>0;i--) printf("%d+",a[i]);
    printf("%d\n",a[i]);
    return 0;
}

int DFS(int k,int t)
{
    int i;
    for(i=k;i>0;)
    {
        i--;
        if(i>=k-i&&k-i>=t)
        {
            time++;
            a[p]=k-i;
            p++;
            a[p]=i;
            printnum();
            DFS(i,k-i);

        }
    }
    p--;
    return 0;
}

int main()
{
    while(scanf("%d",&num)!=EOF)
    {
        time=0;
        p=0;
        DFS(num,0);
    }
    return 0;
}
