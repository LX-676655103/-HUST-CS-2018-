#include<stdio.h>
int main( )
{
    unsigned short x,m,n,mask=0;
    scanf("%hu%hu%hu",&x,&m,&n);
    mask=(~mask)>>(16-n);
    mask=mask<<m;
    mask=(mask&x)<<(16-m-n);
    printf("%hu\n",mask);
    return 0;
}
