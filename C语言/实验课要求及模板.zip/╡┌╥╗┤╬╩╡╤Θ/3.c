#include<stdio.h>
int main( )
{
    char c;
    while(scanf("%1s",&c)!=EOF)
    {
        if(c>='A'&&c<='Z') c+=32;
        printf("%c\n",c);
    }
    return 0;
}
