#include<stdio.h>
int main( )
{
    unsigned long x,num[4];
    int i;
    scanf("%lu",&x);
    for(i=0;i<4;i++)
    {
        num[i]=x<<(i*8);
        num[i]=num[i]>>24;
    }
    printf("%lu.%lu.%lu.%lu\n",num[3],num[2],num[1],num[0]);
    return 0;
}
