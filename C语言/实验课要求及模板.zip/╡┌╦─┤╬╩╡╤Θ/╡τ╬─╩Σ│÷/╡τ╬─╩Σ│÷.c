#include<stdio.h>
#include<math.h>
//#define CHANGE 0
#define CHANGE 1 //�����궨�������Ƴ����Ƿ�����
int main()
{
    char c;
    #if CHANGE == 0
    while(putchar(getchar())!='\n');
    #elif CHANGE == 1
    while((c=getchar())!='\n')
    {
        if(c>='a'&&c<='z')
            putchar(c-32);
        else if(c>='A'&&c<='Z')
            putchar(c+32);
        else putchar(c);
    }
    printf("\n");
    #endif
    return 0;
}
