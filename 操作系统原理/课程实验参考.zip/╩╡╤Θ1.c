#include <stdio.h>
#include<stdlib.h>
#include<signal.h>

int  pipefd[2];
int count = 0;

#define  total  100

int pid1,pid2;
char buf[100];

void stop1()
{
kill(pid1,SIGUSR1);
kill(pid2,SIGUSR2);
close(pipefd[1]);
wait();
wait();
printf("Total message :%d\n",100-total);
exit(-1);
}


void stop2(int sig)
{
close(pipefd[0]);
if (sig == SIGUSR1)
printf("child1 %d to be killed!,Get message:%d\n",getpid(),count);
else
printf("child2 %d to be killed!,Get message:%d\n",getpid(),count);
exit(-1);
}


main()
{
int i;
pipe(pipefd);

pid1= fork();
if (pid1 ==0) {
	close(pipefd[1]);
	signal(SIGINT,SIG_IGN);
	signal(SIGUSR1,stop2);
	while (read(pipefd[0],buf,100)>0) {
		count++;
		printf("child1 %d read %s\n",getpid(),buf);
	}
	printf("child1 %d Get message:%d\n",getpid(),count);
	close(pipefd[0]);
	exit(0);
}

pid2 = fork();
if (pid2==0) { 
        close(pipefd[1]);
        signal(SIGINT,SIG_IGN);
        signal(SIGUSR2,stop2);
        while (read(pipefd[0],buf,100)>0){
		count++;
                printf("child2 %d read %s\n",getpid(),buf);
	}
	printf("child2 %d Get message:%d\n",getpid(),count);
        close(pipefd[0]);
        exit(0);
}
close(pipefd[0]);
signal(SIGINT,stop1);
i=0;
while (i<total) {
	sprintf(buf," %d message by %d!",i++,getpid());
	write(pipefd[1],buf,100);
	sleep(1);
}
close(pipefd[1]);

wait(NULL);
wait(NULL);
printf("Total message :%d\n",100-total);
}
