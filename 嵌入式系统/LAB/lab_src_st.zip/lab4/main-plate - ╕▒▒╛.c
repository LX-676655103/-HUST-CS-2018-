#include <stdio.h>
#include "../common/common.h"
#define BUTTON_H 30
#define BUTTON_W 50
#define COLOR_BACKGROUND	FB_COLOR(0xff,0xff,0xff)
int r = 30;
int last_x [5] = {-1};
int last_y [5] = {-1};
int color[5] =
{
    FB_COLOR(65,105,225),   //Blue
    FB_COLOR(0,255,127),    //Spring Green
    FB_COLOR(255,215,0),    //Gold
    FB_COLOR(255,140,0),    //Dark Orange
    FB_COLOR(255,69,0)     //Orange Red
};
static int touch_fd;

void draw_plate (int x0,int y0,int r,int color)
{

    if (r <= 0) return;
    if (x0+r<0 || x0-r>SCREEN_WIDTH) return ;
    if (y0+r<0 || y0-r>SCREEN_HEIGHT) return ;

    int x,y;
    for (x=x0-r; x<=x0+r; x++)
        for (y=y0-r; y<=y0+r; y++)
            if ((x-x0)*(x-x0) + (y-y0)*(y-y0) <= r*r)
                fb_draw_pixel(x,y,color);

}
static void touch_event_cb(int fd)
{
	int type,x,y,finger,i;
	type = touch_read(fd, &x,&y,&finger);
	switch(type){
	case TOUCH_PRESS:
		printf("TOUCH_PRESS：x=%d,y=%d,finger=%d,color=%d\n",x,y,finger,color[finger]);
        draw_plate(x,y,r,color[finger]);
        last_x[finger] = x;
        last_y[finger] = y;
        fb_update();
        break;

	case TOUCH_MOVE:
	    printf("TOUCH_MOVE：x=%d,y=%d,finger=%d,color=%d\n", x,y,finger,color[finger]);
        last_x[finger] = x;
        last_y[finger] = y;
        fb_draw_rect(0,0,SCREEN_WIDTH,SCREEN_HEIGHT,COLOR_BACKGROUND);
        for (i = 0; i < 5; i++)
            if (last_x[i] != -1 && last_y[i] != -1)
                draw_plate(last_x[i],last_y[i],r,finger_color[i]);
        fb_update();
        break;
	case TOUCH_RELEASE:
		printf("TOUCH_RELEASE：x=%d,y=%d,finger=%d\n",x,y,finger);
        fb_draw_rect(0,0,SCREEN_WIDTH,SCREEN_HEIGHT,COLOR_BACKGROUND);
        last_x[finger] = -1;
        last_y[finger] = -1;
        for (i = 0; i < 10; i++){
            if (last_x[i] != -1 && last_y[i] != -1)
                draw_plate(last_x[i],last_y[i],r,finger_color[i]);
        fb_update();
		break;
	case TOUCH_ERROR:
		printf("close touch fd\n");
		close(fd);
		task_delete_file(fd);
		break;
	default:
		return;
	}
	fb_update();
	return;
}

int main(int argc, char *argv[])
{
	fb_init("/dev/graphics/fb0");
	fb_draw_rect(0,0,SCREEN_WIDTH,SCREEN_HEIGHT,COLOR_BACKGROUND);
	fb_update();

	//打开多点触摸设备文件, 返回文件fd
	touch_fd = touch_init("/dev/input/event3");
	//添加任务, 当touch_fd文件可读时, 会自动调用touch_event_cb函数
	task_add_file(touch_fd, touch_event_cb);
	task_loop(); //进入任务循环
	return 0;
}
