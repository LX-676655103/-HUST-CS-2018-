#include <stdio.h>
#include "../common/common.h"
#define BUTTON_H 30
#define BUTTON_W 50
#define COLOR_BACKGROUND	FB_COLOR(0xff,0xff,0xff)
int last_x [5];
int last_y [5];
int color[5] =
{
    FB_COLOR(65,105,225),   //Blue
    FB_COLOR(0,255,127),    //Spring Green
    FB_COLOR(255,215,0),    //Gold
    FB_COLOR(255,140,0),    //Dark Orange
    FB_COLOR(255,69,0)      //Orange Red
};
static int touch_fd;
static void touch_event_cb(int fd)
{
	int type,x,y,finger,i;
	type = touch_read(fd, &x,&y,&finger);
	switch(type){
	case TOUCH_PRESS:
		printf("TOUCH_PRESS：x=%d,y=%d,finger=%d,color=%d\n",x,y,finger,color[finger]);
		/* 点击清除按钮 */
        if(x<=BUTTON_W && y<=BUTTON_H)
        {
            fb_draw_rect(0,0,SCREEN_WIDTH,SCREEN_HEIGHT,FB_COLOR(255,255,255));
            fb_draw_rect(0,0,BUTTON_W,BUTTON_H,FB_COLOR(0,0,0));
            fb_draw_text(10,10,"清除CLEAR",25,FB_COLOR(255,255,255));
            fb_update();
            break;
        }
        /* 记录之前手指位置信息，并输出点，宽度为4 */
        last_x[finger]=x;
        last_y[finger]=y;
        fb_draw_rect(x-2,y-2,4,4,color[finger]);
        fb_update();
        break;

	case TOUCH_MOVE:
	    printf("TOUCH_MOVE：x=%d,y=%d,finger=%d,color=%d\n", x,y,finger,color[finger]);
	    /* 并输出线，记录手指位置信息，线宽度为4 */
	    fb_draw_line(last_x[finger],last_y[finger],x,y,color[finger]);
	    for(i = 1; i < 2; i++)
        {
            fb_draw_line(last_x[finger],last_y[finger]+i,x,y+i,color[finger]);
            fb_draw_line(last_x[finger],last_y[finger]-i,x,y-i,color[finger]);
            fb_draw_line(last_x[finger]+i,last_y[finger],x+i,y,color[finger]);
            fb_draw_line(last_x[finger]-i,last_y[finger],x-i,y,color[finger]);
        }
        last_x[finger]=x;
        last_y[finger]=y;
        fb_update();
		break;
	case TOUCH_RELEASE:
		printf("TOUCH_RELEASE：x=%d,y=%d,finger=%d\n",x,y,finger);
		break;
	case TOUCH_ERROR:
		printf("close touch fd\n");
		close(fd);
		task_delete_file(fd);
		break;
	default:
		return;
	}
	fb_update();
	return;
}

int main(int argc, char *argv[])
{
	fb_init("/dev/graphics/fb0");
	fb_draw_rect(0,0,SCREEN_WIDTH,SCREEN_HEIGHT,COLOR_BACKGROUND);
	/* 绘制清除按钮 */
	fb_draw_rect(0,0,BUTTON_W,BUTTON_H,FB_COLOR(0,0,0));
	fb_draw_text(10,10,"清除CLEAR",25,FB_COLOR(255,255,255));
	fb_update();

	//打开多点触摸设备文件, 返回文件fd
	touch_fd = touch_init("/dev/input/event3");
	//添加任务, 当touch_fd文件可读时, 会自动调用touch_event_cb函数
	task_add_file(touch_fd, touch_event_cb);
	task_loop(); //进入任务循环
	return 0;
}
