#include <stdio.h>

int main(int argc, char* argv[])
{
	printf("Hello embedded linux!\n");
	return 0;
}
