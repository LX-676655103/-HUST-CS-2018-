#!/system/busybox/bin/sh

#check bdaddr_mac
if [ -e /system/etc/bluetooth/bdaddr_mac ]
then
        echo already has bdaddr_mac
else
	BTMAC="ae:2d:`expr $RANDOM % 89 + 10`:`expr $RANDOM % 89 + 10`:`expr $RANDOM % 89 + 10`:`expr $RANDOM % 89 + 10`"

        echo $BTMAC > /system/etc/bluetooth/bdaddr_mac
	sync
fi

ps | grep hciattach | grep -v grep > /dev/null
if [ $? -eq 0 ]
then
	echo "already running"
	exit 0
fi

#开启串口蓝牙hci
hciattach -n -s 115200 /dev/ttySAC3 rda 1152000 &
sleep 3

#执行蓝牙服务程序
setprop ctl.start bluetoothd
sleep 3

#蓝牙配对
agent 1234 &
sleep 1

#增加串口服务
sdptool add SP

#进入page状态(可以被连接)
hciconfig hci0 pscan

#同时进入page状态和inquiry状态
#hciconfig hci0 piscan

